import json
import re

R = []

# ---- six-table engine retarder family (values tables only; axis governor_load_xaxis_cal is already named) ----
family_concern = ("governor_load_xaxis_cal is the engine speed axis (1000..4000 rpm) of this retarder family and carries a _cal / governor-load misnomer; "
                  "misnomers in this chain: j1939FormatMultiFrameResponse (quantizes the TSC1 retarder request into stages), cm848_calculateSpeedControlError (builds ERC1 byte 2), "
                  "fuel_operation_mode_index / _count (retarder stage count), j1939_engine_torque_encoded (Q8 retarder percent torque), governor_speed_request_maximum, "
                  "governor_speed_percentage_cal, j1939_transfer_frame_count. 'stage' chosen over 'mode' to avoid confusion with ERC1 SPN 900 Retarder Torque Mode.")
fam_evidence_common = ("Dispatcher cm848_j1939DispatchAddressHandler routes TSC1 (PGN 0) sent to j1939_source_address_b to cm848_j1939ProcessGovernorRequest, and the PGN 61440 (ERC1) header uses the same source address; "
                       "cm848_j1939SetupMultiFrameTransfer turns the TSC1 byte (125 offset) into a 0..100 percent retarding magnitude. ")
R.append({"lookup": "L225", "base": "engine_retarder_torque_stage_1",
  "input": "engine_rpm_state_t_0040b7ac.current_rpm (engine speed, 0.125 rpm/count)",
  "output": "governor_speed_request_maximum (misnomer) -> maximum engine retarder torque at the current speed with stage 1 engaged; j1939FormatMultiFrameResponse compares it with j1939_governor_speed_demand = requested retarder percent x WORD_ARRAY_0005a462[4] / 100 and steps governor_output_percentage 0/17/33/50/67/83/100 (= stage / 6)",
  "units_check": "shared axis governor_load_xaxis_cal 8000..32000 = 1000..4000 rpm at 0.125 rpm/count, fits engine speed; values 208, 300, 350, 322 are retarder torque units where 350 (= WORD_ARRAY_0005a462[4]) is the 100 percent reference; mode-1 is the only non-zero stage in this calibration (cal_fuel_operation_mode_1_en = 1, the other stage cals = 0)",
  "confidence": "high",
  "evidence": fam_evidence_common + "Mode 1 is the one populated curve; cm848_calculateSpeedControlError also selects it when fuel_operation_mode_index = 1.",
  "naming_concern": family_concern})
for lk, n, addr in (("L226", 2, "0x0005a43a"), ("L227", 3, "0x0005a444"), ("L228", 4, "0x0005a44e"), ("L229", 5, "0x0005a458")):
    R.append({"lookup": lk, "base": "engine_retarder_torque_stage_%d" % n,
      "input": "engine_rpm_state_t_0040b7ac.current_rpm (engine speed, 0.125 rpm/count)",
      "output": "governor_speed_request_maximum (misnomer) -> maximum engine retarder torque at the current speed with stage %d engaged (compared with the requested retarder torque in j1939FormatMultiFrameResponse; also selectable by fuel_operation_mode_index = %d in cm848_calculateSpeedControlError)" % (n, n),
      "units_check": "same shared axis as L225 (1000..4000 rpm); values are all 0 here (stage %d not populated in this calibration)" % n,
      "confidence": "medium",
      "evidence": "Member of the six-table family walked in order 1..5 by j1939FormatMultiFrameResponse and indexed 1..6 by cm848_calculateSpeedControlError; identified by family membership because the table is all zero. " + fam_evidence_common.strip(),
      "naming_concern": "same family concern as L225 (stage vs the misnamed fuel_operation_mode_index; governor_load_xaxis_cal is the engine speed axis)"})
R.append({"lookup": "L237", "base": "engine_retarder_torque_stage_6",
  "input": "engine_rpm_state_t_0040b7ac.current_rpm (engine speed, 0.125 rpm/count)",
  "output": "in_r6 selected by fuel_operation_mode_index = 6 in cm848_calculateSpeedControlError: j1939_engine_torque_encoded = clamp(table_N(rpm) x throttle_demand_integrator / WORD_ARRAY_0005a462[4], 32000), a Q8 percent that cm848_j1939BuildVehicleOperatingStatus sends as ERC1 byte 2 = 125 - (value >> 8) (SPN 520 actual retarder percent torque); its last value 350 is also the 100 percent reference (governor_speed_percentage_cal) in j1939FormatMultiFrameResponse",
  "units_check": "shared axis 1000..4000 rpm; values 0, 0, 0, 350: only the 4000 rpm point is set (the reference), consistent with a stage that is not populated in this calibration",
  "confidence": "high",
  "evidence": "Mode-6 member of the six-table family (note in bin). ERC1 formula 0x7d - (percent) is the J1939 -125 percent offset of SPN 520, so the family is engine retarder torque; element [4] of this table is read directly (not interpolated) as the full-scale reference.",
  "naming_concern": "WORD_ARRAY_0005a462[4] doubles as the full-scale reference for the whole family (and WORD_ARRAY_0005a44e[4] when fuel_operation_mode_count = 4), so this table is also the reference table; " + family_concern})

# ---- L044 / L045 : two endpoint tables of the 0..128 blend ----
R.append({"lookup": "L044", "base": "governor_speed_scale_factor_blend_0",
  "input": "speed_request_base (pedal-interpolated engine speed request between governor_speed_lower_limit and governor_speed_error_low, 0.125 rpm/count) in cm848_calculateFuelTrimValues; governor_speed_error_input (the running speed command, same units) in cm848_calculateFuelDemandWithConditions",
  "output": "governor_speed_scale_factor: weight (0x80 - fuel_timing_blend_factor) in the blend (blend x C + (128 - blend) x B) >> 7; feeds the governor PID gain calculation (governor_pid_integral_gain / governor_pid_proportional_gain) and is the divisor of (speed command - measured rpm) x 1226 that converts speed error to a fuel quantity",
  "units_check": "breakpoints 9000..36000 = 1125..4500 rpm at 0.125 rpm/count, fits a speed request; values 13533..21000 dimensionless scale; contents identical to the blend 128 table in this calibration",
  "confidence": "medium",
  "evidence": "Both functions evaluate this pair and the 0x5976e pair and blend them with fuel_timing_blend_factor; blend 0 selects this pair only, blend 128 the other (cm848_calculateRpmLimitsFromProtection picks the same endpoints for governor_speed_error_high/low_working vs _b). Meaning of the scale (inverse of the speed to fuel gain) is inferred from its use as a divisor.",
  "naming_concern": "fuel_timing_blend_factor is not about fuel timing (it is set from drivetrain_ratio thresholds, all 128 in this calibration, and blends governor tunings); cm848_calculateFuelTrimValues computes governor PID gains, not a fuel trim; governor_speed_error_low/high look like the high/low speed limits"})
R.append({"lookup": "L045", "base": "governor_speed_scale_factor_blend_128",
  "input": "speed_request_base (pedal-interpolated engine speed request, 0.125 rpm/count) in cm848_calculateFuelTrimValues; governor_speed_error_input (the running speed command) in cm848_calculateFuelDemandWithConditions",
  "output": "governor_speed_scale_factor: weight fuel_timing_blend_factor in the same blend (full weight when the blend factor = 128 = 0x80); same two consumers as the blend 0 table",
  "units_check": "breakpoints 9000..36000 = 1125..4500 rpm at 0.125 rpm/count, fits a speed request; values identical to the blend 0 table (13533..21000)",
  "confidence": "medium",
  "evidence": "Other endpoint of the blend described under L044; with fuel_timing_blend_factor = 128 (all ROM 0x5a9d2 blend entries are 128) this is the pair actually used in this calibration.",
  "naming_concern": "same blend-factor and fuel_trim misnomers as L044"})

# ---- L060 / L061 : load-adjustment gain scaling ----
R.append({"lookup": "L060", "base": "throttle_rate_d_gain_scale_by_fuel_demand_error",
  "input": "throttle_position_scaled = (fuel_demand_rate_limited - fuel_quantity_ema_filtered) / 2 (cm848_processLoadAdjustment): half the difference between the rate-limited fuel demand and the filtered fuel quantity, signed",
  "output": "throttle_rate_d_gain = min(0x7fff, table x throttle_position_scale_cal >> 12); cm848_calculateLoadIntegral multiplies it with throttle_rate_control_input (>> 10, clamped +-0x6400) to form the term subtracted from the integrator preset",
  "units_check": "signed breakpoints -1536..1921 in half fuel-quantity counts (fuel quantity 0.0679 mm3 per count) cover the whole possible demand-minus-quantity range; values all 4096 = 1.0 in Q12, so the curve is neutral in this calibration",
  "confidence": "medium",
  "evidence": "Input and output both trace to named globals with a described computation; the table is a Q12 gain multiplier applied to throttle_position_scale_cal.",
  "naming_concern": "throttle_position_scaled is not a throttle position (it is a fuel-quantity difference); whether throttle_rate_d_gain is really a derivative gain is unclear (the p-gain path is the one accumulated into the integrator); the subsystem purpose (fuel / load rate control) is not pinned down"})
R.append({"lookup": "L061", "base": "throttle_rate_p_gain_scale_by_control_input",
  "input": "throttle_rate_control_input (cm848_calculateLoadAdjustmentFactors): load-weighted fuel-demand error = gain_pos x fuel_demand_scaled >> 14 - gain_neg x integral_input / 0x51ec, signed fuel-quantity-sized counts",
  "output": "throttle_rate_p_gain = min(0x7fff, table x throttle_rate_control_scale_cal >> 12); cm848_calculateLoadIntegral accumulates (throttle_rate_control_input x throttle_rate_p_gain >> 10) x 0x28f into throttle_position_integral",
  "units_check": "signed breakpoints -320..256 (about +-20 mm3 at 0.0679 mm3/count if the signal is in fuel counts); values all 4096 = 1.0 in Q12, neutral in this calibration; the input scale is only partly verified",
  "confidence": "medium",
  "evidence": "Same Q12 gain-multiplier pattern as L060; input and output are named globals with described computations.",
  "naming_concern": "same throttle_rate / p-d gain role uncertainty as L060; breakpoint fit rests on the input being in fuel-quantity counts"})

# ---- L069 : boost compensation scale ; L070 skip ----
R.append({"lookup": "L069", "base": "governor_boost_compensation_scale",
  "input": "fuel_pressure_sensor_reference (misnomer): = boost_pressure_fuel_working (+ boost_fuel_pressure_offset_lookup), default 0x75e, so a boost / manifold pressure at 0.0159 inHg per count",
  "output": "fuel_pressure_demand_reference = (boost_control_default_cal or boost_control_mode1_cal) x table >> 15; cm848_boostCompensatedRpmGovernor subtracts fuel_demand_quantity from it (setpoint minus quantity) and runs a clamped +-0x6400 regulator",
  "units_check": "16 breakpoints 0..1886 in steps of 125.7 counts = 0..30 inHg in 2 inHg steps (1886 = the 0x75e default); values all 32768 = 1.0 in Q15, so the scale is neutral in this calibration",
  "confidence": "medium",
  "evidence": "Axis units match exactly at 0.0159 inHg per count and the writer of the input is a boost pressure; the output is the reference of the function named boostCompensatedRpmGovernor. What the reference physically limits (speed or fuel quantity) is not resolved.",
  "naming_concern": "fuel_pressure_sensor_reference and fuel_pressure_demand_reference are not fuel pressures (the first is boost pressure); fuel_demand_quantity is selected between speed-like demands by boost_control_mode, so the 'fuel' / 'turbo ratio' names in cm848_calculateTurboRatioWithMode are suspect"})
R.append({"lookup": "L070", "skip": True,
  "reason": "input is an unnamed local ratio (fuel_demand_quantity << 15 / boost_control_default_cal or mode1 cal, Q15) whose numerator is a mode-selected demand of unresolved units; output is a constant -1.0 (Q14) that goes through lookup_table_scale_factor_c_cal, a clamp and a first-order filter (throttle_rate_filter_output_a) before cm848_calculateTurboBlendOutput, so neither end gives a name that I can verify; table is neutral/flat anyway"})

# ---- L118 / L119 : sensor channel 16 linearization, two variants ----
R.append({"lookup": "L118", "base": "sensor_channel16_linearization_feature_bit_4_off",
  "input": "ADC channel index 0xf (sensorChannelTypeB_configInit in cm848_sensorChannel16_init), raw ADC counts 0..1023",
  "output": "sensor_channel15_value (0 / 1000 / 2000): a three-level discrete reading with config block 0x3fefca, used when (j1939_governor_feature_byte & 0x10) = 0",
  "units_check": "axis 0, 50, 51, 341, 454, 920, 921, 962, 963, 1023 in ADC counts (0..1023); values step 0 (counts 0..50), 1000 (51..920), 2000 (921..1023): thresholds near 4.5 V of 5 V; flat 1000 across 51..920",
  "confidence": "medium",
  "evidence": "Both init and process wrappers pick this pair when feature byte mask 0x10 is clear and the other pair when it is set; the physical sensor on ADC index 15 is not identified, hence sensor_channel16 (wrapper ordinal) naming like sensor_channel2_linearization (cm848_sensorChannel2_init passes ADC index 4 and cm848_sensorChannel7_init passes 0x4b, so the existing sensor_channelN names key on the wrapper ordinal, not the ADC index).",
  "naming_concern": "the state variable passed as argument 2 is named fuel_demand_table_xaxis_base and the outputs sensor_channel15_*: all misleading for sensor channel 16 (ADC index 15)"})
R.append({"lookup": "L119", "base": "sensor_channel16_linearization_feature_bit_4_on",
  "input": "ADC channel index 0xf (sensorChannelTypeB_configInit in cm848_sensorChannel16_init), raw ADC counts 0..1023",
  "output": "sensor_channel15_value (0 / 1000 / 2000): same three-level reading with config block 0x3fefda, used when (j1939_governor_feature_byte & 0x10) != 0",
  "units_check": "axis 0, 50, 51, 251, 341, 446, 447, 448, 449, 1023 in ADC counts; values step 0 (0..50), 1000 (51..446), 2000 (447..1023): the high threshold moves from about 920 to about 447 counts",
  "confidence": "medium",
  "evidence": "Else branch of the same feature-bit selection as L118 in the init and process wrappers.",
  "naming_concern": "same sensor_channel16 / sensor_channel15 / fuel_demand_table_xaxis_base naming mismatch as L118"})

# ---- L142 / L143 : fuel blend coefficient candidates ----
R.append({"lookup": "L142", "base": "fuel_blend_coefficient_by_barometric_pressure",
  "input": "sensor_readings_t_0040baf2.barometric_pressure (1/18.56 kPa = 0.0159 inHg per count; the field was renamed from intake_air_temp)",
  "output": "iat_fuel_trim_lookup_result (misnomer) -> max() with the coolant candidate -> fuel_blend_coefficient (Q14, clamped to 0x4000, excess goes to fuel_blend_coefficient_offset); fuel_blend_coefficient blends two fuel-limit maps in cm848_calculateThermalLimitValue / cm848_processTorqueLimitState",
  "units_check": "breakpoints 0..2200 in steps of 314 counts = 0..35 inHg in 5 inHg steps, fits barometric pressure; values all 0 so no trim in this calibration (Q14 coefficient range 0..16384)",
  "confidence": "medium",
  "evidence": "cm848_temperatureBasedFuelTrim takes the larger of this table and the coolant table as the blend coefficient; barometric_pressure is a verified sensor_readings_t field.",
  "naming_concern": "iat_fuel_trim_lookup_result and iat_fuel_trim_enable_flag still say intake air temperature although the input is barometric pressure; cm848_temperatureBasedFuelTrim also is not a fuel trim"})
R.append({"lookup": "L143", "base": "fuel_blend_coefficient_by_coolant_temperature",
  "input": "sensor_readings_t_0040baf2.coolant_temp (1/64 deg F per count)",
  "output": "coolant_fuel_trim_lookup_result -> max() with the barometric candidate -> fuel_blend_coefficient (Q14, 0x4000 = full)",
  "units_check": "breakpoints 0..22400 in steps of 3200 counts = 0..350 deg F in 50 deg F steps, fits coolant temperature; values all 0 so no trim in this calibration",
  "confidence": "medium",
  "evidence": "Other operand of the max() in cm848_temperatureBasedFuelTrim; coolant_temp is a verified sensor_readings_t field.",
  "naming_concern": "coolant_fuel_trim_lookup_result / cm848_temperatureBasedFuelTrim say trim but the result is the blend coefficient between two fuel-limit maps"})

# ---- L161 / L162 : battery voltage scaling of TPU-A parameters ----
R.append({"lookup": "L161", "base": "tpu_a_channel_14_scale_by_battery_voltage",
  "input": "sensor_readings_t_0040baf2.battery_voltage (1/16 V per count, 192 = 12.0 V)",
  "output": "TPUA_CH14_PARAM0 upper half = (tpu_ch14_period_base x table) / 0xfff, lower half = tpu_ch14_period_base (cm848_tpuMiosOutput_loadCalibration); CH14 runs the HPCR sync function per docs/tpu_mios_channel_map.md, device unknown",
  "units_check": "breakpoints 95..223 = 5.9..13.9 V, fits supply voltage; values 260 (at 5.9 V) then 299 of 4095 (Q12) = 6.3 to 7.3 percent of the base period",
  "confidence": "medium",
  "evidence": "Both ends named (battery voltage; TPU-A channel 14 parameter built from tpu_ch14_period_base); physical actuator of channel 14 is a known bench task, so the table is named by channel.",
  "naming_concern": "tpu = MPC555 time processor unit, as in the existing tpu_ch14_period_base; 'scale' is a Q12 fraction of the period base (pulse fraction), actuator unidentified"})
R.append({"lookup": "L162", "base": "tpu_a_channel_4_scale_by_battery_voltage",
  "input": "sensor_readings_t_0040baf2.battery_voltage (1/16 V per count)",
  "output": "DAT_0030414c (TPU-A channel 4 parameter 6: 0x304100 + 4 x 0x10 + 0xc) = (DAT_004090a6 x table) / 0xfff in cm848_tpuMiosOutput_loadCalibration; CH4 is a cold-start-gated output, device unknown",
  "units_check": "breakpoints 0..512 = 0..32 V in 8 V steps, fits supply voltage; values all 4098 = 1.0007 in Q12 so neutral in this calibration",
  "confidence": "medium",
  "evidence": "Channel assignment follows the TPU parameter RAM layout (0x30414e = tpu_output_ch_param7_ref for CH4 PARAM7); the scaled cal word DAT_004090a6 is unnamed.",
  "naming_concern": "same tpu abbreviation / unidentified actuator note as L161; DAT_004090a6 and DAT_0030414c are unnamed"})

# ---- final decision: L060, L061, L069 become skips (no subsystem notes in firmware/CLAUDE.md, doubtful destination names, L061 input scale unverified) ----
SKIPS = {
  "L060": ("input throttle_position_scaled is not a throttle position: cm848_processLoadAdjustment sets it to (fuel_demand_rate_limited - fuel_quantity_ema_filtered) / 2 (signed, -1536..1921 breakpoints). "
           "The table (all 4096 = 1.0 in Q12, neutral in this calibration) multiplies throttle_position_scale_cal to form throttle_rate_d_gain, which cm848_calculateLoadIntegral applies directly to the integrator preset "
           "while throttle_rate_p_gain is the one accumulated, so the p / d roles look swapped and the destination name is doubtful. firmware/CLAUDE.md has no notes on this load-adjustment / throttle_rate cluster, "
           "so the controller's purpose is unidentified; a base would copy the doubtful d_gain name or guess a role"),
  "L061": ("input throttle_rate_control_input is a composite signal from cm848_calculateLoadAdjustmentFactors (gain_pos x fuel_demand_scaled >> 14 - gain_neg x integral_input / 0x51ec) whose units cannot be verified, "
           "so the -320..256 breakpoints cannot be checked against it. The table (all 4096 = 1.0 in Q12, neutral) scales throttle_rate_control_scale_cal into throttle_rate_p_gain, which cm848_calculateLoadIntegral accumulates "
           "into throttle_position_integral (x 0x28f); same doubtful p / d destination naming as L060 and no notes in firmware/CLAUDE.md on the cluster"),
  "L069": ("input is a boost pressure: fuel_pressure_sensor_reference = boost_pressure_fuel_working (+ boost_fuel_pressure_offset_lookup, default 0x75e = 30 inHg), 16 breakpoints 0..1886 = 0..30 inHg in 2 inHg steps at 0.0159 inHg per count, "
           "values all 32768 = 1.0 in Q15 (neutral). Output is fuel_pressure_demand_reference = (boost_control_default_cal or mode1 cal) x table >> 15, the setpoint that cm848_boostCompensatedRpmGovernor subtracts fuel_demand_quantity from; "
           "but fuel_demand_quantity is selected among speed-like demands by boost_control_mode, so what the setpoint limits (speed or fuel quantity) is unresolved and the fuel_pressure_* names are misnomers. "
           "If a name is wanted later the input side is firm: a scale of the boost-compensated governor setpoint versus boost pressure. firmware/CLAUDE.md has no notes on this cluster"),
}
R = [({"lookup": r["lookup"], "skip": True, "reason": SKIPS[r["lookup"]]} if r["lookup"] in SKIPS else r) for r in R]

with open('/home/linux/.claude/jobs/d55ae3c6/tmp/tables/result_12.jsonl', 'w') as f:
    for r in R:
        f.write(json.dumps(r, ensure_ascii=True) + "\n")
print(len(R), "lines written")

# name checks against global_variables.csv
csv = open('/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/global_variables.csv').read()
for r in R:
    if 'base' not in r:
        continue
    b = r['base']
    sfx = ['_values'] if r['lookup'] in ('L225', 'L226', 'L227', 'L228', 'L229', 'L237') else ['_axis', '_values']
    for s in sfx:
        n = b + s
        hits = csv.count(',' + n + ',')
        flag = []
        if len(b) > 48:
            flag.append('BASE>48')
        if len(n) > 56:
            flag.append('COMPOSED>56')
        if hits:
            flag.append('COLLISION')
        if re.search(r'[^a-z0-9_]', n):
            flag.append('BADCHAR')
        if re.search(r'(_cal\b|_temp\b|hex|0x)', n):
            flag.append('BANNED?')
        print(r['lookup'], n, len(b), len(n), hits, flag)
