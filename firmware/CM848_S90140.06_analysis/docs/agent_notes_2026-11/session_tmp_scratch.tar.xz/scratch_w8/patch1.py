reps_all = {
    '/tmp/scratch_w8/gen_a.py': [('9211-9219', '9195-9203'), ('.cpp 9285-9291', '.cpp 9300-9314'), ('.cpp 9273-9320', '.cpp 9300-9399')],
    '/tmp/scratch_w8/gen_b.py': [('and every init-to-2 word of this kind in the binary is the cached axis offset of a lookupTableInterpolation.',
                                  'and the init-to-2 words around it (0x3fa10a-0x3fa112, 0x3fa896-0x3fa89a, 0x3faa7a-0x3faa82) are all cached axis offsets passed to lookupTableInterpolation / cm848_dualAxisTableInterpolation.')],
}
for p, reps in reps_all.items():
    s = open(p).read()
    for a, b in reps:
        print(p, repr(a[:40]), s.count(a))
        s = s.replace(a, b)
    open(p, 'w').write(s)
