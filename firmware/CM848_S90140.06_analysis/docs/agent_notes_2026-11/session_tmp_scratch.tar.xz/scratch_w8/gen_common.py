import csv, json, re, sys
FW = '/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/'
OUT = FW + 'CM848_S90140.06_analysis/output/'
OUT550 = FW + 'CM550_J90350.00_analysis/output/'

def read_globals():
    gv = {}
    for row in csv.reader(open(OUT + 'global_variables.csv')):
        if row and row[0].startswith('0x') and len(row) >= 2:
            gv[int(row[0], 16)] = row
    return gv

GV = read_globals()
FUNCS = {}
for row in csv.reader(open(OUT + 'function_renames.csv')):
    if row and row[0].startswith('0x'):
        FUNCS[int(row[0], 16)] = row

ROWS = []

def add(**kw):
    ROWS.append(kw)

def check_old(addr, old):
    r = GV.get(addr)
    assert r is not None and r[1] == old, f'0x{addr:08x}: expected {old!r}, csv has {r[1] if r else None!r}'

def G(addr, old, new, evidence, new_type=None, verdict='confirmed'):
    check_old(addr, old)
    d = {'kind': 'global', 'address': f'0x{addr:08x}', 'old': old, 'verdict': verdict}
    if new:
        d['new'] = new
    if new_type:
        d['new_type'] = new_type
    d['evidence'] = evidence
    ROWS.append(d)

def NG(addr, new, typ, evidence):
    assert addr not in GV or not GV[addr][1] or GV[addr][1].endswith('+2'), f'0x{addr:08x} already has a row {GV.get(addr)}'
    ROWS.append({'kind': 'new_global', 'address': f'0x{addr:08x}', 'new': new, 'type': typ, 'evidence': evidence})

def F(addr, old, new, plate, evidence, verdict='confirmed'):
    r = FUNCS.get(addr)
    assert r is not None and r[1] == old, f'func 0x{addr:08x}: expected {old!r}, csv has {r[1] if r else None!r}'
    ROWS.append({'kind': 'function', 'address': f'0x{addr:08x}', 'old': old, 'verdict': verdict, 'new': new,
                 'plate_comment': plate, 'evidence': evidence})

def NOTE(text):
    ROWS.append({'kind': 'note', 'text': text})
