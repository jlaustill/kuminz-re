import re

def patch(path, reps):
    s = open(path).read()
    for a, b in reps:
        assert s.count(a) == 1, (path, a[:60], s.count(a))
        s = s.replace(a, b)
    open(path, 'w').write(s)

# ---------------------------------------------------------------- gen_c: condensation family rewritten
s = open('/tmp/scratch_w8/gen_c.py').read()
i0 = s.index('cond = [')
i1 = s.index("NG(0x40a5e8")
new_block = '''E2M_ANCHOR = ("E2M (corroboration): anchoring 0x40a5d0 on EMO_Cooler_Cond_Adj_Off_Gain (0x01196F1A) lines up 0x40a5ba-0x40a5ea with 0x01196F04-0x01196F34 by name, width and unit "
              "(AECD_Active, AECD_Possible, Cond_Count (4 bytes), Delta_PP, the four Adj gains, Delta_T, Incrt (4 bytes) cooler / intake, Satur_PP cooler / intake, Cndst_Mass_Rate cooler / intake). "
              "None of these words is in the time-shared window (all 0x4065xx / 0x40axxx).")
cond = [
    ('fuel_demand_boost_compensation_accumulated', 'egr_cooler_condensation_count',
     "CODE: dword accessed only by fuel_demand_boost_compensate (loads 0x50506c / 0x505094 / 0x5050b0, store 0x5050ac): the accumulator that follows the step, forced to 0 while fuel_cold_start_phase3_compensation_enable_flag is 0. E2M: EMO_Cooler_Cond_Count (4 bytes, 0x01196F08)."),
    ('fuel_demand_boost_compensation_limit', 'egr_cooler_condensation_count_maximum',
     "CODE: ROM-copied dword (0x406552, outside the EEPROM mirror so no _cal), one load (0x505024) in fuel_demand_boost_compensate, no writer: the upper bound of the count and the threshold of the at-limit flag. E2M: C_EMO_Cooler_Cond_Max_Count (4 bytes, 0x01196E04) 'Limit of Cumulative Cooler condensation'; the calibration block 0x406552 / 0x406566 lines up with 0x01196E04 / 0x01196E18 (C_EMO_Condensation_AECD_Margin) by the +0x14 spacing."),
    ('fuel_demand_boost_compensation_step', 'egr_cooler_condensation_increment',
     "CODE: dword, one store (0x50501c) in fuel_demand_boost_compensate and no load (the value stays in a register): signed step = gain x |difference| / 640 added to or subtracted from the count. E2M: EMO_Cooler_Cond_Incrt (4 bytes, 0x01196F26)."),
    ('fuel_demand_boost_compensation_step_rate_negative', 'egr_cooler_condensation_adjusted_off_gain',
     "CODE: loaded in fuel_demand_boost_compensate (0x504fe0) as the step rate when the vapor pressure difference is not positive, and STORED by a third function, fuel_coldStart_quantityScale_update (0x505170), so it is a computed value, not a calibration word. E2M: EMO_Cooler_Cond_Adj_Off_Gain 'EGR cooler condensation Off gain after adjusted by total fueling' (0x01196F1A); the calibration gain is C_EMO_Cooler_Cond_Off_Gain (0x01196E08)."),
    ('fuel_demand_boost_compensation_step_rate_positive', 'egr_cooler_condensation_adjusted_on_gain',
     "CODE: loaded in fuel_demand_boost_compensate (0x504f70) as the step rate when the vapor pressure difference is positive, STORED by fuel_coldStart_quantityScale_update (0x50519c): a computed value. E2M: EMO_Cooler_Cond_Adj_On_Gain (0x01196F1C); the intake twins 0x40a5d4 / 0x40a5d6 (fuel_demand_blend_compensation_step_rate_*) are EMO_Intake_Cond_Adj_Off / On_Gain, used by fuel_demand_blend_compensate (not read)."),
    ('fuel_demand_boost_compensation_direction_flag', 'egr_cooler_condensation_increasing_flag',
     "CODE: stored 0 (0x504f40) / 1 (0x504fb0) and loaded (0x505048) only in fuel_demand_boost_compensate: 1 when the vapor pressure difference is positive; it selects the on gain and the count direction. E2M: EMO_Cooler_Cond_AECD_Possible 'Condensation for EGR is predicted and AECD triggering is possible' (0x01196F06) at this offset (the code name describes the use)."),
    ('fuel_demand_boost_compensation_at_limit_flag', 'egr_cooler_condensation_count_at_limit_flag',
     "CODE: stored in fuel_demand_boost_compensate (0x5050d4: 1 when the count reaches its maximum, 0 when it returns to 0) and loaded by fuel_coldStart_quantityScale_update (0x505214), the OR that feeds fuel_coldStart_compensation_at_limit_flag and so bit 0x80 of combustion_status_flags (EGR-off request). E2M: EMO_Cooler_Cond_AECD_Active 'Condensation AECD for EGR is currently permitting higher emissions levels' (0x01196F04)."),
    ('boost_demand_ema_decay_coeff', 'egr_cooler_saturation_vapor_pressure',
     "CODE: one store (0x504d7c) in fuel_demand_boost_ema_compensate and no load in either bank: the water saturation vapor pressure at coolant_temperature_selected (a table lookup result, not a decay coefficient). E2M: EMO_Cooler_Satur_PP (IN_HG, 0x01196F2E) at this offset; the next word 0x40a5e6 (blend_demand_ema_filtered_decay_coeff) is EMO_Intake_Satur_PP."),
]
missing = []
for old, new, ev in cond:
    if old not in BYNAME:
        missing.append(old)
        continue
    a = addr_of(old)
    assert not (0x3f9800 <= a <= 0x3fdb30), old
    if 0x3fd482 <= a <= 0x3feec1:
        new = new + '_cal'
    G(a, old, new, ev + ' ' + E2M_ANCHOR + " MEDIUM-HIGH confidence (the e2m role and the code role agree on sign, width and neighbours; the 'cooler' scope rests on the coolant temperature input and the e2m cooler block).")
if missing:
    NOTE('Not found in global_variables.csv by name (skipped): ' + ', '.join(missing))
NOTE("0x40a61c CONSUMERS - LEFT UNRENAMED, with the reason: fuel_demand_compensation_base_setpoint (0x406566, ROM-copied word, only read by fuel_demand_boost_compensate / fuel_demand_blend_compensate) lines up with C_EMO_Condensation_AECD_Margin (0x01196E18, DEG_F) by the +0x14 spacing from the Max_Count word, but the e2m also has C_EMO_Cooler_Cond_Margin (0x01196E02) and the formula 'Coolant - Exhaust_Saturation_Tmptr - margin' needs both, so which one it is is not settled; fuel_boost_compensation_target (0x40a72c) is a RAM word written by cm848_blendBoostAndThrottleFuelDemand (a computed temperature, probably the exhaust saturation temperature) - the producer was not read.")

'''
s = s[:i0] + new_block + s[i1:]
s = s.replace("'i16',\n   \"CODE: store-only (sth 0x504ee8)", "'word',\n   \"CODE: store-only (sth 0x504ee8)")
s = s.replace("'i16',\n   \"CODE: store-only (sth 0x504f28)", "'word',\n   \"CODE: store-only (sth 0x504f28)")
s = s.replace("so the type is signed. E2M", "so the VALUE is signed (type kept word: store-only, no load instruction proves the sign; i16 would be correct). E2M")
s = s.replace("so it is signed (dump 9264). E2M", "so the value can be signed (type kept word: store-only; i16 would be correct). Dump 9264. E2M")
open('/tmp/scratch_w8/gen_c.py', 'w').write(s + "\nimport gen_d\n")

# ---------------------------------------------------------------- gen_b fixes
sb = open('/tmp/scratch_w8/gen_b.py').read()
# drop the MODE_SHUTDOWN enum_member row
i0 = sb.index("ROWS.append({'kind': 'enum_member', 'enum': 'ENGINE_OPERATING_MODE', 'old': 'MODE_SHUTDOWN'")
i1 = sb.index("\n", i0)
sb = sb[:i0] + sb[i1 + 1:]
# 0x3fd910 as a note
i0 = sb.index("ROWS.append({'kind': 'global', 'address': '0x003fd910'")
j = sb.index("'evidence': \"SKIP, no name. ", i0)
k = sb.index("\"})\n", j) if "\"})\n" in sb[j:] else None
text_start = j + len("'evidence': \"")
text_end = sb.index("\"})", text_start)
txt = sb[text_start:text_end]
sb = sb[:i0] + 'NOTE("0x003fd910 (no row; EEPROM 0x48e): UNCERTAIN, ' + txt.replace('"', "'") + '")' + sb[text_end + 3:]
# 0x3fa114/16 wording
a = "All e2m ASG tables (friction fuel, alternate friction fuel, coolant adjustment, droop, alternate droop, gear ratio, throttle prefilter) are already accounted for by other cache words or by the plain loop in cm848_blendGovernorTuningSets, so the family of the two spare caches is not known: the generic name says only what is proven (a lookup cache this build never uses)."
assert sb.count(a) == 1
sb = sb.replace(a, "The family of the two spare caches is NOT known (the ASG tables of the e2m were not all matched to cache words): the generic name says only what is proven. Both words still hold the init value 2 in the dump, while a cache that is used has moved (0x40a8a7 = 8, 0x3fa8a6 = 2 only because its table is not exercised) - consistent with 'never used', not proof. LOWEST-CONFIDENCE rename of this file.")
a = "MEDIUM confidence on 'lookup cache'; the old 'diag state' is wrong in any case."
assert sb.count(a) == 1
sb = sb.replace(a, "Confidence on 'lookup cache' is only medium-low; the old 'diag state' is wrong in any case.")
# 0x40affe wording
i0 = sb.index("G(0x40affe, 'governor_proportional_gain', 'engine_operating_mode_fuel_demand',")
i1 = sb.index("G(0x40b000, 'engine_operating_mode', None,")
sb = sb[:i0] + '''G(0x40affe, 'governor_proportional_gain', 'engine_operating_mode_fuel_demand',
  "CODE: one writer per operating mode (modes 7 / 2 / 30 the governor result, sth 0xfa9c; mode 8 cm848_calculateDualAxisFuelLimit, sth 0x1e85c; mode 1 etc1_torque_limit_calc, sth 0x428cc; mode 5 governor_proportional_gain_cal, sth 0x42910; mode 6 pedal_fault_mode_fuel_demand_ramp, sth 0x50da44). The unit comes from the consumer: cm848_calculateDriverDemandPercentTorque takes the copy governor_pid_t.proportional_gain as driver_demand_fuel_quantity (mm3 per stroke, scaled to percent torque) and cm848_updateGovernorFromProtection copies it on; further readers cm848_processEngineRetarderTsc1Request and governor_resetModeStateOnCondition. It is not a gain. Same misnomer family (not renamed here): governor_proportional_gain_calc (0x40a887, the mode 8 result) and governor_proportional_gain_cal (0x3fd8b4, EEPROM 0x432, the mode 5 value). ")
''' + sb[i1:]
open('/tmp/scratch_w8/gen_b.py', 'w').write(sb)

# ---------------------------------------------------------------- gen_a fixes
sa = open('/tmp/scratch_w8/gen_a.py').read()
assert sa.count('DAT_00808036-0x8003c') == 1
sa = sa.replace('DAT_00808036-0x8003c', 'DAT_00808036-0x80803c')
for old in ["'all_speed_governor_throttle_droop_gain_1',\n  \"CODE: write-only", "'all_speed_governor_throttle_droop_gain_2',\n  \"CODE: write-only"]:
    assert sa.count(old) == 1, old
sa = sa.replace("E2M: ASG_Throttle_Droop_1 'ASG throttle droop gain 1' (0x01107A08, Q10 1/1024) at this offset;", "E2M: ASG_Throttle_Droop_1 'ASG throttle droop gain 1' (0x01107A08, Q10 1/1024) at this offset (the 'droop gain' vocabulary is the e2m's; whether to use it for the live pair 0x40a250 / 0x40a252 as well is the owner's decision, see the e2m alignment note (3); MEDIUM confidence);")
sa = sa.replace("E2M: ASG_Throttle_Droop_2 'ASG throttle droop gain 2' (0x01107A0A, Q10) at this offset. ", "E2M: ASG_Throttle_Droop_2 'ASG throttle droop gain 2' (0x01107A0A, Q10) at this offset; same caveat as throttle_droop_gain_1 (owner's decision, MEDIUM confidence). ")
open('/tmp/scratch_w8/gen_a.py', 'w').write(sa)
print('patched')
