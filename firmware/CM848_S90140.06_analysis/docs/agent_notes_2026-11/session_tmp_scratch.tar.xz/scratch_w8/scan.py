#!/usr/bin/env python3
"""Whole-binary access scan (ROM + Bank 2): every load/store with a computable effective address and
every register-built address (lis/addi/ori) landing in RAM. Cached in /tmp/scratch_w8/scan.json."""
import os, re, sys, json, subprocess, bisect
sys.path.insert(0, '/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/scripts')
import disasm_func as D

CACHE = '/tmp/scratch_w8/scan.json'
LD_ST = re.compile(r"^r(\d+),(-?\d+)\(r(\d+)\)$")
LD_X = re.compile(r"^r(\d+),r(\d+),r(\d+)$")
M = 0xffffffff
RAMLO, RAMHI = 0x3f9800, 0x414290


def bank_lines(binary, vma):
    cmd = ["powerpc-linux-gnu-objdump", "-D", "-b", "binary", "-m", "powerpc", "-EB",
           f"--adjust-vma={hex(vma)}", binary]
    return subprocess.run(cmd, capture_output=True, text=True).stdout.splitlines()


def build():
    funcs = D.function_table()
    starts = [a for a, _ in funcs]
    names = {a: n for a, n in funcs}
    starts_set = set(starts)

    def fname(pc):
        i = bisect.bisect_right(starts, pc) - 1
        return names[starts[i]] if i >= 0 else '?'

    accesses = []   # (ea, kind, width, pc, mnem, func, text)
    builds = []     # (value, pc, func, text)  register-built addresses in RAM range
    for binary, vma in ((D.ROM, 0), (D.FLASH2, 0x500000)):
        lines = bank_lines(binary, vma)
        regs = {0: 0}
        for ln in lines:
            m = D.ASM_LINE.match(ln)
            if not m:
                continue
            pc = int(m.group(1), 16)
            if pc in starts_set:
                regs = {0: 0}
            mnem, ops = m.group(2), m.group(3).replace(" ", "")
            ops = ops.split('#')[0].split('<')[0]
            op = ops.split(",")
            w = D.WIDTH.get(mnem)
            if w:
                lm = LD_ST.match(ops)
                xm = LD_X.match(ops) if lm is None else None
                rd = None
                kind = 'store' if mnem.startswith('st') else 'load'
                if lm:
                    rd, disp, ra = int(lm.group(1)), int(lm.group(2)), int(lm.group(3))
                    b = D.register_base(regs, ra)
                    if b is not None:
                        accesses.append(((b + disp) & M, kind, w, pc, mnem, fname(pc), ln.strip()))
                elif xm:
                    rd, ra, rb = int(xm.group(1)), int(xm.group(2)), int(xm.group(3))
                    va, vb = D.register_base(regs, ra), D.register_base(regs, rb)
                    if va is not None and vb is not None:
                        accesses.append(((va + vb) & M, kind, w, pc, mnem + '(idx)', fname(pc), ln.strip()))
                    elif va is not None or vb is not None:
                        accesses.append((va if va is not None else vb, kind, w, pc, mnem + '(idx-base)', fname(pc), ln.strip()))
                if rd is not None and not mnem.startswith('st'):
                    regs.pop(rd, None)
                continue
            D.step_address_registers(regs, mnem, op)
            if mnem in ('addi', 'ori', 'addic') and len(op) == 3:
                v = regs.get(int(op[0][1:]))
                if v is not None and RAMLO <= v < RAMHI:
                    builds.append((v, pc, fname(pc), ln.strip()))
    return accesses, builds


def load():
    if os.path.exists(CACHE):
        return json.load(open(CACHE))
    r = build()
    json.dump(r, open(CACHE, "w"))
    return r


def query(lo, hi=None):
    """Accesses and register builds with EA in [lo, hi] (hi defaults to lo)."""
    hi = lo if hi is None else hi
    acc, bld = load()
    a = [x for x in acc if lo <= x[0] <= hi]
    b = [x for x in bld if lo <= x[0] <= hi]
    return sorted(a, key=lambda x: (x[0], x[3])), sorted(b, key=lambda x: (x[0], x[1]))


if __name__ == '__main__':
    if len(sys.argv) == 1:
        acc, bld = load()
        print(len(acc), 'accesses', len(bld), 'builds')
    else:
        lo = int(sys.argv[1], 16)
        hi = int(sys.argv[2], 16) if len(sys.argv) > 2 else None
        a, b = query(lo, hi)
        for x in a:
            print(f"0x{x[0]:08x} {x[1]:5s} {x[2]:5s} pc=0x{x[3]:06x} {x[4]:10s} {x[5]}")
        for x in b:
            print(f"BUILD 0x{x[0]:08x} pc=0x{x[1]:06x} {x[2]}  {x[3]}")
