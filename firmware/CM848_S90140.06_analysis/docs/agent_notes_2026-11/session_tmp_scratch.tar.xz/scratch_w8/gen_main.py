import json, re, csv, sys
sys.path.insert(0, '/tmp/scratch_w8')
import gen_common as C
import gen_a, gen_b, gen_c
from gen_common import ROWS, OUT, OUT550, GV, FUNCS

RESULT = '/home/linux/.claude/jobs/d55ae3c6/tmp/renames/result_W8_governor_combustion.jsonl'

# ---- existing name sets
func_names = {r[1] for r in FUNCS.values()}
glob_names = {r[1] for r in GV.values() if r[1]}
arr_names = set()
try:
    for r in csv.reader(open(OUT + 'arrays.csv')):
        if r and not r[0].startswith('#'):
            arr_names.update(x for x in r[:3] if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', x or ''))
except FileNotFoundError:
    pass
enum_members = set()
for r in csv.reader(open(OUT + 'enums.csv')):
    if r and not r[0].startswith('#') and len(r) >= 3:
        enum_members.add(r[2])
func_names550 = set()
for r in csv.reader(open(OUT550 + 'function_renames.csv')):
    if r and r[0].startswith('0x') and len(r) >= 2:
        func_names550.add(r[1])

errors = []
seen = {}
def tokens(name):
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', name)
    return [t.lower() for t in s.split('_') if t]

for i, row in enumerate(ROWS):
    k = row['kind']
    new = row.get('new')
    if k in ('function', 'global', 'new_global') and new:
        if new in seen:
            errors.append(f'duplicate new {new}: rows {seen[new]} and {i}')
        seen[new] = i
        if k == 'function':
            if new in func_names or new in func_names550:
                errors.append(f'function name exists: {new}')
        else:
            if new in glob_names or new in func_names or new in arr_names:
                errors.append(f'global name exists: {new}')
        if '0x' in new or re.search(r'(^|_)[0-9a-f]{5,}(_|$)', new):
            errors.append(f'hex in name {new}')
        if 'init' in tokens(new):
            errors.append(f'init token in {new}')
        if k != 'function' and not re.fullmatch(r'[a-z][a-z0-9_]*', new):
            errors.append(f'not snake_case: {new}')
        if k == 'function' and not re.fullmatch(r'(cm848_)?[a-z][A-Za-z0-9]*', new):
            errors.append(f'function name shape: {new}')
        if 'protection' in tokens(new) and len(tokens(new)) <= 3:
            errors.append(f'bare protection: {new}')
        if k in ('global', 'new_global'):
            a = int(row['address'], 16)
            in_eeprom = 0x3fd482 <= a <= 0x3feec1
            if new.endswith('_cal') and not in_eeprom:
                errors.append(f'_cal outside the EEPROM mirror: {new} @0x{a:x}')
    if k == 'enum_member' and row.get('new'):
        n = row['new']
        if n in enum_members:
            errors.append(f'enum member exists: {n}')
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', n):
            errors.append(f'enum member shape: {n}')
    for fld in ('evidence', 'text', 'plate_comment'):
        v = row.get(fld)
        if v is not None and not isinstance(v, str):
            errors.append(f'row {i} {fld} not a string')

with open(RESULT, 'w') as f:
    for row in ROWS:
        f.write(json.dumps(row, ensure_ascii=True) + '\n')

# reload and re-verify
n = 0
kinds = {}
for line in open(RESULT):
    r = json.loads(line)
    n += 1
    key = (r['kind'], r.get('verdict'))
    kinds[key] = kinds.get(key, 0) + 1
print('rows', n, 'arrays names loaded', len(arr_names), 'glob', len(glob_names), 'func', len(func_names))
for k, v in sorted(kinds.items(), key=lambda kv: str(kv[0])):
    print(k, v)
print('ERRORS' if errors else 'no validation errors')
for e in errors:
    print('  ', e)
