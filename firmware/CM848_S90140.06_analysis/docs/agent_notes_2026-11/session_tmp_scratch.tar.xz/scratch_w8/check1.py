import csv, sys, struct
sys.path.insert(0, '/tmp/scratch_w8')
import scan
FW = '/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/'
gv = {}
for row in csv.reader(open(FW + 'global_variables.csv')):
    if row and row[0].startswith('0x') and len(row) >= 3:
        gv[int(row[0], 16)] = row
e2m = {}
for row in csv.reader(open(FW + 'e2m_parameters.csv')):
    if len(row) >= 7 and row[2].startswith('0x'):
        e2m.setdefault(int(row[2], 16), []).append(row)

def show(cm, e2):
    g = gv.get(cm)
    gname = g[1] if g else '(no row)'
    gtype = g[2] if g else ''
    acc, _ = scan.query(cm)
    kinds = sorted(set((a[1][0], a[4]) for a in acc))
    e = e2m.get(e2, [])
    en = e[0][0] if e else '(none)'
    eu = (e[0][4] + ' x' + e[0][5]) if e else ''
    print(f"0x{cm:06x} {gname[:58]:58s} {gtype:6s} {str(kinds)[:50]:50s} | e2m 0x{e2:08x} {en:34s} {eu}")

print('--- restore block anchor 0x40a216 <-> 0x0111700C')
for k in range(0, 27):
    show(0x40a216 + 2 * k, 0x0111700C + 2 * k)
print('--- live reset states anchor 0x40a20a <-> 0x01117000')
for k in range(0, 6):
    show(0x40a20a + 2 * k, 0x01117000 + 2 * k)
print('--- live ASG block anchor 0x40a24c <-> 0x01107A00')
for k in range(0, 12):
    show(0x40a24c + 2 * k, 0x01107A00 + 2 * k)
print('--- existing rows 0x5c314-0x5c332')
for a in range(0x5c300, 0x5c340, 2):
    if a in gv:
        print(hex(a), gv[a][:3])
print('--- engine_crank_state_t.run_state 0x40b80a')
print(gv.get(0x40b80a), gv.get(0x40b808))
