import csv, sys
sys.path.insert(0, '/tmp/scratch_w8')
import scan
FW = '/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/'
gv = {}
for row in csv.reader(open(FW + 'global_variables.csv')):
    if row and row[0].startswith('0x') and len(row) >= 3:
        gv[int(row[0], 16)] = row
e2m = {}
for row in csv.reader(open(FW + 'e2m_parameters.csv')):
    if len(row) >= 7 and row[2].startswith('0x'):
        e2m.setdefault(int(row[2], 16), []).append(row)

def show(cm, e2):
    g = gv.get(cm)
    gname = g[1] if g else '(no row)'
    gtype = g[2] if g else ''
    acc, _ = scan.query(cm)
    kinds = sorted(set((a[1][0], a[4]) for a in acc))
    fn = sorted(set(a[5] for a in acc))
    e = e2m.get(e2, [])
    en = e[0][0] if e else '(none)'
    eu = (e[0][4] + ' x' + e[0][5]) if e else ''
    print(f"0x{cm:06x} {gname[:50]:50s} {gtype:6s} {str(kinds)[:34]:34s} {str(fn)[:60]:60s}| e2m 0x{e2:08x} {en:34s} {eu}")

print('--- shadow block 0x40a1dc <-> 0x01107C32')
for k in range(0, 10):
    show(0x40a1dc + 2 * k, 0x01107C32 + 2 * k)
print('--- rows named fuel_pid_ / fuel_trim_ / governor_fuel_demand_tracking_limit_cal')
for a, r in sorted(gv.items()):
    if r[1].startswith('fuel_pid_') or r[1].startswith('fuel_trim_') or r[1] == 'governor_fuel_demand_tracking_limit_cal':
        print(f"0x{a:06x} {r[1]} {r[2]}")
