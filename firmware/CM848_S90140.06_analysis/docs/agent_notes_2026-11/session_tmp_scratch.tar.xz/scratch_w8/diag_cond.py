import sys
sys.path.insert(0, '/tmp/scratch_w8')
import gen_common as C
import scan
names = ['fuel_demand_boost_compensation_accumulated', 'fuel_demand_boost_compensation_limit', 'fuel_demand_boost_compensation_step',
         'fuel_demand_boost_compensation_step_rate_negative', 'fuel_demand_boost_compensation_step_rate_positive',
         'fuel_demand_boost_compensation_direction_flag', 'fuel_demand_boost_compensation_at_limit_flag', 'boost_demand_ema_decay_coeff',
         'fuel_demand_compensation_base_setpoint', 'fuel_boost_compensation_target', 'fuel_boost_map_correction_weighted',
         'fuel_demand_blend_compensation_step_rate_negative', 'fuel_demand_blend_compensation_step_rate_positive']
by = {}
for a, r in C.GV.items():
    by.setdefault(r[1], []).append(a)
for n in names:
    for a in by.get(n, []):
        acc, bld = scan.query(a, a + 3)
        sig = sorted(set((x[0], x[1], x[2], x[3] and hex(x[3]), x[5]) for x in acc))
        tshare = 0x3f9800 <= a <= 0x3fdb30
        print(f"0x{a:08x} {n} type={C.GV[a][2]} timeshared={tshare}")
        for x in sig:
            print('     ', hex(x[0]), x[1], x[2], x[3], x[4])
        for b in bld:
            print('      BUILD', hex(b[0]), hex(b[1]), b[2])
    if n not in by:
        print('MISSING', n)
