#!/usr/bin/env python3
"""Read-only helper: find address BUILDS (register values after lis/addi/ori/li/mr) inside given ranges,
whether or not a load/store follows - catches pointers passed to copy routines."""
import bisect
import re
import sys

sys.path.insert(0, "/tmp/w7")
sys.path.insert(0, "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/scripts")
import disasm_func as D
import scan

ranges = []
for a in sys.argv[1:]:
    lo, hi = a.split("-")
    ranges.append((int(lo, 16), int(hi, 16)))

funcs = D.function_table()
starts = [a for a, _ in funcs]
names = {a: n for a, n in funcs}
dis = scan.load_dis()
seen = {}
for bank, lines in dis.items():
    regs = {0: 0}
    cur = None
    for ln in lines:
        m = D.ASM_LINE.match(ln)
        if not m:
            continue
        addr = int(ln.split(":")[0].strip(), 16)
        i = bisect.bisect_right(starts, addr) - 1
        fa = starts[i] if i >= 0 else None
        if fa != cur:
            cur = fa
            regs = {0: 0}
        mnem, ops = m.group(2), m.group(3).replace(" ", "")
        op = ops.split(",")
        if mnem in ("addi", "addic", "ori", "li", "mr", "lis") and len(op) >= 2 and re.fullmatch(r"r\d+", op[0]):
            D.step_address_registers(regs, mnem, op)
            v = regs.get(int(op[0][1:]))
            if v is not None and mnem != "lis":
                for lo, hi in ranges:
                    if lo <= v <= hi:
                        seen.setdefault((names.get(fa, "?"), hex(v)), []).append(hex(addr))
            continue
        w = D.WIDTH.get(mnem)
        if w:
            lm = re.match(r"^r(\d+),(-?\d+)\(r(\d+)\)$", ops)
            if lm:
                rd = int(lm.group(1))
                if not mnem.startswith("st"):
                    regs.pop(rd, None)
            continue
        D.step_address_registers(regs, mnem, op)
for (fn, v), where in sorted(seen.items(), key=lambda x: x[0][1]):
    print(fn, v, where[:4])
