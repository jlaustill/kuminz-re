#!/usr/bin/env python3
"""Read-only helper: list CSV rows whose comments mention old (pre-rename) names of the HSG block."""
import re
import sys

OUT = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/"
names = sys.argv[1:]
pats = {n: re.compile(r'(?<![A-Za-z0-9_])' + re.escape(n) + r'(?![A-Za-z0-9_])') for n in names}
for fn in ("global_variables.csv", "function_renames.csv", "structure_definitions.csv", "enums.csv",
           "arrays.csv", "constants.csv", "local_variables.csv", "function_definitions.csv"):
    try:
        lines = open(OUT + fn, errors="replace").read().split("\n")
    except FileNotFoundError:
        continue
    hits = {}
    for i, ln in enumerate(lines, 1):
        cols = ln.split(",", 2)
        for n, p in pats.items():
            if p.search(ln):
                if len(cols) > 1 and cols[1] == n:
                    # the row's own name column: only count mentions in the comment part
                    rest = cols[2] if len(cols) > 2 else ""
                    if not p.search(rest):
                        continue
                hits.setdefault(cols[0], set()).add(n)
    if hits:
        print("==", fn, len(hits), "rows mention old names in their text")
        for a, s in sorted(hits.items()):
            print("  ", a, sorted(s))
