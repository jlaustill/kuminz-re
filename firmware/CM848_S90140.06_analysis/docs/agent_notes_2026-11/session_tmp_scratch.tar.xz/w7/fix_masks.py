#!/usr/bin/env python3
"""Rewrite bit-number wording to mask wording inside the result generator (my own /tmp file)."""
P = "/tmp/w7/gen_result.py"
s = open(P).read()
repl = [
    ("fuel_mode_status_flags bits 8 / 16 / 512 are all clear", "fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 are all clear"),
    ("dump: flags 0x402 = bit 2 set -> EGR off requested;", "dump: flags 0x402, mask 2 set -> EGR off requested;"),
    ("(combustion_override_and_estimation_enable_flags_cal bit 7 set and bit 6 set; e2m CBR_FULL_USER_OVERRIDE)", "(combustion_override_and_estimation_enable_flags_cal mask 0x80 set and mask 0x40 set; e2m CBR_FULL_USER_OVERRIDE)"),
    ("(bit 7 set and bit 6 clear; e2m CBR_SINGLE_USER_OVERRIDE)", "(mask 0x80 set and mask 0x40 clear; e2m CBR_SINGLE_USER_OVERRIDE)"),
    ("selected when fuel_mode_status_flags bit 8 / 16 / 512 is set; EGR is requested off", "selected when any of fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 is set; EGR is requested off"),
    ("when fuel_mode_status_flags bit 8, 16 or 512 is set (its only reader", "when any of fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 is set (its only reader"),
    ("the sensor validation word gives bit 8 from DAT_0040a43c, 4 from DAT_0040a43e and 0x100 from fuel_demand_active_state_flag", "the sensor validation word gives mask 0x08 from DAT_0040a43c, 0x04 from DAT_0040a43e and 0x100 from fuel_demand_active_state_flag"),
    ("bit 1 cold start phase 2.6 fuel mode (cold_start_phase26_fuel_mode_flag), bit 2 set when NOT in cold start phase 2.6 or 3 (always true warm: this is why EGR is requested off here), bit 0x80 phase 3 count met or compensation at limit, bits 0x20 / 0x40 from injection_timing_cylinder_check_flags, bits 4 / 8 / 0x100 from the sensor validation word",
     "mask 1 cold start phase 2.6 fuel mode (cold_start_phase26_fuel_mode_flag), mask 2 set when NOT in cold start phase 2.6 or 3 (always true warm: this is why EGR is requested off here), mask 0x80 phase 3 count met or compensation at limit, masks 0x20 / 0x40 from injection_timing_cylinder_check_flags, masks 0x04 / 0x08 / 0x100 from the sensor validation word"),
    ("only when governor_feature_config_flags bit 0x40 is set", "only when governor_feature_config_flags mask 0x40 is set"),
    ("(bit 0x400 is not tested by the chi selection)", "(mask 0x400 is not tested by the chi selection)"),
    ("Bits 0x10 and 0x200 have no writer at all", "Masks 0x10 and 0x200 have no writer at all"),
    ("or WORD_0040bdae when sensor_generic_fault_status has bit 2 set (and sets", "or WORD_0040bdae when sensor_generic_fault_status mask 2 is set (and sets"),
    ("read by cm848_mainLoop_step_3 when the channel fault status has bit 2 set.", "read by cm848_mainLoop_step_3 when the channel fault status mask 2 is set."),
    ("Code: cm848_selectHighSpeedGovernorGainSet (bit 0 of system_feature_config_flags set) increments it", "Code: cm848_selectHighSpeedGovernorGainSet (system_feature_config_flags mask 1 set) increments it"),
    ("5 (engine_mode_control_flags bit 0, cm848_setEngineOperatingMode5)", "5 (engine_mode_control_flags mask 1, cm848_setEngineOperatingMode5)"),
]
for a, b in repl:
    n = s.count(a)
    print(n, a[:70])
    s = s.replace(a, b)
open(P, "w").write(s)
