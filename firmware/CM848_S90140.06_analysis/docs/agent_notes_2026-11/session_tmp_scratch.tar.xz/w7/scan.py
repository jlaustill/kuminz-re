#!/usr/bin/env python3
"""Whole-binary access scanner (read-only research helper, lives in /tmp).
Finds every load/store whose effective address (tracked through lis/addi/ori/li/mr within a function window)
falls in [lo, hi) for each target range. Unlike xref_addr.py it does NOT depend on the names the .cpp prints."""
import sys, os, re, subprocess, json, bisect
sys.path.insert(0, "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/scripts")
import disasm_func as D

CACHE = "/tmp/w7/dis_cache.json"


def load_dis():
    if os.path.exists(CACHE):
        return json.load(open(CACHE))
    out = {}
    for name, binary, vma, lo, hi in (("rom", D.ROM, 0x0, 0x0, 0x70000),
                                      ("flash2", D.FLASH2, 0x500000, 0x500000, 0x540000)):
        cmd = ["powerpc-linux-gnu-objdump", "-D", "-b", "binary", "-m", "powerpc", "-EB",
               f"--adjust-vma={hex(vma)}", f"--start-address={hex(lo)}", f"--stop-address={hex(hi)}", binary]
        lines = subprocess.run(cmd, capture_output=True, text=True).stdout.splitlines()
        out[name] = lines
    json.dump(out, open(CACHE, "w"))
    return out


def scan(ranges):
    """ranges: list of (lo, hi, label). Returns hits (func, insn_addr, kind, width, text, ea, label)."""
    funcs = D.function_table()
    starts = [a for a, _ in funcs]
    names = {a: n for a, n in funcs}
    dis = load_dis()
    hits = []
    ld_st = re.compile(r"^r(\d+),(-?\d+)\(r(\d+)\)$")
    ld_x = re.compile(r"^r(\d+),r(\d+),r(\d+)$")
    for bank, lines in dis.items():
        regs = {0: 0}
        cur_func = None
        for ln in lines:
            m = D.ASM_LINE.match(ln)
            if not m:
                continue
            addr = int(ln.split(":")[0].strip(), 16)
            i = bisect.bisect_right(starts, addr) - 1
            fa = starts[i] if i >= 0 else None
            if fa != cur_func:
                cur_func = fa
                regs = {0: 0}
            mnem, ops = m.group(2), m.group(3).replace(" ", "")
            op = ops.split(",")
            w = D.WIDTH.get(mnem)
            if w:
                lm = ld_st.match(ops)
                xm = ld_x.match(ops) if lm is None else None
                rd = None
                ea = None
                if lm:
                    rd, disp, ra = int(lm.group(1)), int(lm.group(2)), int(lm.group(3))
                    b = D.register_base(regs, ra)
                    if b is not None:
                        ea = (b + disp) & 0xffffffff
                elif xm:
                    rd, ra, rb = int(xm.group(1)), int(xm.group(2)), int(xm.group(3))
                    va, vb = D.register_base(regs, ra), D.register_base(regs, rb)
                    if va is not None and vb is not None:
                        ea = (va + vb) & 0xffffffff
                if ea is not None:
                    for lo, hi, label in ranges:
                        if lo <= ea < hi:
                            kind = "store" if mnem.startswith("st") else "load"
                            hits.append((names.get(fa, "?"), addr, kind, w, ln.strip(), ea, label))
                if rd is not None and not mnem.startswith("st"):
                    regs.pop(rd, None)
                continue
            D.step_address_registers(regs, mnem, op)
    return hits


if __name__ == "__main__":
    ranges = []
    for a in sys.argv[1:]:
        if "-" in a:
            lo, hi = a.split("-")
            ranges.append((int(lo, 16), int(hi, 16), a))
        else:
            v = int(a, 16)
            ranges.append((v, v + 1, a))
    for h in scan(ranges):
        print(f"{h[6]:>14}  {h[0]:<58} {h[1]:#x} {h[2]:<5} {h[3]:<5} ea={h[5]:#x}  {h[4]}")
