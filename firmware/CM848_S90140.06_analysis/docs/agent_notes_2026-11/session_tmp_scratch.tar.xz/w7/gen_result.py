#!/usr/bin/env python3
"""Builds the wave 7 result JSONL (read-only research output) and validates old names against the CSVs."""
import csv
import json
import re
import sys

OUT = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/"
RESULT = "/home/linux/.claude/jobs/d55ae3c6/tmp/renames/result_W7_governor_combustion.jsonl"

rows = []


def note(text):
    rows.append({"kind": "note", "text": text})


def glob(address, old, verdict, new, evidence):
    r = {"kind": "global", "address": address, "old": old, "verdict": verdict}
    if new:
        r["new"] = new
    r["evidence"] = evidence
    rows.append(r)


def func(address, old, verdict, new, plate, evidence):
    r = {"kind": "function", "address": address, "old": old, "verdict": verdict}
    if new:
        r["new"] = new
    if plate:
        r["plate_comment"] = plate
    r["evidence"] = evidence
    rows.append(r)


TS = "Time-shared window: a whole-binary scan of ROM and Bank 2 (displacement, lis+addi and indexed forms) finds no access below 0x7F60 (first user at 0x1f30c or later), so no boot-ROM user."

# ---------------------------------------------------------------- 1. label problem 0x3fb54c / 0x3fb54e
note("LABEL PROBLEM 0x3fb54c / 0x3fb54e - DIAGNOSIS: the cause is the ROM-to-RAM thunk of the romramthunks build stage, NOT a wrong row, a wider type or a swapped label. (1) The boot ROM calls RAM 0x3fb54c once (mpc555_diagService25_executeFunction, bl at ROM 0x185c); RAM 0x3fb54c is the boot-kernel image of cm848_validateDiagnosticRequestLengthAndAuthorization (ROM 0x597c, RAM = 0x3F9800 + ROM - 0x3C30). ApplyRomToRamThunks.java therefore does listing.clearCodeUnits(0x3fb54c, 0x3fb54f) and creates a 4-byte thunk function over exactly those bytes. The thunk takes the name of the label at its entry (the row at 0x3fb54c), so the call prints engine_retarder_request_on_delay_counter(param_1) (.cpp line 1132); the word accesses AT the entry print with a leading underscore (_engine_retarder_request_on_delay_counter, cm848_driveEngineRetarderOutput, .cpp 42000-42024); the word accesses at 0x3fb54e, which lie INSIDE the 4-byte thunk body, print the same plain name (.cpp 41574-41642 in cm848_updateEngineRetarderEnableState and 42100 in cm848_initializeEngineRetarderRequestState), and the tc_lockup_disengage_state label never reaches the decompiler. (2) Before/after proof with the SAME two CSV rows: the .cpp of the commit before the thunk stage (62b6cf1) prints tc_lockup_disengage_state for every 0x3fb54e access (lines 41803-41861 and 42232), governor_j1939_fuel_input_counter (plain, no underscore) for every 0x3fb54c access (42144-42167) and func_0x003fb54c(param_1) for the boot call; the commit that added the thunk stage (8a72628, 2026-06-01) is the first .cpp with the crossed names (its lines 41810-41868), and the crossing is in every .cpp since, including pre.cpp. (3) Widths are proven word: scanning both banks finds exactly 7 accesses and all are lhz/sth - 0x3fb54c: cm848_driveEngineRetarderOutput lhz 0x42074, sth 0x4207c, sth 0x4212c; 0x3fb54e: cm848_updateEngineRetarderEnableState sth 0x41428 (r30 = 0x3fb54e), lhz 0x4157c, lhz 0x41798, and cm848_initializeEngineRetarderRequestState sth 0x422ac (clears it; xref_addr.py misses this one because the .cpp prints the other name there). No access below 0x7F60 and none above word width, so no pair clear and no boot user; the only boot-time use of 0x3fb54c is the bytes of the kernel image function itself. (4) The same mechanism hits every thunk address the application also uses as data, and in no case is a CSV row INSIDE a thunk body used by the decompiler (an in-body access prints either the entry name, as for a word at entry + 2 under a word entry, or an unnamed default): 0x3fd1d8 / 0x3fd1da in hpcr_checkRailPressureSensorBeforeStart (two different counters, 0x3fd1d8 and the unnamed 0x3fd1da, both print as sensor_scan_cycle_counter; the lis/lhz order at 0x5315a4 vs 0x5315bc shows the plain name is the one at 0x3fd1da), 0x3fae3c / 0x3fae3e (_mpc555_dispatchCanMessageHandlers = 8 and puRam003fae3e, the j1939_tx_buf_data_ptr row is lost), 0x3fb528 / 0x3fb52a (_fuel_demand_enable_sync_flag_shadow, wRam003fb52a), 0x3fd070 (_engine_load_ema_filter_pointer), 0x3fd1ac / 0x3fd284 / 0x3fd298 (BYTE_ rows, in-body bytes print bRam003fd1ad / sRam003fd1ae / uRam003fd285). What happens inside Ghidra was not inspected (read-only task); the evidence is the before/after .cpp and the sibling cases.")
note("LABEL PROBLEM - CSV FIX (rows only; no name, type or address changes): the names and the word types are right and must stay; a rename cannot cure the crossing, the comment rows can stop it misleading. Exact replacement rows (global_variables.csv lines 1890 / 1891): 0x003fb54c,engine_retarder_request_on_delay_counter,word,Counts passes with engine_retarder_request_percent at 50 percent or more (cm848_driveEngineRetarderOutput: lhz 0x42074; sth 0x4207c = 0 below 50 percent; sth 0x4212c = clamp to engine_retarder_request_on_delay_passes); word width; only user in either bank. Time-shared RAM: 0x3fb54c is also the entry of the boot-kernel image of cm848_validateDiagnosticRequestLengthAndAuthorization (ROM 0x597c; called once from the boot ROM at 0x185c) so the romramthunks stage puts a 4-byte thunk over 0x3fb54c-0x3fb54f. In the decompiled C this counter prints as _engine_retarder_request_on_delay_counter; the plain engine_retarder_request_on_delay_counter is the lockup state word at 0x3fb54e and the boot call (was governor_j1939_fuel_input_counter) | 0x003fb54e,tc_lockup_disengage_state,word,Torque converter lockup state: cm848_updateEngineRetarderEnableState stores j1939_tsc1_override_state.etc1_spn573_tc_lockup_disengage (or, when algorithm_enable_flags_6_cal mask 4 is set, 1 if the first byte of protection_condition_state & 1 is nonzero) with sth 0x41428 and reads it with lhz 0x4157c and 0x41798 (nonzero while transmission_park_or_neutral_flag is 0 gives the retarder exit condition; zero is part of the enter condition); cm848_initializeEngineRetarderRequestState clears it (sth 0x422ac). Word width; no other user; no boot-ROM user. Lies inside the 4-byte thunk over 0x3fb54c so the decompiled C prints every access to it as engine_retarder_request_on_delay_counter and never prints this name. Plate refresh (function_renames.csv): append to cm848_updateEngineRetarderEnableState (line 1301) the sentence ' Its torque converter lockup state word (0x3fb54e, tc_lockup_disengage_state) prints in the decompiled C as engine_retarder_request_on_delay_counter (ROM-to-RAM thunk over 0x3fb54c).'; append to cm848_initializeEngineRetarderRequestState (line 1309) ' Its last store clears the lockup state word at 0x3fb54e, which prints as engine_retarder_request_on_delay_counter.'; append to cm848_driveEngineRetarderOutput (line 1307) ' Its counter at 0x3fb54c prints as _engine_retarder_request_on_delay_counter (thunk window).'; append to mpc555_diagService25_executeFunction (0x1840) ' Its first call goes to the boot-kernel image of cm848_validateDiagnosticRequestLengthAndAuthorization (RAM 0x3fb54c) and prints as engine_retarder_request_on_delay_counter(param_1).'")
note("LABEL PROBLEM - REAL FIX is in the build, not the CSV (proposal, not applied, needs one build to confirm): in firmware/scripts/ApplyRomToRamThunks.java skip the thunk when the application owns the RAM address, i.e. when the symbol table already holds a USER_DEFINED non-function label at the thunk entry (the named data rows of global_variables.csv: 0x3fb528, 0x3fb54c, 0x3fd070, 0x3fd1ac, 0x3fd1d8, 0x3fd284, 0x3fd298; type-only rows have no label and keep their thunk, so the other 23 boot call targets keep their ROM function names). Expected result, taken from the pre-thunk .cpp (62b6cf1, same rows): tc_lockup_disengage_state and engine_retarder_request_on_delay_counter print correctly with no underscore, and the boot call prints func_0x003fb54c(param_1) as before 2026-06-01 instead of a call named after a counter. Cost: those 7 boot calls lose a name, but today they print the wrong one (engine_retarder_request_on_delay_counter(param_1), engine_load_ema_filter_pointer(param_1,0), sensor_scan_cycle_counter(), BYTE_003fd298(...)). Not a type change and no CSV row needed; 0x3fd1da (second rail pressure counter, no row) would then deserve its own row.")

# ---------------------------------------------------------------- 2. high speed governor remaining words
HSG_PREFIX = "Code (cm848_runHighSpeedGovernorPid 0x1f40c, cm848_presetHighSpeedGovernorIntegrator 0x1f34c, cm848_selectHighSpeedGovernorGainSet 0x1fa20): "
hsg = [
    ("0x0040a8c1", "governor_fuel_demand_threshold_cal", "high_speed_governor_fueling",
     "Code: stored once per pass at the end of the PID (sum of proportional, derivative and integral terms clamped between the fueling minimum / maximum); read by cm848_processProtectionRampControl (0x4066c: becomes governor_fuel_demand_value when governor_fuel_demand_mode is 12) and cm848_copyProtectionRampValue (0x40ddc: governor_fuel_demand_low_threshold). A computed RAM output, so the old _cal is wrong. Dump 2179 = 2062 + 0 + 117. e2m corroboration only: HSG fueling clamps."),
    ("0x0040a8c5", "injection_timing_max_cal_load", "high_speed_governor_proportional_term",
     "Code: error x adjusted proportional gain / 1113 clamped between the proportional term minimum / maximum; stored by the PID (0x1f828), read by the preset function (the part above the preset offset limit) and by the final sum. Dump 2062 = 8000 x 287 / 1113. Users: those two functions only."),
    ("0x0040a8c7", "injection_timing_base_clamped", "high_speed_governor_derivative_term",
     "Code: (filtered error - previous filtered error) x adjusted derivative gain x 100 / 3478 clamped between the derivative term minimum / maximum; stored by the PID (0x1f89c) and read only by its sum. Dump 0 (error unchanged)."),
    ("0x0040a8c9", "injection_timing_compensation_b", "high_speed_governor_integral_term",
     "Code: high word of the integrator, written by the init (integrator maximum), the preset function and the PID; read by the final sum and by cm848_selectEngineSpeedLimit (0x20298: clamped to torque_limit_fuel_upper_cal / _lower_cal and used as the fuel value of the engine speed limit droop). Dump 117 = high word of the integrator 0x0075b17c."),
    ("0x003fa890", "timing_compensation_accumulator", "high_speed_governor_integrator",
     "Code: dword Q16 integrator (high word = integral term): preset to fuel_demand_computed minus the proportional part while governor_mode_code is not 12, reset to the reset value << 16 at overspeed, then += proportional gain-switch compensation + error x integral gain / 17809, clamped between the integrator minimum / maximum. Word accesses at 0x3fa890 / 0x3fa892 are the halves (0x1f54c / 0x1f554 clear them). Dump 0x0075b17c. Users: the PID and the preset function only. Row stays dword (no type change). " + TS),
    ("0x0040a8d7", "injection_timing_compensation_int", "high_speed_governor_error_filter_accumulator",
     "Code: state[1] of cm848_signedFirstOrderFilter(error, &high_speed_governor_error_filter_coefficient_pointer) (state[0] = pointer to the coefficient word 0x40a8d1; the filter returns accumulator >> 16); reset to the limit << 16 when the filtered error hits its limits, cleared by the overspeed reset and the init. Dump 0x1f400000 -> 8000 = high_speed_governor_filtered_error. Users: the PID and the init."),
    ("0x0040a8db", "injection_timing_scale_factor", "high_speed_governor_proportional_gain_adjusted",
     "Code: proportional gain after the |filtered error| scaling table (multiplier / 256, capped 0xf000) when the proportional adjustment enable is nonzero, else the plain gain; used x error / 1113 for the proportional term and (previous value) in the integrator gain-switch compensation. Dump 287 (plain gain 82, enable = 1). Only user: the PID."),
    ("0x0040a8dd", "injection_timing_compensation_scale", "high_speed_governor_derivative_gain_adjusted",
     "Code: derivative gain after its scaling table (cap 0xffff) when the derivative adjustment enable is nonzero, else the plain gain; used in the derivative term. Dump 2 (enable 0). Only user: the PID."),
    ("0x0040a8df", "injection_timing_ema_coeff_computed", "high_speed_governor_integral_gain_adjusted",
     "Code: integral gain after its scaling table (cap 0x3d70) when the integral adjustment enable is nonzero, else the plain gain; the integrator increment is error x this / 17809. Dump 262 (enable 0). Only user: the PID."),
    ("0x003fa894", "fuel_demand_filter_output_snapshot", "high_speed_governor_filtered_error_previous",
     "Code: copy of high_speed_governor_filtered_error taken at the start of the PID and in the preset function; read by the derivative term as the previous value. Dump 8000. " + TS),
    ("0x0040a8b7", "fuel_demand_state_code", "high_speed_governor_gain_set_code",
     "Code: 16 base set, 17 transient set, 18 / 19 low / high reference speed set, or the working set code from cm848_processSystemStatusLimits (20 / 21 per the working gain rows); written by the init and cm848_selectHighSpeedGovernorGainSet only (.cpp: no other function mentions the old name). Dump 16."),
    ("0x0040a8b1", "fuel_demand_filter_coefficient_working_set_code", "high_speed_governor_working_gain_set_code",
     "Code: 0 means no working set was loaded and the ROM / base sets apply; nonzero makes cm848_selectHighSpeedGovernorGainSet copy the working gains and take this as the set code; written only by cm848_processSystemStatusLimits (0x424dc / 0x42524) with the working gains. Dump 0."),
    ("0x00406fbe", "fuel_demand_filter_output_upper_limit", "high_speed_governor_filtered_error_maximum",
     "Code: the filtered error is clamped to this when above it (and the error filter accumulator is reset to it << 16). Dump 8000. ROM-copied cal, no _cal."),
    ("0x00406fc0", "fuel_demand_filter_output_lower_limit", "high_speed_governor_filtered_error_minimum",
     "Code: lower clamp of the filtered error. Dump -8000 (0xe0c0). ROM-copied cal, no _cal."),
    ("0x00406fc2", "injection_timing_compensation_limit_upper", "high_speed_governor_integrator_maximum",
     "Code: PID clamps the integrator high word to this when it is at or above it; also the init value of the integral term. Dump 1766. (Row comment still cites old names.)"),
    ("0x00406fc4", "injection_timing_compensation_limit_lower", "high_speed_governor_integrator_minimum",
     "Code: lower integrator clamp. Dump 0. (Row comment still cites old names.)"),
    ("0x00406fc6", "injection_timing_compensation_initial_value", "high_speed_governor_integrator_reset_value",
     "Code: value the integrator and integral term are set to when engine speed exceeds the limit plus the reset speed offset with governor_fuel_demand_mode 12 and governor_fuel_demand_value below the reset threshold. Dump 0."),
    ("0x00406fc8", "governor_mode_c_rpm_offset_cal", "high_speed_governor_integrator_reset_speed_offset",
     "Code: (arbitrated engine speed limit + this) < current_rpm is the overspeed reset condition (rpm x 8 units). Dump 25600 = 3200 rpm, so the reset is effectively off here. ROM-copied, no _cal."),
    ("0x00406fca", "governor_mode_c_fuel_demand_threshold_cal", "high_speed_governor_integrator_reset_fuel_demand_threshold",
     "Code: governor_fuel_demand_value < this is the second reset condition. Dump 0. ROM-copied, no _cal."),
    ("0x00406fcc", "injection_timing_compensation_calculation_lower_limit", "high_speed_governor_integrator_preset_minimum",
     "Code: cm848_presetHighSpeedGovernorIntegrator clamps the preset integrator between this (minimum) and the preset maximum. Dump 0."),
    ("0x00406fce", "injection_timing_compensation_calculation_upper_limit", "high_speed_governor_integrator_preset_maximum",
     "Code: upper clamp of the preset integrator. Dump 1766."),
    ("0x00406fd0", "governor_fuel_demand_threshold_lower_cal", "high_speed_governor_fueling_maximum",
     "Code (min / max are INVERTED in the old name): the PID output is set to this when the sum is above it (0x1f940), so it is the maximum. Dump 5888 (= 0x1700, the hard cap used elsewhere). ROM-copied, no _cal."),
    ("0x00406fd2", "governor_fuel_demand_threshold_upper_cal", "high_speed_governor_fueling_minimum",
     "Code (min / max inverted in the old name): the PID output is raised to this when the sum is below it (0x1f958), so it is the minimum. Dump 0."),
    ("0x00406fda", "injection_timing_base_lower_cal", "high_speed_governor_derivative_term_maximum",
     "Code (inverted in the old name): derivative term is set to this when above it (0x1f864). Dump 2208. ROM-copied, no _cal."),
    ("0x00406fdc", "injection_timing_base_upper_cal", "high_speed_governor_derivative_term_minimum",
     "Code (inverted in the old name): derivative term is raised to this when below it (0x1f87c). Dump -2206 (0xf762)."),
    ("0x00406fde", "injection_timing_load_floor_cal", "high_speed_governor_proportional_term_maximum",
     "Code (the 'floor' is the maximum): proportional term is set to this when above it (0x1f654 / 0x1f7f4). Dump 2208. ROM-copied, no _cal."),
    ("0x00406fe0", "injection_timing_max_load_cal", "high_speed_governor_proportional_term_minimum",
     "Code (the 'max' is the minimum): proportional term is raised to this when below it (0x1f66c / 0x1f80c). Dump -2206."),
    ("0x00406fe2", "injection_timing_compensation_addend", "high_speed_governor_integrator_preset_offset_limit",
     "Code: in the preset function the integrator is fuel_demand_computed minus the positive proportional term, plus min(proportional term, this). Dump 221. Row comment cites an old name."),
    ("0x003fa89c", "injection_timing_step_counter", "high_speed_governor_transient_gain_set_pass_counter",
     "Code: cm848_selectHighSpeedGovernorGainSet (system_feature_config_flags mask 1 set) increments it every call (0x1fd34 / 0x1fd3c) and clears it when it enters the transient gain set (code 17, 0x1fae4). Dump 0. " + TS),
    ("0x003fa89e", "injection_timing_working", "high_speed_governor_transient_gain_set_timer",
     "Code: = pass counter x 20 (0x1fa4c), compared with DAT_0005c316 (the transient set time) and limited to it before the post-transient set is chosen; written only there. Dump 0. " + TS),
]
for a, o, n, e in hsg:
    glob(a, o, "confirmed", n, e)

note("HIGH SPEED GOVERNOR - what is verified and what is left: all 30 rows above were checked against the code, a whole-binary access scan and the RAM dump (base 0x3fa000): error 8000 -> P 2062 + D 0 + I 117 = 2179 = high_speed_governor_fueling, adjusted proportional gain 287 (adjustment enable 1), integral / derivative adjustment off, gain set code 16, integrator 0x0075b17c, error filter accumulator 0x1f400000. Every old name in the list has users only inside the block (.cpp function lists: cm848_runHighSpeedGovernorPid, cm848_presetHighSpeedGovernorIntegrator, cm848_selectHighSpeedGovernorGainSet, cm848_initializeHighSpeedGovernorGainSet, plus cm848_processProtectionRampControl / cm848_copyProtectionRampValue for the output and cm848_selectEngineSpeedLimit for the integral term). TEXT REFRESH needed after the renames (rows that still quote old names): global_variables.csv 0x00406fb4, 0x00406fb6, 0x00406fb8 (governor_fuel_demand_threshold_cal), 0x00406fc2, 0x00406fc4, 0x00406fe2, 0x0040a8cb, 0x0040a8cd, 0x0040a8cf; function_renames.csv plates 0x0001f40c (governor_fuel_demand_threshold_cal) and 0x0001fa20 (fuel_demand_state_code). The '+2' sub-label row 0x003fa892 (timing_compensation_accumulator+2, no type) was left alone by wave 6 and such names never become labels (cf. wRam003fb52a); if it is kept it must follow the rename of 0x3fa890 (high_speed_governor_integrator+2). NOT part of the block: 0x3fa88c / 0x3fa88e (fuel_ema_slot_state_1 / 2) are the two cached axis offsets of the cm848_dualAxisTableInterpolation call in cm848_calculateFuelDemandWithTrim (output injection_timing_demand_output; init 2 by cm848_initFuelDemandTableDimensions, no boot user), keep the names until that table is re-domained. The torque_limit_* arbitration (now cm848_selectEngineSpeedLimit) uses the integral term as described and needs no rename here.")

# ---------------------------------------------------------------- 3. saved block 0x40a216-0x40a248
note("SAVED BLOCK 0x40a216-0x40a246 - FACTS (settles the writer question of the wave 6 note): (1) The block is read exactly once per word by cm848_restoreEngineOperatingMode (0xfb28, called only from cm848_resetEngineOperatingMode 0x42918 as the first of the mode selectors) and never written: a whole-binary scan of ROM and Bank 2 for loads, stores, indexed and base+displacement forms finds 25 loads of 0x40a216-0x40a246 and no store; the only 32-bit constants in ROM / flash 2 that point near it are three Bank 2 parameter table records (0x40a20a, 0x40a24a, 0x40a24c) that are read-only diagnostic entries. A pointer-walk copy cannot hide the writer either: cm848_copyRomToRamBuffer (0x4bd00) fills only 0x3feed0-0x40a045 (sensor_channel_cal_block_start to sensor_channel_ram_start; 45430 bytes, 100 percent equal to ROM 0x64aea in the dump), the EEPROM mirror is 0x3fd482-0x3feec1, so the block (0x40a216 and up) is outside both calibration fills, and address builds (lis / addi / ori results) in 0x40a1c0-0x40a262 occur only inside cm848_runOperatingModeSpeedGovernor, cm848_restoreEngineOperatingMode and cm848_calculateGovernorReferenceSpeedBlend and point at single governor words, not at a copy range. (2) The 'RAM image kept across a warm reset' reading is REFUTED: cm848_clearWorkingRam (0x538974, first call after the TPU set-up in cm848_applicationMain) zeroes all RAM from 0x3fa000 to 0x41428e, which contains the block, on every start, and the dump holds 0 in it. So in this firmware the valid flag is 0 after every start and nothing sets it, the restore branch is never taken by application code. (3) What it restores: engine_operating_mode 30 (0x1e) and the all-speed governor's complete tuning set plus its internal state: speed request, integral / proportional gain (governor_pid_integral_gain / _proportional_gain), the speed filter coefficient, the fuel demand tracking limit and floor, nine compensator coefficients (fuel_demand_pid_coeffs is pointed at the block copy 0x40a232 and the coefficients are copied to fuel_pid_shadow_coeff0-8), engine speed, and six one-pass memories of the governor (previous speed error, integral state, previous engine speed, clamp value, integral clamped value, fuel demand correction) that cm848_runOperatingModeSpeedGovernor uses as its seeds while fuel_trim_mode_active_flag is 1. The same destinations are loaded by the two normal starts: mode 7 (variable speed governor selected: cm848_initEngineOperatingMode loads the calibration set fuel_pid_*_cal / fuel_pid_ema_initial_state_cal / governor_fuel_demand_tracking_limit_cal 5888 / fuel_trim_speed_reference_cal 0, dump engine_operating_mode = 7) and mode 2 (J1939 TSC1 speed control: cm848_engineMode_reset loads speed_request_unfiltered = j1939_tsc1_override_state.etc1_capped_speed_target, the nine coefficients from the ROM record at 0x5c1d6 + etc1_speed_control_mode x 18 and the filter coefficient / tracking limit / floor from the fixed ROM words 0x5c1d0 / 0x5c1d2 / 0x5c1d4). So the block is the third tuning set / state record of the same governor and the vocabulary 'fuel trim' is wrong for all of it (the live words 0x40a20a-0x40a214 / 0x40a248 / 0x40a25c-0x40a260 are the same governor and are the follow-up). (4) The governor does publish one state word every pass, governor_pid_integral_saved (0x40a1b8, store at 0xf40c in cm848_runOperatingModeSpeedGovernor), but nothing reads it, so the save half of the feature is absent from this build as well.")
saved = [
    ("0x0040a216", "fuel_trim_save_valid_flag", "engine_operating_mode_restore_valid_flag",
     "Code: gate of cm848_restoreEngineOperatingMode (engine_operating_mode 0 and this nonzero -> mode 30 and the copy). Only reader; no writer; zeroed at every start (dump 0)."),
    ("0x0040a218", "fuel_trim_saved_speed_request", "engine_operating_mode_restore_speed_request",
     "Code: copied to speed_request_unfiltered (0x40a24e) by the restore (lhz 0xfb5c). Only reader; no writer."),
    ("0x0040a21a", "fuel_trim_saved_integral_gain", "engine_operating_mode_restore_integral_gain",
     "Code: copied to governor_pid_integral_gain (0x40a250) by the restore. Only reader; no writer."),
    ("0x0040a21c", "fuel_trim_saved_proportional_gain", "engine_operating_mode_restore_proportional_gain",
     "Code: copied to governor_pid_proportional_gain (0x40a252). Only reader; no writer."),
    ("0x0040a21e", "fuel_trim_speed_ema_state", "engine_operating_mode_restore_speed_filter_coefficient",
     "Code: the restore copies it to fuel_pid_shadow_ema_state AND points fuel_trim_speed_filter_state.coefficient at it, i.e. it is the coefficient of the reference speed EMA (governor_reference_filter_weight = *coefficient >> 2; the calibration twin fuel_pid_ema_initial_state_cal is 32768). Only reader; no writer. Not an EMA state."),
    ("0x0040a220", "fuel_trim_saved_demand_limit", "engine_operating_mode_restore_fuel_demand_tracking_limit",
     "Code: copied to governor_fuel_demand_tracking_limit (0x40a25a), the upper clamp of governor_fuel_demand_tracking in cm848_runOperatingModeSpeedGovernor (calibration twin governor_fuel_demand_tracking_limit_cal = 5888). Only reader; no writer."),
    ("0x0040a222", "fuel_trim_saved_speed_reference", "engine_operating_mode_restore_fuel_demand_tracking_floor",
     "Code: copied to fuel_trim_speed_reference (0x40a25c), which is the LOWER clamp of governor_fuel_demand_tracking (fuel_demand_previous = clamp(tracking, floor, limit), .cpp 9463-9475 in cm848_runOperatingModeSpeedGovernor), not a speed reference (calibration twin fuel_trim_speed_reference_cal = 0, TSC1 ROM word DAT_0005c1d4). Only reader; no writer."),
    ("0x0040a224", "fuel_trim_saved_mode_flag", "engine_operating_mode_restore_state_active_flag",
     "Code: copied to fuel_trim_mode_active_flag (0x40a25e); while that flag is 1 the governor takes its pass-to-pass memories from the restored words instead of computing them (normal starts clear it). Medium: the exact meaning of 'active' beyond that dataflow is not proven. Only reader; no writer."),
    ("0x0040a226", "fuel_trim_saved_pid_error_accum", "engine_operating_mode_restore_speed_error_previous",
     "Code: copied to fuel_trim_pid_error_accum (0x40a20a), which the governor loads into iVar16; in the normal continuing path iVar16 is fuel_demand_pid_reference_working, the previous pass's reference minus actual speed. Medium confidence on 'previous speed error'. Only reader; no writer."),
    ("0x0040a228", "fuel_trim_saved_pid_integral", "engine_operating_mode_restore_integral_state",
     "Code: copied to fuel_trim_pid_integral (0x40a20c) and then governor_pid_integral_state = value << 16 (high word of the governor integrator). Only reader; no writer."),
    ("0x0040a22a", "fuel_trim_saved_ema_ref", "engine_operating_mode_restore_engine_speed_previous",
     "Code: copied to fuel_trim_pid_ema_ref (0x40a20e) and then fuel_trim_pid_ema_snapshot, which the governor sets to governor_rpm_actual at the end of every pass and subtracts from it (engine speed change per pass). Only reader; no writer."),
    ("0x0040a22c", "fuel_trim_saved_clamp_value", "engine_operating_mode_restore_pid_clamp_value",
     "Code: copied to fuel_trim_pid_clamp_value (0x40a210) which seeds iVar14 = the previous governor_pid_integral_clamp_value (the clamped proportional + derivative output). Only reader; no writer."),
    ("0x0040a22e", "fuel_trim_saved_clamped", "engine_operating_mode_restore_pid_integral_clamped",
     "Code: copied to fuel_trim_pid_clamped (0x40a212) which seeds the previous governor_pid_integral_clamped (integral + clamp value, clamped). Only reader; no writer."),
    ("0x0040a230", "fuel_trim_saved_correction", "engine_operating_mode_restore_fuel_demand_correction",
     "Code: copied to fuel_trim_pid_correction (0x40a214) which seeds fuel_demand_correction_working. Only reader; no writer."),
]
for i in range(9):
    addr = 0x0040a232 + 2 * i
    saved.append(("0x%08x" % addr, "fuel_trim_pid_coeff_%d" % i, "engine_operating_mode_restore_compensator_coefficient_%d" % i,
                  "Code: the restore points fuel_demand_pid_coeffs at 0x40a232 (so the governor reads the block in place) and copies coefficient %d to fuel_pid_shadow_coeff%d; the calibration twin is fuel_pid_*_cal. Nine coefficients of the all-speed governor compensator (the PID in the old names is the code's own word). Only reader; no writer." % (i, i)))
saved.append(("0x0040a244", "fuel_trim_saved_rpm_actual", "engine_operating_mode_restore_engine_speed",
              "Code: copied to governor_rpm_actual (0x40a260). Only reader; no writer."))
saved.append(("0x0040a246", "fuel_trim_saved_alt_speed_request", "engine_operating_mode_restore_no_load_fuel_speed_request",
              "Code: copied to fuel_trim_speed_request_working (0x40a248), which cm848_calculateAllSpeedGovernorNoLoadFuel uses instead of speed_request_unfiltered while engine_operating_mode is 30. Only reader; no writer."))
UNCERTAIN_SAVED = {"0x0040a224", "0x0040a226"}
for a, o, n, e in saved:
    if a in UNCERTAIN_SAVED:
        glob(a, o, "uncertain", None,
             "UNCERTAIN, no new name; candidate " + n + " (dataflow is proven, the role is medium confidence). " + e)
    else:
        glob(a, o, "confirmed", n, e)
glob("0x0040a25c", "fuel_trim_speed_reference", "confirmed", "governor_fuel_demand_tracking_floor",
     "Code: lower clamp of governor_fuel_demand_tracking in cm848_runOperatingModeSpeedGovernor (the upper clamp is governor_fuel_demand_tracking_limit 0x40a25a, kept); loaded at mode starts from fuel_trim_speed_reference_cal (0), the TSC1 ROM set (DAT_0005c1d4) or the restore block. Dump 0 vs limit 5888. Pairs with the restore rows above. The calibration twin fuel_trim_speed_reference_cal (0x3ff6d4) is outside 0x3fd482-0x3feec1, so its _cal is legacy debt, follow-up.")
note("SAVED BLOCK - SIDE NOTES: (a) the ENGINE_OPERATING_MODE enum in enums.csv (lines 55-60) contradicts the code: MODE_RUN 7 is the variable speed governor (cm848_initEngineOperatingMode, variable_speed_governor_selected_flag), MODE_TRANSITION 2 is J1939 TSC1 speed control, 0x1e (MODE_CRANK) is the restore mode above, and the setters also use 1 (TSC1 torque control, cm848_setEngineOperatingMode1), 5 (engine_mode_control_flags mask 1, cm848_setEngineOperatingMode5), 6 and 8. No variable is typed with it, so it is inert, but its member names should not be used. (b) The remaining live words of the governor that still say 'fuel trim' (0x40a20a-0x40a214 fuel_trim_pid_*, 0x40a248 fuel_trim_speed_request_working, 0x40a254 / 0x40a256 fuel_trim_pid_*_gain_calc = duplicates of governor_pid_*_gain written by cm848_calculateGovernorCompensatorCoefficients, 0x40a25e fuel_trim_mode_active_flag, and fuel_pid_shadow_coeff0-8 / fuel_pid_*_cal) are the same governor; rename them in one pass with these rows (the e2m calls the compensator ASG, all speed governor). (c) fuel_pid_*_cal and fuel_trim_speed_reference_cal sit at 0x3ff6d0-0x3ff6ea, outside the EEPROM mirror, so their _cal is legacy debt.")

# ---------------------------------------------------------------- 4. 0x3fd910
note("UNCERTAIN 0x003fd910, no name proposed (no CSV row; word; EEPROM 0x48e, so a future name needs _cal). Verified: the EEPROM mirror maps exactly (3359 of 3359 words of 0x3fd482-0x3feec0 match cm848_eeprom.bin), the word is 0 in all four EEPROM dumps (before / after HPT), and there are exactly two readers: cm848_calculateEngineRetarderCruisePermissionPercent (lhz 0x524608, added to cruise_speed_command before the threshold test) and governorCruiseStateMachine (lhz 0x525018, first argument of governor_cruise_rampScale_calc = x << 10 / (governor_cruise_fuel_demand_setpoint - governor_cruise_fuel_demand_min), capped 0x22c8, into cruise_ramp_rate_a_working 0x40b69c). The neighbours form one record: 0x3fd912 and 0x3fd916 (EEPROM 0x490 / 0x494) are already cruise_ramp_zone_b / _d_fuel_demand_threshold and 0x3fd914 (0x492) goes the same way into cruise_ramp_rate_c_working, so 0x3fd910 / 0x3fd914 read as zone A / C amounts. The two users disagree on the unit (a speed offset added to cruise_speed_command versus a numerator over a fuel demand span), and the whole cruise_* block was already found to be partly the dual accelerator pedal, so no name until the cruise side is settled. Side finding: cruise_ramp_zone_b_fuel_demand_threshold (0x3fd912) and _d_ (0x3fd916) are inside the EEPROM mirror (EEPROM 0x490 / 0x494) but lack _cal and their comments call them ROM; legacy naming debt.")

# ---------------------------------------------------------------- 5. 0x40a370 / function 0x10874 charge manager
func("0x00010874", "cm848_selectTemperatureTrimValue", "confirmed", "cm848_selectChargeManagerMassChargeFlowCommand",
     "Selects the mass charge flow command that goes to the charge manager: mass_charge_flow_selected_command takes mass_charge_flow_engine_retarder_command (0 here) while engine_retarder_active_flag is 1 and mass_charge_flow_combustion_command otherwise; cm848_calculateTurboBlendOutput then limits it (was cm848_selectTemperatureTrimValue).",
     "Code: the body is two stores and one test (lhz 0x10894 of 0x40a370, store 0x1089c to 0x40a376); it has no temperature input. e2m corroboration: CHS_MCF_Cmd (0x011A5200) 'Either CBL_MCF_Cmd or EB_Charge_Flow_Command', where CBL_MCF_Cmd is already mass_charge_flow_combustion_command and EB_Charge_Flow_Command (0x0110701E) 'Final Charge Flow commanded by Brake Manager during braking'.")
glob("0x0040a370", "fuel_demand_rate_minimum_fuel_mode_1_value", "confirmed", "mass_charge_flow_engine_retarder_command",
     "Code: the value cm848_selectChargeManagerMassChargeFlowCommand copies while engine_retarder_active_flag is 1; one reader (lhz 0x10894), one writer (cm848_initializeEngineRetarderRequestState sth 0x422a4 = 0), so it is always 0 here and the charge flow command is 0 while the retarder is active. e2m corroboration: EB_Charge_Flow_Command 'Final Charge Flow commanded by Brake Manager during braking' (the code base says engine retarder for the exhaust brake). The old fuel_mode_1 wording has no support.")
glob("0x0040a376", "fuel_demand_rate_min", "confirmed", "mass_charge_flow_selected_command",
     "Code: written only by cm848_selectChargeManagerMassChargeFlowCommand, read only by cm848_calculateTurboBlendOutput (0x10c40 / 0x10c78): the command that is limited to charge_mass_flow_filtered - 2 x the derate offsets while a derate flag is set, else passed on; 'min' came from the min() in that limiter, the word is the unlimited command. e2m corroboration: CHS_MCF_Cmd.")
glob("0x0040a378", "fuel_demand_rate_limited", "confirmed", "mass_charge_flow_limited_command",
     "Code: output of cm848_calculateTurboBlendOutput (0x10c54 / 0x10c64 / 0x10c7c); only reader cm848_processLoadAdjustment (0x112a4): (this - charge_mass_flow_filtered) / 2 -> throttle_position_scaled, i.e. the charge flow error. e2m corroboration: CHL_MCF_Cmd 'Charge Mgr demanded charge flow after limiters' (scale 1/128 lb/min) and CSE_MCF_Error 'Difference between CHL_Charge_Flow_Command and actual Charge Mass Flow' (scale 1/64 = half), which is exactly the /2 in the code.")
note("CHARGE MANAGER CHAIN (cross-check for the owner of the throttle_* / fuel_demand_rate_* family; no rows): the e2m CHL group matches cm848_calculateTurboBlendOutput (0x10b28) beyond the rows above. Code: uVar4 = charge_mass_flow_filtered + (rate filter output a / b / c, whichever is active) x -2 with the three throttle_rate_threshold_a / b / c_flag values deciding whether the limit applies, and fuel_demand_rate_below_min_flag = 1 when the limited value is below the selected command. e2m: CHL_COT_Drt_Offset / CHL_Delta_P_Drt_Offset / CHL_Turbo_Speed_Drt_Offset (LB/MIN 1/64, hence the x 2 into the 1/128 flow scale) with CHL_COT_Drt_Active / CHL_Delta_P_Drt_Active / CHL_Turbo_Speed_Drt_Active and CHL_Derate_Is_Active. So likely: throttle_rate_filter_output_a / b / c are the three charge flow derate offsets, throttle_rate_threshold_a / b / c_flag their active flags, fuel_demand_rate_below_min_flag = a charge flow derate is active, cm848_calculateTurboBlendOutput = the charge manager derate limiter (candidate cm848_limitChargeManagerMassChargeFlowCommand), cm848_calculateTurboRatioA / B the derate offset calculations, and throttle_position_scaled = CSE_MCF_Error. Not verified further here (which of COT / delta P / turbo speed is a, b, c needs the two TurboRatio functions), so only the four rows above are proposed.")

# ---------------------------------------------------------------- 6. 0x3fa114 / 0x3fa116
for a, o, tag in (("0x003fa114", "diag_state_group4_a_state", "first"), ("0x003fa116", "diag_state_group4_d_state", "second")):
    glob(a, o, "uncertain", None,
         "UNCERTAIN, no name; candidate unused_lookup_cached_axis_offset_1 / _2 (names fixed by address order, the a / d letters of the old names are arbitrary) if medium confidence is accepted. Re-verified with a whole-binary scan including base+displacement and indexed forms and a search of ROM / flash 2 data for 32-bit pointers 0x3fa100-0x3fa11f: the only access is the 'li 2; sth' store in cm848_initLookupTableParams (0x10250 for 0x3fa114, 0x10258 for 0x3fa116); nobody loads it, builds its address or passes it. The same function stores 2 to 0x3fa110 / 0x3fa112 (all_speed_governor_droop_blend_0 / _128 cached axis offsets, passed by pointer in cm848_calculateGovernorCompensatorCoefficients), so this is the cache-init group of four lookups of which this build keeps two; an excluded feature would explain two init-only words, but no code proves it. Time-shared window, no access below 0x7F60. The old name (diag state) is wrong in any case; the .cpp prints it only in the init.")

# ---------------------------------------------------------------- 7. COMBUSTION_CHI_SOURCE enum + 0x4059da / 0x4059f0
note("ENUM PROPOSAL COMBUSTION_CHI_SOURCE (enums.csv columns enum_name,value,member_name,comment,size; size 2 because both words are 'word'; decimal values; all six verified in the code, the other values never occur in this firmware): COMBUSTION_CHI_SOURCE,1,COMBUSTION_CHI_SOURCE_AMBIENT_AIR_DENSITY,Base chi from the ambient air density protective chi table (cm848_determineBaseChi keeps the larger chi of the two sources; cm848_selectChiSourceCode returns 1 when the density chi is not smaller),2 | COMBUSTION_CHI_SOURCE,3,COMBUSTION_CHI_SOURCE_COOLANT_TEMPERATURE,Base chi from the coolant temperature protective chi table (returned when the density chi is smaller),2 | COMBUSTION_CHI_SOURCE,10,COMBUSTION_CHI_SOURCE_EGR_OFF,Fixed EGR-off chi and level (combustion_egr_off_chi_hundredths / combustion_egr_off_paired_level) when EGR is requested off and fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 are all clear - the normal state on this truck (dump: flags 0x402, mask 2 set -> EGR off requested; combustion_chi_source_code = 10; chi 400),2 | COMBUSTION_CHI_SOURCE,12,COMBUSTION_CHI_SOURCE_USER_OVERRIDE_FULL,Calibrated override of chi and both map numbers (combustion_override_and_estimation_enable_flags_cal mask 0x80 set and mask 0x40 set; e2m CBR_FULL_USER_OVERRIDE),2 | COMBUSTION_CHI_SOURCE,13,COMBUSTION_CHI_SOURCE_USER_OVERRIDE_SINGLE_VALUE,Calibrated override with one whole chi that sets both map numbers (mask 0x80 set and mask 0x40 clear; e2m CBR_SINGLE_USER_OVERRIDE),2 | COMBUSTION_CHI_SOURCE,14,COMBUSTION_CHI_SOURCE_STATUS_FLAG_FIXED_VALUE,Fixed chi and level combustion_status_flag_chi_hundredths / combustion_status_flag_paired_level selected when any of fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 is set; EGR is requested off (e2m CBR_PROTECTION_CHI),2. Typing: change the type column of 0x0040a4a4 (combustion_chi_source_code; values 1 / 3 / 10 / 12 / 13 / 14; no reader) and 0x0040a4e4 (combustion_base_chi_source_code; only 1 / 3; read once in cm848_selectChiAndAlpha) from word to COMBUSTION_CHI_SOURCE. Render check needed: the names only substitute for whole-value compares on an enum-typed variable, and the compares are on locals (sVar1 == 1 / 3 in cm848_determineBaseChi, local_1a assigned 1 / 3 / 10 / 12 / 13 / 14 in both functions), so local_variables.csv rows typing those locals as COMBUSTION_CHI_SOURCE (and cm848_selectChiSourceCode returning it) are needed for the names to appear. The same two-code-space words 0x40a4f0 (reference source 23 / 52 / 53 / 54 / 55 / 58) and fuel_demand_mode_code (27 / 28) remain candidates for two further enums, not examined.")
glob("0x004059da", "fuel_blend_step_a_cal", "confirmed", "combustion_status_flag_chi_hundredths",
     "Code: the chi in hundredths (dump 400) that cm848_selectChiAndAlpha uses with source code 14 when any of fuel_mode_status_flags masks 0x08 / 0x10 / 0x200 is set (its only reader, lhz 0x160ec; the map numbers become chi / 100) and which forces EGR off. Trigger traced: fuel_mode_status_flags (0x40a5ee) is written only by fuel_modeStatusFlags_update (DAT_00406568 when DAT_003fd7ea is nonzero, else the cold start / cylinder check / sensor validation word 0x40a8a9 OR DAT_0040656a) and zeroed by cm848_initialization_step_7; the sensor validation word gives mask 0x08 from DAT_0040a43c, 0x04 from DAT_0040a43e and 0x100 from fuel_demand_active_state_flag, DAT_0040a43c / DAT_0040a43e have no writer, and DAT_00406568 = DAT_0040656a = 1024 (0x400) here, so source 14 is never selected on this truck (dump flags 0x402, source 10). The name states what selects it (the status flags), like its neighbour combustion_egr_off_chi_hundredths; the e2m calls it C_CBR_Protection_Chi (+04 in the CBR scalar block anchored at 0x4059d6, corroboration only) and 'protection' alone is not a name. ROM-copied calibration, no _cal.")
glob("0x004059f0", "fuel_blend_step_a_threshold_cal", "confirmed", "combustion_status_flag_paired_level",
     "Code: the level (dump 8192) paired with that chi: combustion_chi_paired_level when the source code is 14 (only reader cm848_selectChiAndAlpha, lhz 0x160fc), same trigger as 0x4059da. e2m corroboration: C_CBR_Protection_EL (+1A, 'Corresponds to C_CBR_Protection_Chi'). ROM-copied, no _cal.")
note("fuel_mode_status_flags (0x40a5ee) bit sources, from fuel_modeStatusFlags_update (0x50530c) and cm848_updateSensorValidationFlags (0x509a7c): mask 1 cold start phase 2.6 fuel mode (cold_start_phase26_fuel_mode_flag), mask 2 set when NOT in cold start phase 2.6 or 3 (always true warm: this is why EGR is requested off here), mask 0x80 phase 3 count met or compensation at limit, masks 0x20 / 0x40 from injection_timing_cylinder_check_flags, masks 0x04 / 0x08 / 0x100 from the sensor validation word 0x40a8a9 (DAT_0040a43e / DAT_0040a43c, both never written, and fuel_demand_active_state_flag) only when governor_feature_config_flags mask 0x40 is set, plus the calibration words DAT_00406568 (full override, selected by DAT_003fd7ea, EEPROM 0x368) and DAT_0040656a (ORed in), both 0x400 here (mask 0x400 is not tested by the chi selection). Masks 0x10 and 0x200 have no writer at all besides those calibration words; DAT_003fbd50 / DAT_003fbd54 (zeroed by cm848_initFlowControlStateVariables) feed the validation word and are never set. governor_fuel_demand_interp_state_y (0x40a8a7, dword; init 2 by cm848_initFaultSeverityTables) is a two-use word: its second half 0x40a8a9 is this validation word, its first half is a cache word, so the name governor_fuel_demand_interp_state_y is wrong for the second half.")

# ---------------------------------------------------------------- 8. 0x40a61c
glob("0x0040a61c", "fuel_demand_boost_input", "confirmed", "coolant_temperature_with_fault_default",
     "Code: cm848_mainLoop_step_3 (and cm848_initialization_step_11) copies WORD_0040bd88 into it, or WORD_0040bdae when sensor_generic_fault_status mask 2 is set (and sets boost_correction_inhibit_flag = 2). The generic sensor channel is slot 2: cm848_sensorChannelGeneric_init / update_configBundle pass channel_index 2, the coolant_temperature_linearization tables and fault bits 16 / 17 to sensorChannelConfigInit / updateSensorChannelWithConfig, whose last lines store *value_output_ptr (0x40bd88) = sensor_channel_filtered_output[2] (= sensor_readings_t.coolant_temp, ET1 SPN 110) and *default_value_output_ptr (0x40bdae) = config default 12160 = 190 F. Dump: 0x40bd88 2052, slot 2 2049, this 2050, coolant_temperature_in_use 2057 (all about 32 F in 1/64 F) and default 12160. It is therefore the filtered coolant temperature with the channel default substituted on a channel fault (a different substitution from coolant_temperature_in_use). It has 15 reader functions (combustion manager, VGT block, boost / temperature compensation, cold start fuel floor, protection checks); the ones read (cm848_determineBaseChi, cm848_selectChiAndAlpha, the VGT functions, the cold start floor lookup with cold_start_override_fuel_demand_floor_axis, the thresholds at .cpp 60378-60441) use it as a temperature threshold or lookup x axis, not all 15 were read. The name is not scoped to one consumer, so it does not over-claim.")
glob("0x0040bd88", "", "confirmed", "coolant_temperature_channel_value",
     "Type-only row (renders WORD_0040bd88). Code: *value_output_ptr of the generic (slot 2, coolant temperature) sensor channel = sensor_channel_filtered_output[2]; read by cm848_mainLoop_step_3 and cm848_initialization_step_11. Dump 2052.")
glob("0x0040bdae", "", "confirmed", "coolant_temperature_channel_default_value",
     "Type-only row (renders WORD_0040bdae). Code: *default_value_output_ptr of the same channel = config default (dump 12160 = 190 F); read by cm848_mainLoop_step_3 when the channel fault status mask 2 is set.")
note("0x40a61c follow-ups: the old fuel_demand_boost_* / boost_correction_* names of its consumers belong to the temperature compensation chain (the wave 6 note on cm848_auxiliaryControl_exponentialAverage = gas temperature estimate stands: candidate cm848_updateGasTemperatureEstimate is the air-handling owner's); boost_correction_inhibit_flag (0x40a61e) is 2 exactly when the coolant channel is faulted, 0 otherwise, which suggests coolant_temperature_channel_fault_flag but it is read elsewhere and was not checked.")

# ---------------------------------------------------------------- skipped
note("Skipped (informational or still unsettled, one line each): the wave 6 notes on the 0x3fb54c window names (done above), the governor_speed_* / channel 75 deviation words near 0x507214 (pairing of the PID output with the channel still not settled), the TSC1 / array type notes and the mode 7 reduction reason (typing pass), and the combustion_chi_maximum_torque_at_point_N i16 type note (type change, not proposed).")

# ---------------------------------------------------------------- validation
def load_csv_names(path, name_col=1):
    names = {}
    for line in open(path, errors="replace"):
        parts = line.rstrip("\n").split(",", 3)
        if len(parts) > 1 and parts[0].startswith("0x"):
            names[parts[0].lower()] = parts[1]
    return names


gv = load_csv_names(OUT + "global_variables.csv")
fr = load_csv_names(OUT + "function_renames.csv")
allnames = set(gv.values()) | set(fr.values())
try:
    for line in open(OUT + "arrays.csv", errors="replace"):
        p = line.split(",")
        if len(p) > 1:
            allnames.add(p[1])
except FileNotFoundError:
    pass

problems = []
newnames = {}
for r in rows:
    if r["kind"] not in ("global", "function"):
        continue
    table = gv if r["kind"] == "global" else fr
    cur = table.get(r["address"].lower())
    if cur is None:
        problems.append("no CSV row at %s (%s)" % (r["address"], r["kind"]))
    elif cur != r["old"]:
        problems.append("old mismatch at %s: csv '%s' vs '%s'" % (r["address"], cur, r["old"]))
    n = r.get("new")
    if n:
        if n in allnames:
            problems.append("new name already exists: %s (%s)" % (n, r["address"]))
        if n in newnames:
            problems.append("new name used twice: %s (%s and %s)" % (n, newnames[n], r["address"]))
        newnames[n] = r["address"]
        base = n.split("+")[0]
        if not re.fullmatch(r"[a-z][a-z0-9_]*", base) and r["kind"] == "global":
            problems.append("bad characters in %s" % n)
        if re.search(r"0x|[0-9a-f]{6,}", n):
            problems.append("hex-looking name %s" % n)
        if r["kind"] == "global":
            a = int(r["address"], 16)
            if n.endswith("_cal") and not (0x3fd482 <= a <= 0x3feec1):
                problems.append("_cal outside the EEPROM mirror: %s" % n)
        if re.search(r"(^|_)protection(_|$)", n):
            problems.append("bare protection in %s" % n)

for p in problems:
    print("PROBLEM:", p)
print("rows:", len(rows), "problems:", len(problems))
if "--write" in sys.argv:
    with open(RESULT, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=True) + "\n")
    print("written", RESULT)
