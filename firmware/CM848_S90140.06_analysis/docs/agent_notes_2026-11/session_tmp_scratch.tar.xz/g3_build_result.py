import json

OUT = "/home/linux/.claude/jobs/d55ae3c6/tmp/renames/result_G3.jsonl"
records = []


def fn(address, old, verdict, new, plate, evidence):
    rec = {"kind": "function", "address": address, "old": old, "verdict": verdict}
    if new:
        rec["new"] = new
    if plate:
        rec["plate_comment"] = plate
    rec["evidence"] = evidence
    records.append(rec)


def gv(address, old, new, evidence, verdict="confirmed"):
    rec = {"kind": "global", "address": address, "old": old, "verdict": verdict}
    if new:
        rec["new"] = new
    rec["evidence"] = evidence
    records.append(rec)


def note(text):
    records.append({"kind": "note", "text": text})


# ---------------------------------------------------------------- functions
fn(
    "0x00011ab4",
    "cm848_boostCompensatedRpmGovernor",
    "confirmed",
    "cm848_calculateWastegateDutyRequest",
    "Wastegate solenoid duty controller, called once per phase group A through cm848_turboCompensationWrapper: "
    "writes rpm_governor_state_t_0040a3ca.commanded_rpm, the wastegate duty request in half-duty counts "
    "(12800 = 100 %; cm848_applyWastegateSolenoidDuty sends 2 x it). commanded_rpm = clamp(calibration base + "
    "rate-limited term + PI integrator fed by the fuel_demand_quantity and fuel_flow_rate error terms, "
    "lower_rpm_limit, desired_rpm); the ceiling is wastegate_duty_ceiling_fixed x a battery-voltage gain (or the "
    "engine speed x load grid when wastegate_duty_ceiling_grid_enable_cal is set), the floor is "
    "wastegate_duty_floor_fixed or its grid, and both are trimmed by altitude (barometric_altitude_feet). "
    "(was cm848_boostCompensatedRpmGovernor)",
    "rpm_governor_state_t.commanded_rpm (0x40a3ca) is written only by this function (xref: this function and the "
    "init function) and read by cm848_applyWastegateSolenoidDuty as duty = 2 x it (25600 = 100 %, output channel 11, "
    "P0243 read-back). The RAM dump closes the loop numerically: battery 192 (12.0 V) gives gain 4649 (interpolated "
    "between 5202 at 10 V and 4096 at 14 V), 9600 x 4649 / 4096 = 10896, and wastegate_solenoid_duty_command "
    "(0x40c14e) = 21792 = 2 x 10896 exactly. A ceiling scaled by battery voltage and by altitude only makes sense "
    "for a solenoid duty, not an rpm. A second reader, cm848_calculateSpeedControlLimit, clamps the same word in the "
    "same half-duty units (see note); it does not change this verdict.",
)

fn(
    "0x00537584",
    "hpcr_fuelDemandProc",
    "confirmed",
    "cm848_monitorWastegateBoostPressure",
    "Wastegate (CWG) boost-pressure monitor, called from periodicTaskSet_fuelDemand; it runs only when "
    "cold_start_feature_flags mask 0x8, protection_feature_status_flags mask 0x1000000 and the start battery "
    "temperature test (DAT_003fd270) allow it, and it clears its counts and exits while sensor faults or the wastegate "
    "solenoid fault (403) are active. It looks up three boost limits by barometric_pressure_reference and sets fault "
    "332 (fault_detected_bits_320_to_335 mask 0x1000, high boost) after wastegate_monitor_debounce_count_limit passes "
    "with boost at or above wastegate_monitor_fail_high_boost_pressure_threshold, engine speed at or above "
    "wastegate_monitor_minimum_engine_speed_threshold and wastegate_solenoid_duty_command at or below DAT_00409fe0. "
    "It also counts the passes (wastegate_monitor_pass_event_count, wastegate_monitor_pass_duration_count) in which "
    "boost stays between the pass-low and pass-high thresholds at engine load of at least DAT_00409fe4; boost is "
    "intake_manifold_pressure, or boost_pressure_above_barometric when protection_sensor_mode_flag is set. "
    "(was hpcr_fuelDemandProc)",
    "Every role in the code has a counterpart in the e2m CWG (Controlled WasteGate) monitor parameter list; the "
    "pairing is by role (the e2m uses different addresses), not by address: CWG_Monitor_Enable "
    "(cold_start_feature_flags mask 0x8), CWG_Min_Start_Battery_Temp_Threshold (DAT_00409fe8 = 1280 = 20 F against "
    "battery_temperature_sensor_filtered, latched in cm848_initAdaptiveControl), CWG_Driver_Duty_Cycle_Threshold "
    "(DAT_00409fe0 = 11520 = 45 % against the duty command), CWG_Minimum_Engine_Speed_Threshold (14400 = 1800 rpm), "
    "CWG_High_Load_Threshold (DAT_00409fe4 = 19200 = 75 %), the Fail / Pass-high / Pass-low boost tables by ambient "
    "pressure, CWG_High_Boost_Error (mask 0x1000 in fault bits 320..335) and CWG_Total_Pass_Counter / "
    "CWG_Total_Pass_Time. The guard on fault_detected_bits_400_to_415 & 8 is fault 403, the wastegate solenoid "
    "read-back fault (P0243). Its sibling cm848_monitorOverboostAndHighLoadBoostBand is the non-CWG (P0234) variant. "
    "In the dump (engine off, runtime RAM) protection_feature_status_flags mask 0x1000000 is clear, so the monitor "
    "was not armed at that moment and all its counters read 0.",
)

fn(
    "0x00037744",
    "cm848_filterProtectionOutput",
    "confirmed",
    "cm848_calculateAlternatorFieldDutyByRegulatorState",
    "Per-state duty calculation of the 4-state charging-voltage (alternator field) regulator whose state machine is "
    "cm848_dispatchProtectionOutputMode; it runs only while engine_feature_enable_flags_cal bit 0 is set and writes "
    "alternator_field_duty_target (25600 = 100 %), clamped to 25600: state 0 (engine stopped, or fault 368) "
    "gives 0, or protection_fuel_output_idle_cal while fault 368 is set; state 1 gives the soft-start "
    "ramp by pass count; state 2 gives the duty from charging_voltage_error through alternator_field_duty_regulation_*; "
    "state 3 gives the load-response duty for an rpm-dependent hold time, then the slow-average snapshot plus an rpm- "
    "and duty-scaled ramp. It also keeps alternator_field_duty_slow_average. When operating_mode_flags mask 0x20 is set "
    "(it is in the dump), cm848_calculateProtectionOutputDemand's PID loop replaces the duty in states 2 and 3. "
    "(was cm848_filterProtectionOutput)",
    "Called in phase group B between cm848_dispatchProtectionOutputMode (state machine, handlers at ROM 0x38338 / "
    "0x38384 / 0x383f0 / 0x3844c, disassembled) and cm848_applyAlternatorFieldDuty (output channel 27, field "
    "control pin); every table it reads is an alternator_field_* table, indexed by battery_voltage_delta = "
    "battery_voltage_prev (charging voltage target) - battery_voltage, or by engine speed. It does not filter the "
    "output; the only filtering is a 0.1-weight EMA (coefficient 6554 / 65536) of the duty kept for the load "
    "response. Dump: target 240 (15.0 V) minus battery 192 (12.0 V) = delta 48; engine_feature_enable_flags_cal = "
    "0x27EF has bit 0 set.",
)

fn(
    "0x00532418",
    "hpcr_injectPressureTuning",
    "confirmed",
    "cm848_monitorIntakeAirHeaterPerformance",
    "Intake (grid) air heater performance test, a 7-state machine in intake_air_heater_performance_test_state "
    "(0 armed, 1 baseline taken, 2 heater on, 3 heater off, 4 passed, 5 failed, 6 aborted) that samples battery-voltage "
    "ADC channel index 4 in threes while the heater relays switch on and off; it runs only when operating_mode_flags "
    "mask 0x200 is set (clear in the dump) and hpcr_throttlePositionDiagnostic armed it at start. If the voltage drop "
    "at turn-on and the recovery after turn-off agree within DAT_00064430 counts, then both below the "
    "intake_air_heater_performance_threshold_* value for the intake manifold temperature sets fault 411 "
    "(fault_detected_bits_400_to_415 mask 0x800, P2609; state 5) and anything else clears it (state 4); if the two "
    "disagree the test ends in state 6 and leaves the fault bit unchanged. engine_protection_batteryLoad_check also "
    "aborts the test (state 6) when voltage, temperature or heater state is out of range, and a steady result in "
    "state 4 or 5 sets diagnostic_monitor_complete_bits 0x400. (was hpcr_injectPressureTuning)",
    "State 0 samples qadc_channel_index_table[4] (slot 4 = battery voltage, the channel of "
    "battery_voltage_linearization_*) before the heater relays are energised (cm848_countDownIntakeAirHeaterPreheat "
    "holds logical outputs 43/44 off while operating_mode_flags & 0x200 and the state is 0), states 1 and 2 sample it "
    "with the heater on, state 3 after intake_air_heater_preheat_remaining_ticks reaches 0; the final compare against "
    "hpcr_pressure_diag_lookup_ref (table intake_air_heater_performance_threshold_axis / _values by "
    "intake_manifold_temperature_sensor_filtered: 45 counts at 0 F falling to 24 at 66 F) sets or clears "
    "fault_detected_bits_400_to_415 & 0x800 = fault 411. Nothing in the function touches a pressure, so the "
    "hpcr_pressure_diag_* names are wrong-domain. Fault 411 = P2609 is taken from the lead and the campaign file; I "
    "did not decode the DTC slot table myself.",
)

# ---------------------------------------------------------------- globals: alternator regulator
gv(
    "0x0040b26c",
    "cruise_state_machine_index",
    "alternator_field_regulator_state",
    "Written only by cm848_dispatchProtectionOutputMode (next state from the 4-entry handler table at ROM 0x57730) and "
    "cm848_initProtectionFilterValues; all six readers are the charging regulator cluster (dispatch, filter, PID, "
    "output checks, processProtectionMode2). Values 0..3: 0 idle / fault, 1 start ramp, 2 regulation, 3 load response. "
    "Dump: 0 (engine off).",
)
gv(
    "0x003fb39c",
    "cruise_prev_state_index",
    "alternator_field_regulator_previous_state",
    "Written only by cm848_dispatchProtectionOutputMode (copy of the state before the handler runs); read by the "
    "filter (state 3 entry test) and the PID (state 1 -> 2 integrator preset).",
)
gv(
    "0x0040b26a",
    "cruise_voltage_debounce_timer",
    "alternator_field_load_response_hold_remaining_passes",
    "Loaded on the first pass of state 3 from alternator_field_load_response_hold_time_* indexed by engine speed, "
    "decremented once per pass while non-zero; while non-zero the duty follows alternator_field_duty_load_response_*, "
    "at 0 the load response moves to its ramp stage. Used only in cm848_filterProtectionOutput and the init function.",
)
gv(
    "0x0040b272",
    "cruise_voltage_fault_state",
    "alternator_field_load_response_stage",
    "0 outside state 3, set to 1 on state 3 entry (hold stage, duty from the load-response table), set to 2 when the "
    "hold timer expires (duty restored to the slow-average snapshot, then ramped); zeroed in states 0 and 2. Not a "
    "fault state; only cm848_filterProtectionOutput and the init function touch it.",
)
gv(
    "0x003fb38a",
    "battery_voltage_scan_index",
    "alternator_field_start_ramp_elapsed_passes",
    "Only user is cm848_filterProtectionOutput: it is the x input of the alternator_field_duty_start_ramp_* lookup in "
    "state 1, incremented once per pass there and zeroed in states 0 and 2, so it is the age of the soft-start ramp "
    "(not a voltage scan).",
)
gv(
    "0x0040b25c",
    "cold_start_fuel_ema",
    "alternator_field_duty_slow_average",
    "ema = (ema x (65536 - coefficient) + alternator_field_duty_target x coefficient) / 65536 at the top of "
    "cm848_filterProtectionOutput, coefficient = cold_start_fuel_ema_coeff_cal = 6554 (0.1); nothing to do with cold "
    "start or fuel. Read only to take the snapshot below.",
)
gv(
    "0x0040b270",
    "cold_start_fuel_ema_snapshot",
    "alternator_field_duty_slow_average_snapshot",
    "Copy of the slow average duty taken on entry to regulator state 3; written back into alternator_field_duty_target "
    "when the load-response hold timer expires (stage 1 -> 2). Only user is cm848_filterProtectionOutput.",
)
gv(
    "0x003fb38c",
    "battery_voltage_confirm_counter",
    "alternator_field_load_response_elapsed_passes",
    "Incremented once per pass in regulator state 3 and zeroed in states 0, 1 and 2; read by the state 3 handler "
    "(ROM 0x3844c): with the duty at 25600 and this count above the limit at 0x4087b0 the machine leaves state 3 for "
    "state 2. It counts time in the load response, not a confirmation of anything.",
)
gv(
    "0x0040b26e",
    "battery_voltage_prev",
    "charging_voltage_target",
    "Written only in cm848_processProtectionCoolantLookup: charging_voltage_target_by_battery_temperature_* lookup on "
    "battery_temperature_sensor_filtered plus charging_voltage_target_offset (or battery_voltage_correction_default_cal "
    "when battery_voltage_correction_enable_cal is non-zero). Read in cm848_processProtectionVoltageOffset as "
    "delta = battery_voltage_prev - battery voltage and in the SCI command 20 reply. Dump check: battery temperature "
    "2086 (32.6 F) interpolates 236 -> 232 to 235.65, + offset 4 = 240 = 15.0 V, which is the stored value.",
)
gv(
    "0x0040b274",
    "battery_voltage_delta",
    "charging_voltage_error",
    "cm848_processProtectionVoltageOffset: battery_voltage_delta = battery_voltage_prev (target) - "
    "sensor_readings_t.battery_voltage, signed, 1/16 V per count; the input of the state 2 and state 3 duty tables and "
    "of the PID. Dump: 240 - 192 = 48.",
)
gv(
    "0x0040b25e",
    "battery_voltage_filtered",
    "charging_voltage_error_slow_average",
    "cm848_processProtectionVoltageOffset: EMA of battery_voltage_delta with battery_voltage_filter_coeff_cal; it is "
    "a filtered charging voltage ERROR, not a filtered battery voltage (the checks compare it with thresholds the way "
    "an error is compared).",
)
gv(
    "0x0040b260",
    "battery_voltage_delta_filtered",
    "charging_voltage_error_fast_component",
    "cm848_processProtectionVoltageOffset: battery_voltage_delta - battery_voltage_filtered (the error minus its slow "
    "average); the state 2 handler (ROM 0x383f0) enters state 3 when it exceeds the threshold at 0x4087ac, i.e. a fast "
    "voltage dip from an electrical load.",
)
_caches = [
    ("0x003fb38e", "can_subsystem_init_state_a", "charging_voltage_target_lookup_cached_offset",
     "charging_voltage_target_by_battery_temperature_* lookup in cm848_processProtectionCoolantLookup"),
    ("0x003fb390", "can_subsystem_init_state_b", "alternator_field_duty_start_ramp_lookup_cached_offset",
     "alternator_field_duty_start_ramp_* lookup (state 1)"),
    ("0x003fb392", "can_subsystem_init_state_c", "alternator_field_duty_regulation_lookup_cached_offset",
     "alternator_field_duty_regulation_* lookup (state 2)"),
    ("0x003fb394", "can_subsystem_init_state_d", "alternator_field_load_response_hold_time_lookup_cached_offset",
     "alternator_field_load_response_hold_time_* lookup (state 3 entry)"),
    ("0x003fb396", "can_subsystem_init_state_e", "alternator_field_duty_load_response_lookup_cached_offset",
     "alternator_field_duty_load_response_* lookup (state 3 hold)"),
    ("0x003fb398", "can_subsystem_init_state_f", "alternator_field_load_response_ramp_by_rpm_lookup_cached_offset",
     "alternator_field_load_response_ramp_by_rpm_* lookup (state 3 ramp)"),
    ("0x003fb39a", "can_subsystem_init_state_g", "alternator_field_load_response_ramp_by_duty_lookup_cached_offset",
     "alternator_field_load_response_ramp_by_duty_* lookup (state 3 ramp)"),
]
for addr, old, new, what in _caches:
    gv(
        addr,
        old,
        new,
        "First argument of lookupTableInterpolation (ROM 0x55ef4 reads it as the starting segment, writes back "
        "2 x index: lhz r12,0(r8) ... sth r12,0(r8)); initialised to 2 in cm848_initProtectionFilterValues; its only "
        "other reference is the " + what + ". Nothing to do with CAN. (Existing 'Lookup cache' comment wording in "
        "global_variables.csv says 'the last axis segment offset (2 x index)'.)",
    )
gv(
    "0x004087d2",
    "cold_start_fuel_ema_coeff_cal",
    "alternator_field_duty_slow_average_coefficient",
    "Weight of the new duty sample in the slow average (6554 / 65536 = 0.1 in the dump). Address 0x4087d2 is outside "
    "the EEPROM mirror 0x3fd482-0x3feec1, so the _cal suffix is dropped.",
)
gv(
    "0x004087fa",
    "protection_fuel_output_idle_cal",
    None,
    "Behaviour is certain, the right name is not: it is read only in regulator state 0, where "
    "alternator_field_duty_target = this value, then forced to 0 unless fault_detected_bits_368_to_383 mask 0x1 is "
    "set (the state handlers return to state 0 whenever that fault is set). Value 0 in the dump. What fault 368 means "
    "is only inferred from cm848_processProtectionMode2, so I give no new name; 'idle' is at least not wrong for state "
    "0. Address 0x4087fa is outside the EEPROM mirror, so any new name must not end in _cal.",
    verdict="uncertain",
)

# ---------------------------------------------------------------- globals: wastegate monitor
gv(
    "0x0040ba6e",
    "hpcr_fuel_demand_protection_threshold",
    "wastegate_monitor_fail_high_boost_pressure_threshold",
    "Output of the wastegate_monitor_fail_high_boost_pressure_* lookup by barometric reference; boost at or above it "
    "(with the other conditions) counts toward fault 332 (CWG_High_Boost_Error).",
)
gv(
    "0x0040ba70",
    "hpcr_fuel_demand_fault_upper_limit",
    "wastegate_monitor_pass_high_boost_pressure_threshold",
    "Output of the wastegate_monitor_pass_high_boost_pressure_* lookup; upper edge of the PASS window (boost above it "
    "decrements the pass debounce), not a fault limit. e2m CWG_Pass_High_Boost_Pressure_Threshold.",
)
gv(
    "0x0040ba72",
    "hpcr_fuel_demand_fault_lower_limit",
    "wastegate_monitor_pass_low_boost_pressure_threshold",
    "Output of the wastegate_monitor_pass_low_boost_pressure_* lookup; lower edge of the PASS window. e2m "
    "CWG_Pass_Low_Boost_Pressure_Threshold.",
)
gv(
    "0x003fd26c",
    "hpcr_fuel_demand_protection_debounce_count",
    "wastegate_monitor_high_boost_debounce_count",
    "Up/down counter of the high-boost check (+1 per qualifying pass up to the limit, -1 otherwise); at the limit it "
    "sets fault 332, at 0 it clears it. Address 0x3fd26c is RAM below the EEPROM mirror, so no _cal.",
)
gv(
    "0x003fd26e",
    "hpcr_fuel_demand_fault_debounce_count",
    "wastegate_monitor_pass_debounce_count",
    "Up/down counter of the pass-window check (boost inside the window at load >= DAT_00409fe4 and rpm >= minimum); "
    "reaching the limit counts one pass event. It is the pass debounce, not a fault debounce.",
)
gv(
    "0x0040ba74",
    "hpcr_fuel_demand_fault_qualified_event_count",
    "wastegate_monitor_pass_event_count",
    "Incremented each time wastegate_monitor_pass_debounce_count newly reaches the limit; written only by this "
    "function and its init. Matches e2m CWG_Total_Pass_Counter.",
)
gv(
    "0x0040ba76",
    "hpcr_fuel_demand_fault_count",
    "wastegate_monitor_pass_duration_count",
    "Incremented every pass while the pass debounce is at or above the limit (saturates at 0xffff), so it is the time "
    "spent inside the pass window; its role matches e2m CWG_Total_Pass_Time.",
)
gv(
    "0x00409fe6",
    "hpcr_fuel_demand_rpm_threshold",
    "wastegate_monitor_minimum_engine_speed_threshold",
    "Engine speed (0.125 rpm per count; 14400 = 1800 rpm) below which both checks stop counting up; e2m "
    "CWG_Minimum_Engine_Speed_Threshold. Read only by this function.",
)
gv(
    "0x00409fe2",
    "hpcr_protection_debounce_count_threshold",
    "wastegate_monitor_debounce_count_limit",
    "30 passes in the dump; the limit for both the high-boost debounce and the pass debounce. Read only by this "
    "function.",
)
gv(
    "0x0040a196",
    "fuel_pressure_sensor_reference",
    "barometric_pressure_reference",
    "Not a fuel pressure. Dump numbers: 0x40a196 = 1647 and its source boost_pressure_fuel_working (0x40a162) = 1648, "
    "against sensor_readings_t.barometric_pressure (0x40baf6) = 1647 and intake_manifold_pressure (0x40baf2) = 1700, "
    "with the offset boost_fuel_pressure_offset_lookup = 0. Code: it is clamped to 0x75e = 1886 counts = 101.6 kPa "
    "(standard sea-level atmosphere at 1/18.56 kPa per count), and the table 0x3ff080 -> 0x3ff0a2 that "
    "hpcr_fuelFinal_exponentialAverage applies to it reproduces the standard-atmosphere altitude in feet exactly (see "
    "governor_adjustment_input). It also indexes the three wastegate monitor tables. Used by about 14 functions, so "
    "rename it everywhere.",
)

# ---------------------------------------------------------------- globals: heater test
gv(
    "0x0040b9ec",
    "iat_protection_state",
    "intake_air_heater_performance_test_state",
    "Written only by hpcr_injectPressureTuning (states 1..5), engine_protection_batteryLoad_check (abort = 6) and "
    "hpcr_throttlePositionDiagnostic (arms it: 0, or 6 when the battery and intake manifold temperatures disagree); "
    "cm848_computeIntakeAirHeaterPreheatDuration and cm848_countDownIntakeAirHeaterPreheat only read it (state 0 with "
    "operating_mode_flags & 0x200 holds relays 43/44 off for the baseline sample; 4, 5 and 6 release them). The "
    "existing CSV comment attributing the state machine to cm848_computeIntakeAirHeaterPreheatDuration and to "
    "'intake-air-temp protection' is wrong.",
)
gv(
    "0x003fd1e8",
    "hpcr_pressure_diag_delay_ticks",
    "intake_air_heater_performance_test_delay_ticks",
    "Dwell countdown between test phases, reloaded from ROM DAT_0006442a / 00064424 / 00064428 (25 / 30 / 2); used "
    "by hpcr_injectPressureTuning and initialised from DAT_0006442c in hpcr_throttlePositionDiagnostic.",
)
gv(
    "0x003fd1ea",
    "hpcr_pressure_diag_sample_count",
    "intake_air_heater_performance_test_sample_count",
    "Counts the three battery-voltage ADC samples that are averaged in each phase.",
)
gv(
    "0x003fd1ec",
    "hpcr_pressure_diag_ring_index",
    "intake_air_heater_performance_test_sample_ring_index",
    "Index (wraps after 3) of the three-element sample ring at 0x3fd1f6 filled in state 2.",
)
gv(
    "0x003fd1f0",
    "hpcr_pressure_diag_sample_sum_state0",
    "intake_air_heater_performance_test_baseline_battery_voltage_adc",
    "State 0 accumulates three raw battery-voltage ADC samples (qadc channel index 4) taken before the heater relays "
    "are on, then divides by 3 in place; state 1 subtracts the loaded average from it.",
)
gv(
    "0x003fd1f2",
    "hpcr_pressure_diag_reference_avg",
    "intake_air_heater_performance_test_loaded_battery_voltage_adc",
    "Average battery-voltage ADC reading with the heater on (state 1, refreshed from the ring average at the end of "
    "state 2); state 2 checks the ring average against it (-DAT_0006442e / +DAT_00064438) and state 3 subtracts it "
    "from the after-turn-off average. It is a voltage, not a pressure.",
)
gv(
    "0x003fd1f4",
    "hpcr_pressure_diag_sample_sum_state3",
    "intake_air_heater_performance_test_recovered_battery_voltage_adc",
    "State 3 accumulates three battery-voltage ADC samples after the heater relays are off, divides by 3 in place, "
    "and the recovery (this minus the loaded average) goes to DAT_0040b9e6.",
)
gv(
    "0x0040b9e8",
    "hpcr_pressure_diag_delta_state1",
    "intake_air_heater_performance_test_turn_on_voltage_drop_adc",
    "hpcr_pressure_diag_sample_sum_state0 minus the loaded average (baseline minus loaded), taken in state 1; "
    "compared with the turn-off recovery and with the temperature threshold in state 3.",
)
gv(
    "0x0040b9e4",
    "hpcr_pressure_diag_lookup_ref",
    "intake_air_heater_performance_test_minimum_voltage_change_adc",
    "Output of the intake_air_heater_performance_threshold_* lookup by intake_manifold_temperature_sensor_filtered "
    "(45 counts at 0 F ... 24 at 66 F), taken once on the state 0 -> 1 move; the test fails when both the turn-on drop "
    "and the turn-off recovery are below it.",
)
gv(
    "0x0040bc88",
    "hpcr_pressure_diag_forced_reading",
    "battery_voltage_adc_forced_reading",
    "Element 4 of a per-slot forced-reading array that starts at 0x40bc80 (2 bytes per slot): it replaces the QADC "
    "index 4 (battery voltage) reading when diagnostic_service_dispatch_table word +72 mask 0x10 is set, in the heater "
    "test and in cm848_sciCommand20Callback case 10. The same pattern for slot 69 in SCI case 1 reads DAT_0040bd0a "
    "with word +80 mask 0x20, and 0x40bd0a - 0x40bc88 = 130 = 2 x (69 - 4), while the enable bits are slot / 16 words "
    "past +72 and bit slot mod 16 (slot 4 = +72 mask 0x10, slot 69 = +80 mask 0x20), so this is the battery-voltage "
    "slot's forced value. It is a raw ADC count (it stands in for the dispatch-table ADC reading).",
)

# ---------------------------------------------------------------- globals: governor (wastegate duty) inputs
gv(
    "0x003fd7e0",
    "battery_voltage_gain_init_flag",
    "wastegate_duty_ceiling_grid_enable_cal",
    "Read only in cm848_boostCompensatedRpmGovernor: 0 selects the battery-voltage-scaled fixed ceiling "
    "(battery_voltage_correction_cal x gain / 4096), non-zero selects the engine speed x load grid "
    "(rpm_governor_state.reserved_0c). 0 in the dump. Address is in the EEPROM mirror, so _cal is right.",
)
gv(
    "0x003fd7e2",
    "fuel_quantity_override_flag",
    "wastegate_duty_floor_grid_enable_cal",
    "Read only in cm848_boostCompensatedRpmGovernor: non-zero takes the floor from the wastegate_duty_floor_* grid "
    "(rpm_governor_state.reserved_0e), 0 uses the fixed throttle_fuel_demand_alt_cal. 0 in the dump. EEPROM mirror.",
)
gv(
    "0x003fd7e4",
    "rpm_governor_fuel_mode_init_flag",
    "wastegate_duty_altitude_adjustment_enable_cal",
    "Read only in cm848_boostCompensatedRpmGovernor (with fuel_mode_switch_state = 0): 0 leaves the ceiling and floor "
    "as computed, non-zero adds adjustment_delta to the ceiling and limit_adjustment to the floor (both lookups of "
    "governor_adjustment_input = altitude) and clamps to 0..12800. 0 in the dump. EEPROM mirror.",
)
gv(
    "0x003ffc9e",
    "throttle_fuel_demand_alt_cal",
    "wastegate_duty_floor_fixed",
    "Read only in cm848_boostCompensatedRpmGovernor: the fixed floor of the wastegate duty request used when the "
    "floor grid is off; 128 half-duty counts = 1 % duty in the dump. Address is above the EEPROM mirror, so no _cal.",
)
gv(
    "0x003ffca4",
    "battery_voltage_correction_cal",
    "wastegate_duty_ceiling_fixed",
    "Read only in cm848_boostCompensatedRpmGovernor: the fixed ceiling (9600 = 75 % duty) multiplied by the battery "
    "voltage gain / 4096 when the ceiling grid is off. Above the EEPROM mirror, so no _cal.",
)
gv(
    "0x004002ca",
    "battery_voltage_axis_cal",
    "wastegate_duty_ceiling_battery_voltage_gain_axis",
    "x axis (battery voltage EMA, 1/16 V: 0 / 160 / 224 / 240 / 256) of the gain lookup in "
    "cm848_boostCompensatedRpmGovernor; its only reader. Address 0x4002ca is outside the EEPROM mirror, so the _cal "
    "suffix is wrong.",
)
gv(
    "0x004002d6",
    "battery_voltage_gain_output_cal",
    "wastegate_duty_ceiling_battery_voltage_gain_values",
    "Q12 gain values (5202 / 5202 / 4096 / 4096 / 4096 = 1.27 at or below 10 V, 1.0 at or above 14 V) multiplied into "
    "the fixed duty ceiling; only reader is cm848_boostCompensatedRpmGovernor. Not EEPROM, so no _cal.",
)
gv(
    "0x00400256",
    "governor_adjustment_rpm_axis_cal",
    "wastegate_duty_floor_adjustment_by_altitude_axis",
    "x axis of the lookup whose x input is governor_adjustment_input (altitude in feet), not engine speed; result "
    "rpm_governor_state.limit_adjustment is added to the duty floor. Only reader is cm848_boostCompensatedRpmGovernor. "
    "Mirrors wastegate_duty_ceiling_adjustment_by_altitude_axis. Not EEPROM, so no _cal.",
)
gv(
    "0x00400268",
    "governor_adjustment_limit_cal",
    "wastegate_duty_floor_adjustment_by_altitude_values",
    "Values of the same lookup (see governor_adjustment_rpm_axis_cal); only reader is "
    "cm848_boostCompensatedRpmGovernor. Not EEPROM, so no _cal.",
)
gv(
    "0x0040a194",
    "governor_adjustment_input",
    "barometric_altitude_feet",
    "Written by hpcr_fuelFinal_exponentialAverage from fuel_pressure_sensor_reference through the 0x3ff080 -> "
    "0x3ff0a2 table, which I checked: 1105 / 1149 / 1196 / 1244 / 1293 / 1344 / 1396 / 1452 / 1507 counts (1/18.56 "
    "kPa) give 14000 / 13000 / 12000 / 11000 / 10000 / 9000 / 8000 / 7000 / 6000, and the standard atmosphere gives "
    "13995 / 13014 / 12000 / 10998 / 10006 / 9005 / 8016 / 6984 / 6001 ft for those pressures. Read by the wastegate "
    "controller (both altitude trims) and by governor_adjustment_compare / _blend_check / fuel_demandBlend_weight_calc.",
)

# ---------------------------------------------------------------- notes
note(
    "struct rpm_governor_state_t (0x40a3ca) is the wastegate duty controller state, all in half-duty counts (12800 = "
    "100 %, the output stage sends 2 x commanded_rpm = 25600): commanded_rpm = final request; desired_rpm = duty "
    "ceiling; lower_rpm_limit = duty floor; reserved_0c = ceiling grid lookup (wastegate_duty_ceiling_*: x engine "
    "speed, y engine_load_input_b); reserved_0e = floor grid lookup; adjustment_delta = ceiling trim by altitude; "
    "limit_adjustment = floor trim by altitude; base_rpm_lookup = ceiling by engine speed alone "
    "(governor_base_rpm_output_cal, used while fuel_mode_switch_state is non-zero, floor then = "
    "throttle_rate_pid_gain_cal word 2); reserved_02 = feedback limit (smaller of throttle_rate_filtered_sum, "
    "reserved_04 and governor_rpm_state_output); reserved_04 = P minus D term of fuel_pressure_demand_reference - "
    "fuel_demand_quantity, +-25600; reserved_06 = P gain lookup. The struct and its 'rpm' fields should be renamed "
    "(e.g. wastegate_duty_state_t with duty-based field names); not proposed here."
)
note(
    "Dump numbers for the wastegate path: fuel_feature_control_flags = 0x11DC (mask 0x1000 set, output stage enabled); "
    "wastegate_duty_ceiling_grid and _floor_grid are flat 11532 (90.1 % duty) with a last row of 0 and both grid "
    "enable flags are 0, so the grids are unused; ceiling = 9600 x battery gain, floor = 128. cm848_applyWastegate"
    "SolenoidDuty output = 21792 (85.1 %) at 12.0 V, exactly 2 x (9600 x 4649 / 4096)."
)
note(
    "Second reader of the wastegate duty request: rpm_governor_state_t.commanded_rpm is also read by "
    "cm848_calculateSpeedControlLimit (0x2ca14). It clamps the word with speed_control_rpm_upper_limit_cal (12800 = "
    "100 % in half-duty counts) and, when governor_status_flags mask 0x4000 is set, into the window "
    "[fuel_control_setpoint_cal, 0x3200 - fuel_control_setpoint_cal] = [1856, 10944] (about 14.5 - 85.5 % duty), "
    "i.e. in the same half-duty units; the result fuel_control_setpoint_working (0x40b020) feeds "
    "cm848_calculateSpeedControlRampUp / RampDown, cm848_selectSpeedControlGains and cm848_checkSpeedZeroCondition "
    "(the governor_* speed / fuel PID ending in governor_fuel_demand_raw -> cm848_selectFuelControlModeOutput). Its "
    "purpose is unknown; it is a second consumer in duty units, not a contradiction of the wastegate reading, and "
    "the wastegate verdict does not depend on it (the only writer of 0x40a3ca is this function, the only actuator "
    "reader is the wastegate output stage). Do not rename the SpeedControl chain on this evidence; it needs its own "
    "review."
)
note(
    "cm848_checkSpeedBandCondition (0x11a4c) is the integrator anti-windup of this controller: it sets "
    "throttle_acceleration_active_flag (integrator enabled) unless commanded_rpm is pinned at desired_rpm / "
    "lower_rpm_limit in the direction of the error. cm848_turboCompensationWrapper (0x1231c, phase group A) and "
    "mpc555_initTurboCompensationVariables (0x1233c) are its wrapper and init and should follow the rename "
    "(e.g. cm848_runWastegateDutyControl / cm848_initWastegateDutyControl). The throttle_rate_* and governor_rpm_band_* "
    "variables inside it are controller internals with misleading names; I did not rename them (no independent "
    "evidence for what their inputs measure)."
)
note(
    "Charging regulator chain, evidence from disassembly of the four state handlers (ROM 0x38338 / 0x38384 / 0x383f0 / "
    "0x3844c) and the dump: next state 0 -> 1 when engine speed >= the threshold at 0x4087a8 or cold_start_phase = 3, "
    "and fault 368 clear; every state falls back to 0 when speed < the threshold at 0x4087a2 or fault 368 is set; "
    "1 -> 2 when the duty reaches 25600 or battery_voltage_delta <= the threshold at 0x4087ae; 2 -> 3 when "
    "battery_voltage_delta_filtered > the threshold at 0x4087ac; 3 -> 2 when the duty is 25600 and the elapsed count "
    "exceeds the limit at 0x4087b0, or battery_voltage_delta <= 0x4087ae. The regulator is enabled by "
    "engine_feature_enable_flags_cal bit 0 (0x27EF in the dump; its CSV comment lists bits 2 / 6 / 13 only), and "
    "operating_mode_flags mask 0x20 (set in the dump) switches states 2 and 3 to the PID in "
    "cm848_calculateProtectionOutputDemand. cm848_processProtectionCoolantLookup (0x375c8) is the charging voltage "
    "target (battery temperature table + offset), cm848_processProtectionVoltageOffset (0x37658) the error, "
    "cm848_dispatchProtectionOutputMode (0x376dc) the state machine and cm848_calculateProtectionOutputDemand "
    "(0x37a40) the PID; suggested names: cm848_calculateChargingVoltageTarget, cm848_calculateChargingVoltageError, "
    "cm848_updateAlternatorFieldRegulatorState, cm848_calculateAlternatorFieldDutyPid."
)
note(
    "Existing CSV comment to fix: alternator_field_duty_target (0x40b266) says it is 'filtered by "
    "cm848_filterProtectionOutput'; that function calculates the per-state duty and does not filter it. "
    "operating_mode_flags (0x3fd5ee) is inside the EEPROM mirror (EEPROM 0x16c) and has no _cal suffix; its bits seen "
    "here: 0x20 = charging PID enable, 0x200 = heater performance test enable, 0x400 = overboost monitor "
    "enable (value 0x7CA6 in the dump: 0x20 set, 0x200 clear). cold_start_feature_flags (0x3fd5c2) mask 0x8 = wastegate "
    "monitor enable (0x8488 in the dump, set); protection_feature_status_flags (0x40b9d0, runtime RAM) mask 0x1000000 "
    "= wastegate monitor armed, mask 0x4 = overboost monitor armed; both were clear in the dump (engine off), so "
    "nothing can be said about them while running."
)
note(
    "Unnamed ROM / RAM words in the wastegate monitor (no global_variables.csv row, so no rename proposed): "
    "DAT_00409fe0 = wastegate driver duty threshold (11520 = 45 %, e2m CWG_Driver_Duty_Cycle_Threshold), "
    "DAT_00409fe4 = high load threshold (19200 = 75 %, 1/256 % units), DAT_00409fe8 = minimum start battery "
    "temperature (1280 = 20 F, 1/64 F), DAT_003fd270 = monitor armed flag (byte, set in cm848_initAdaptiveControl), "
    "DAT_003fd271 / 003fd273 / 003fd275 = lookup index caches of the three monitor tables. "
    "In the heater test: DAT_00064424 = 30, DAT_00064426 = 1 (preheat ticks left at which state 2 moves to 3), "
    "DAT_00064428 = 2, DAT_0006442a = 25, DAT_0006442e = 15 (lower tolerance of the loaded average), DAT_00064430 = 10 "
    "(max turn-on drop vs turn-off recovery difference), DAT_00064432 = 0 (minimum intake manifold temperature), "
    "DAT_00064434 = 208 (13.0 V max) and DAT_00064436 = 160 (10.0 V min) battery voltage for a valid test, "
    "DAT_00064438 = 10 (upper tolerance), DAT_0040b9e6 = turn-off recovery, DAT_003fd1ee = latest state 2 ring "
    "average, DAT_003fd1f6 = the 3-word sample ring."
)
note(
    "hpcr_throttlePositionDiagnostic (0x53227c) is the arming step of the heater performance test, not a throttle "
    "diagnostic: it zeroes the sample count, ring index, hpcr_pressure_diag_reference_avg and "
    "hpcr_pressure_diag_sample_sum_state0, loads the dwell from DAT_0006442c, and sets the state to 0 only when the "
    "battery temperature and the intake manifold temperature agree within DAT_0006443a (a cold-soaked engine) and "
    "fault_detected_bits_368_to_383 bits 0x800 / 0x1000 are clear, otherwise to 6. Suggested name: "
    "cm848_armIntakeAirHeaterPerformanceTest (values of DAT_0006442c / DAT_0006443a not read)."
)
note(
    "engine_protection_batteryLoad_check (0x53232c) is not a battery load check: it returns 1 and sets the heater "
    "test state to 6 (aborted) when intake manifold temperature is below DAT_00064432, any of fault bits "
    "16..31 & 0x18 / 288..303 & 0x3c0 is set, battery voltage is outside 10-13 V (DAT_00064436 / DAT_00064434), or "
    "the heater is neither in preheat-on nor preheat-done. Suggested name: "
    "cm848_checkIntakeAirHeaterPerformanceTestConditions (not verified beyond the code). Also "
    "boost_pressure_fuel_working (0x40a162) reads 1648 in the dump against barometric_pressure 1647 and "
    "intake_manifold_pressure 1700, so it holds the barometric reading rather than a boost pressure (candidate name "
    "barometric_pressure_selected; not proposed, since the selection between the live value and its default on a "
    "fault is only read from two assignments)."
)
note(
    "Array typing (a type change, so a note only): the forced-reading words are one per sensor slot, 2 bytes each, "
    "starting at 0x40bc80 (slot 4 = 0x40bc88 = battery_voltage_adc_forced_reading, slot 69 = 0x40bd0a = "
    "DAT_0040bd0a, the battery temperature slot read by cm848_sciCommand20Callback case 1); the matching override "
    "enables are bit (slot mod 16) of word (slot / 16) of diagnostic_service_dispatch_table starting at +72."
)

with open(OUT, "w") as handle:
    for rec in records:
        handle.write(json.dumps(rec, ensure_ascii=True) + "\n")
print(len(records), "records written to", OUT)
