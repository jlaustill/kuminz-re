// Function: cm848_calculatePilotInjectionQuantity @ 0x0052ba30
//

/* WARNING: Function: cm848_signedDivision32 replaced with injection: sdiv64by32 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* Computes the pilot injection quantity injection_quantity_pilot_unscaled (0.0679 mm3 per count):
   the blended pilot_quantity map and the coolant, intake-temperature, ambient, boost and cold
   corrections are combined by sum / max / min wins (injection_quantity_pilot_logic_select, 2 = min
   in the RAM dump), slew-limited, and capped at fuel_demand_computed x DAT_00409e66 / 4096 (half in
   the dump). The result is 0 when crank_position_valid_flag is set with the DAT_00409e62 switch on,
   or in the free-acceleration shutoff (coolant and intake limits are 300 F in the dump), and a
   fixed value while fuel_pressure_limp_home_active_flag is set. cm848_fuel_demand_state_capture
   snapshots it into 0x3fd07e and engine_injectionAngle_updateCutoutAndTimingDemand turns it into
   pilot_injection_quantity (was cm848_torque_limit_state_update). */

void cm848_calculatePilotInjectionQuantity(void)

{
  uint uVar1;
  word x_input;
  word wVar2;
  word wVar3;
  word wVar4;
  short sVar5;
  word unaff_r23;
  uint uVar6;
  word unaff_r25;
  dword dVar7;
  
  wVar4 = intake_manifold_temperature_sensor_filtered;
  wVar3 = sensor_readings_t_0040baf2.barometric_pressure;
  x_input = sensor_readings_t_0040baf2.coolant_temp;
  if (((crank_position_valid_flag != 0) && (DAT_00409e62 != 0)) ||
     (((governor_mode_code == 0x2f ||
       ((int)(uint)DAT_00409e5a < (int)(short)governor_speed_error_b_filtered)) &&
      (((vehicle_speed < DAT_00409e5c &&
        (DAT_00409e5e < (short)sensor_readings_t_0040baf2.coolant_temp)) &&
       (DAT_00409e60 < (short)intake_manifold_temperature_sensor_filtered)))))) {
    dVar7 = 0;
    injection_quantity_pilot_source_code = 0xe;
    injection_quantity_pilot_slewed_q16 = dVar7;
    goto LAB_0052c614;
  }
  if (DAT_00409e4a != 0) {
    dVar7 = (dword)DAT_00409e4c;
    injection_quantity_pilot_source_code = 7;
    injection_quantity_pilot_slewed_q16 = dVar7;
    goto LAB_0052c614;
  }
  sVar5 = engine_rpm_state_t_0040b7ac.current_rpm -
          injection_quantity_pilot_engine_speed_with_hysteresis;
  injection_quantity_pilot_source_code = 0;
  if ((int)(short)injection_quantity_pilot_engine_speed_hysteresis < (int)sVar5) {
    injection_quantity_pilot_engine_speed_with_hysteresis =
         engine_rpm_state_t_0040b7ac.current_rpm - injection_quantity_pilot_engine_speed_hysteresis;
  }
  if ((int)sVar5 < -(int)(short)injection_quantity_pilot_engine_speed_hysteresis) {
    injection_quantity_pilot_engine_speed_with_hysteresis =
         engine_rpm_state_t_0040b7ac.current_rpm + injection_quantity_pilot_engine_speed_hysteresis;
  }
  sVar5 = fuel_demand_computed - injection_quantity_pilot_fuel_demand_with_hysteresis;
  uVar6 = (uint)(short)injection_quantity_pilot_fuel_demand_hysteresis;
  if ((int)uVar6 < (int)sVar5) {
    injection_quantity_pilot_fuel_demand_with_hysteresis =
         fuel_demand_computed - injection_quantity_pilot_fuel_demand_hysteresis;
  }
  if ((int)sVar5 < (int)-uVar6) {
    injection_quantity_pilot_fuel_demand_with_hysteresis =
         fuel_demand_computed + injection_quantity_pilot_fuel_demand_hysteresis;
  }
  if ((uint)fuel_demand_computed < (uVar6 & 0x3fff) << 2) {
    injection_quantity_pilot_fuel_demand_with_hysteresis = fuel_demand_computed;
  }
  if ((((cold_start_phase == CSP_ABOVE_RPM_TRIGGER) ||
       (cold_start_phase == CSP_ABOVE_RPM_VIA_EVENTS)) ||
      (cold_start_phase == CSP_SETPOINT_UNDERRUN)) &&
     (injection_quantity_pilot_cold_start_logic_select == 0)) {
    injection_quantity_pilot_coolant_factor =
         lookupTableInterpolation
                   (&DAT_003fd10e,sensor_readings_t_0040baf2.coolant_temp,
                    injection_quantity_pilot_coolant_factor_cold_start_axis,
                    injection_quantity_pilot_coolant_factor_cold_start_values,1);
  }
  else {
    injection_quantity_pilot_coolant_factor =
         cm848_dualAxisTableInterpolation
                   (&DAT_003fd130,sensor_readings_t_0040baf2.coolant_temp,
                    injection_quantity_pilot_coolant_factor_x_axis,
                    intake_manifold_temperature_sensor_filtered,
                    injection_quantity_pilot_coolant_factor_y_axis,
                    injection_quantity_pilot_coolant_factor_grid,3);
  }
  injection_quantity_pilot_cold_correction_factor =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd110,x_input,injection_quantity_pilot_cold_correction_factor_x_axis,wVar4
                  ,injection_quantity_pilot_cold_correction_factor_y_axis,
                  injection_quantity_pilot_cold_correction_factor_grid,3);
  wVar2 = lookupTableInterpolation
                    (&DAT_003fd10c,wVar4,injection_quantity_pilot_intake_temperature_factor_axis,
                     injection_quantity_pilot_intake_temperature_factor_values,1);
  wVar3 = cm848_dualAxisTableInterpolation
                    (&DAT_003fd11c,wVar4,injection_quantity_pilot_ambient_factor_x_axis,wVar3,
                     injection_quantity_pilot_ambient_factor_y_axis,
                     injection_quantity_pilot_ambient_factor_grid,5);
  wVar4 = cm848_calculateBoostPressure();
  injection_quantity_pilot_boost_factor =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd128,injection_quantity_pilot_engine_speed_with_hysteresis,
                  injection_quantity_pilot_boost_factor_x_axis,wVar4,
                  injection_quantity_pilot_boost_factor_y_axis,
                  injection_quantity_pilot_boost_factor_grid,4);
  wVar4 = cm848_dualAxisTableInterpolation
                    (&DAT_003fd124,injection_quantity_pilot_engine_speed_with_hysteresis,
                     injection_quantity_pilot_base_map_x_axis,
                     injection_quantity_pilot_fuel_demand_with_hysteresis,
                     injection_quantity_pilot_base_map_y_axis,injection_quantity_pilot_base_map_grid
                     ,4);
  if (fuel_blend_lower_map_number == 1) {
    unaff_r25 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_1_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_1_y_axis,injection_quantity_pilot_map_1_grid
                           ,4);
  }
  else if (fuel_blend_lower_map_number == 2) {
    unaff_r25 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_2_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_2_y_axis,injection_quantity_pilot_map_2_grid
                           ,4);
  }
  else if (fuel_blend_lower_map_number == 3) {
    unaff_r25 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_3_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_3_y_axis,injection_quantity_pilot_map_3_grid
                           ,4);
  }
  else if (fuel_blend_lower_map_number == 4) {
    unaff_r25 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_4_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_4_y_axis,injection_quantity_pilot_map_4_grid
                           ,4);
  }
  if (fuel_blend_upper_map_number == 1) {
    unaff_r23 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_1_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_1_y_axis,injection_quantity_pilot_map_1_grid
                           ,4);
  }
  else if (fuel_blend_upper_map_number == 2) {
    unaff_r23 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_2_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_2_y_axis,injection_quantity_pilot_map_2_grid
                           ,4);
  }
  else if (fuel_blend_upper_map_number == 3) {
    unaff_r23 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_3_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_3_y_axis,injection_quantity_pilot_map_3_grid
                           ,4);
  }
  else if (fuel_blend_upper_map_number == 4) {
    unaff_r23 = cm848_dualAxisTableInterpolation
                          (&timing_limit_boost_blend_interp_state,
                           injection_quantity_pilot_engine_speed_with_hysteresis,
                           injection_quantity_pilot_map_4_x_axis,
                           injection_quantity_pilot_fuel_demand_with_hysteresis,
                           injection_quantity_pilot_map_4_y_axis,injection_quantity_pilot_map_4_grid
                           ,4);
  }
  injection_quantity_pilot_map_blend =
       cm848_filterInputValue
                 ((int)(short)unaff_r25,(int)(short)unaff_r23,(int)(short)wVar4,
                  fuel_blend_lower_map_number,fuel_blend_upper_map_number,
                  fuel_blend_state_t_0040a494.blend_weight,fuel_blend_state_t_0040a494.blend_mode);
  DAT_0040b940 = cm848_dualAxisTableInterpolation
                           (&DAT_003fd138,injection_quantity_pilot_engine_speed_with_hysteresis,
                            injection_quantity_pilot_coolant_map_x_axis,
                            injection_quantity_pilot_fuel_demand_with_hysteresis,
                            injection_quantity_pilot_coolant_map_y_axis,
                            injection_quantity_pilot_coolant_map_grid,4);
  uVar6 = (int)(short)DAT_0040b940 * (int)(short)injection_quantity_pilot_coolant_factor;
  injection_quantity_pilot_coolant_correction =
       (short)((int)uVar6 >> 0xc) + (ushort)((int)uVar6 < 0 && (uVar6 & 0xfff) != 0);
  wVar4 = cm848_dualAxisTableInterpolation
                    (&DAT_003fd118,injection_quantity_pilot_engine_speed_with_hysteresis,
                     injection_quantity_pilot_intake_temperature_map_x_axis,
                     injection_quantity_pilot_fuel_demand_with_hysteresis,
                     injection_quantity_pilot_intake_temperature_map_y_axis,
                     injection_quantity_pilot_intake_temperature_map_grid,4);
  uVar6 = (int)(short)wVar4 * (int)(short)wVar2;
  injection_quantity_pilot_intake_temperature_correction =
       (short)((int)uVar6 >> 0xc) + (ushort)((int)uVar6 < 0 && (uVar6 & 0xfff) != 0);
  wVar4 = cm848_dualAxisTableInterpolation
                    (&DAT_003fd120,injection_quantity_pilot_engine_speed_with_hysteresis,
                     injection_quantity_pilot_ambient_map_x_axis,
                     injection_quantity_pilot_fuel_demand_with_hysteresis,
                     injection_quantity_pilot_ambient_map_y_axis,
                     injection_quantity_pilot_ambient_map_grid,4);
  uVar6 = (int)(short)wVar4 * (int)(short)wVar3;
  injection_quantity_pilot_ambient_correction =
       (short)((int)uVar6 >> 0xc) + (ushort)((int)uVar6 < 0 && (uVar6 & 0xfff) != 0);
  injection_quantity_pilot_temperature_correction =
       injection_quantity_pilot_intake_temperature_correction;
  if ((short)injection_quantity_pilot_intake_temperature_correction <
      (short)injection_quantity_pilot_coolant_correction) {
    injection_quantity_pilot_temperature_correction = injection_quantity_pilot_coolant_correction;
  }
  injection_quantity_pilot_boost_map_value =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd12c,injection_quantity_pilot_engine_speed_with_hysteresis,
                  injection_quantity_pilot_boost_map_x_axis,
                  injection_quantity_pilot_fuel_demand_with_hysteresis,
                  injection_quantity_pilot_boost_map_y_axis,injection_quantity_pilot_boost_map_grid,
                  0);
  injection_quantity_pilot_boost_correction =
       (dword)(CONCAT44((int)((ulonglong)
                              ((longlong)(int)(short)injection_quantity_pilot_boost_factor *
                              (longlong)(int)(uint)injection_quantity_pilot_boost_map_value) >> 0x20
                             ),(int)(short)injection_quantity_pilot_boost_factor *
                               (uint)injection_quantity_pilot_boost_map_value) / 0xccc);
  DAT_0040b95c = cm848_dualAxisTableInterpolation
                           (&DAT_003fd114,injection_quantity_pilot_engine_speed_with_hysteresis,
                            injection_quantity_pilot_cold_correction_map_x_axis,
                            injection_quantity_pilot_fuel_demand_with_hysteresis,
                            injection_quantity_pilot_cold_correction_map_y_axis,
                            injection_quantity_pilot_cold_correction_map_grid,4);
  uVar6 = (int)(short)DAT_0040b95c * (int)(short)injection_quantity_pilot_cold_correction_factor;
  injection_quantity_pilot_cold_correction =
       (short)((int)uVar6 >> 0xc) + (ushort)((int)uVar6 < 0 && (uVar6 & 0xfff) != 0);
  wVar3 = injection_quantity_pilot_fuel_pressure_limp_home_default;
  if (fuel_pressure_limp_home_active_flag == 0) {
    if (injection_quantity_pilot_logic_select == 1) {
      _timing_limit_arbitrated_target =
           (dword)(short)injection_quantity_pilot_temperature_correction;
      dVar7 = (dword)(short)injection_quantity_pilot_map_blend;
      if ((int)dVar7 < (int)_timing_limit_arbitrated_target) {
        if ((int)_timing_limit_arbitrated_target <=
            (int)(short)injection_quantity_pilot_ambient_correction) {
LAB_0052c224:
          _timing_limit_arbitrated_target = (int)(short)injection_quantity_pilot_ambient_correction;
        }
      }
      else {
        _timing_limit_arbitrated_target = dVar7;
        if ((int)dVar7 <= (int)(short)injection_quantity_pilot_ambient_correction)
        goto LAB_0052c224;
      }
      if ((int)_timing_limit_arbitrated_target <= (int)injection_quantity_pilot_boost_correction) {
LAB_0052c290:
        _timing_limit_arbitrated_target = injection_quantity_pilot_boost_correction;
      }
    }
    else if (injection_quantity_pilot_logic_select == 2) {
      _timing_limit_arbitrated_target =
           (dword)(short)injection_quantity_pilot_temperature_correction;
      dVar7 = (dword)(short)injection_quantity_pilot_map_blend;
      if ((int)_timing_limit_arbitrated_target < (int)dVar7) {
        if ((int)(short)injection_quantity_pilot_ambient_correction <=
            (int)_timing_limit_arbitrated_target) {
LAB_0052c278:
          _timing_limit_arbitrated_target = (int)(short)injection_quantity_pilot_ambient_correction;
        }
      }
      else {
        _timing_limit_arbitrated_target = dVar7;
        if ((int)(short)injection_quantity_pilot_ambient_correction <= (int)dVar7)
        goto LAB_0052c278;
      }
      if ((int)injection_quantity_pilot_boost_correction <= (int)_timing_limit_arbitrated_target)
      goto LAB_0052c290;
    }
    else {
      _timing_limit_arbitrated_target =
           (int)(short)injection_quantity_pilot_temperature_correction +
           (int)(short)injection_quantity_pilot_map_blend +
           (int)(short)injection_quantity_pilot_ambient_correction +
           injection_quantity_pilot_boost_correction;
      injection_quantity_pilot_source_code = 0xb;
    }
    if (injection_quantity_pilot_cold_correction_logic_select == 0) {
      if ((injection_quantity_pilot_logic_select != 0) &&
         ((short)injection_quantity_pilot_cold_correction != 0)) {
        _timing_limit_arbitrated_target =
             _timing_limit_arbitrated_target + (int)(short)injection_quantity_pilot_cold_correction;
        injection_quantity_pilot_source_code = 0x10;
      }
    }
    else if (injection_quantity_pilot_cold_correction_logic_select == 1) {
      if ((int)_timing_limit_arbitrated_target <=
          (int)(short)injection_quantity_pilot_cold_correction) goto LAB_0052c398;
    }
    else if ((injection_quantity_pilot_cold_correction_logic_select == 2) &&
            ((int)(short)injection_quantity_pilot_cold_correction <=
             (int)_timing_limit_arbitrated_target)) {
LAB_0052c398:
      _timing_limit_arbitrated_target = (dword)(short)injection_quantity_pilot_cold_correction;
    }
    DAT_0040b95e = cm848_dualAxisTableInterpolation
                             (&DAT_003fd13c,injection_quantity_pilot_engine_speed_with_hysteresis,
                              injection_quantity_pilot_cold_start_override_x_axis,x_input,
                              injection_quantity_pilot_cold_start_override_y_axis,
                              injection_quantity_pilot_cold_start_override_grid,6);
    if ((((cold_start_phase == CSP_ABOVE_RPM_TRIGGER) ||
         (cold_start_phase == CSP_ABOVE_RPM_VIA_EVENTS)) ||
        (cold_start_phase == CSP_SETPOINT_UNDERRUN)) &&
       (wVar3 = DAT_0040b95e, injection_quantity_pilot_cold_start_logic_select == 1))
    goto LAB_0052c41c;
  }
  else {
LAB_0052c41c:
    _timing_limit_arbitrated_target = (dword)(short)wVar3;
  }
  if ((int)(short)injection_quantity_pilot_coolant_correction == _timing_limit_arbitrated_target) {
    if ((((cold_start_phase == CSP_ABOVE_RPM_TRIGGER) ||
         (cold_start_phase == CSP_ABOVE_RPM_VIA_EVENTS)) ||
        (cold_start_phase == CSP_SETPOINT_UNDERRUN)) &&
       (injection_quantity_pilot_cold_start_logic_select == 0)) {
      injection_quantity_pilot_source_code = 6;
    }
    else {
      injection_quantity_pilot_source_code = 2;
    }
  }
  else if ((int)(short)injection_quantity_pilot_fuel_pressure_limp_home_default ==
           _timing_limit_arbitrated_target) {
    injection_quantity_pilot_source_code = 0xf;
  }
  else if ((int)(short)injection_quantity_pilot_intake_temperature_correction ==
           _timing_limit_arbitrated_target) {
    injection_quantity_pilot_source_code = 3;
  }
  else if ((int)(short)injection_quantity_pilot_map_blend == _timing_limit_arbitrated_target) {
    injection_quantity_pilot_source_code = 1;
  }
  else if ((int)(short)injection_quantity_pilot_ambient_correction ==
           _timing_limit_arbitrated_target) {
    injection_quantity_pilot_source_code = 4;
  }
  else if (injection_quantity_pilot_boost_correction == _timing_limit_arbitrated_target) {
    injection_quantity_pilot_source_code = 5;
  }
  else if ((int)(short)injection_quantity_pilot_cold_correction == _timing_limit_arbitrated_target)
  {
    injection_quantity_pilot_source_code = 0x11;
  }
  if ((((cold_start_phase == CSP_ABOVE_RPM_TRIGGER) ||
       (cold_start_phase == CSP_ABOVE_RPM_VIA_EVENTS)) ||
      (cold_start_phase == CSP_SETPOINT_UNDERRUN)) &&
     (injection_quantity_pilot_cold_start_logic_select == 1)) {
    injection_quantity_pilot_source_code = 0x13;
  }
  _timing_limit_arbitrated_target = _timing_limit_arbitrated_target << 0x10;
  if ((int)injection_quantity_pilot_slewed_q16 < (int)_timing_limit_arbitrated_target) {
    if ((timing_limit_slew_increase_step_q16 == 0) ||
       ((0 < (int)timing_limit_slew_increase_step_q16 &&
        (injection_quantity_pilot_slewed_q16 =
              injection_quantity_pilot_slewed_q16 + timing_limit_slew_increase_step_q16,
        (int)_timing_limit_arbitrated_target < (int)injection_quantity_pilot_slewed_q16)))) {
LAB_0052c5cc:
      injection_quantity_pilot_slewed_q16 = _timing_limit_arbitrated_target;
    }
  }
  else if (((int)_timing_limit_arbitrated_target < (int)injection_quantity_pilot_slewed_q16) &&
          ((timing_limit_slew_decrease_step_q16 == 0 ||
           ((0 < (int)timing_limit_slew_decrease_step_q16 &&
            (injection_quantity_pilot_slewed_q16 =
                  injection_quantity_pilot_slewed_q16 - timing_limit_slew_decrease_step_q16,
            (int)injection_quantity_pilot_slewed_q16 < (int)_timing_limit_arbitrated_target))))))
  goto LAB_0052c5cc;
  if ((int)injection_quantity_pilot_slewed_q16 < 0) {
    injection_quantity_pilot_slewed_q16 = 0;
    injection_quantity_pilot_source_code = 0xe;
  }
  else if ((int)((uint)fuel_demand_computed << 0x10) < (int)injection_quantity_pilot_slewed_q16) {
    injection_quantity_pilot_slewed_q16 = (uint)fuel_demand_computed << 0x10;
  }
  dVar7 = (int)injection_quantity_pilot_slewed_q16 >> 0x10;
LAB_0052c614:
  uVar6 = (uint)DAT_00409e66 * (uint)fuel_demand_computed >> 0xc;
  DAT_0040b94c = (short)uVar6;
  uVar1 = uVar6 & 0xffff;
  if ((int)dVar7 < (int)uVar1) {
    uVar6 = dVar7;
  }
  injection_quantity_pilot_unscaled = (word)uVar6;
  if ((uVar1 <= (uVar6 & 0xffff)) && (0x3a < fuel_demand_computed)) {
    injection_quantity_pilot_source_code = 0xd;
  }
  return;
}



//
// Function: cm848_initializePilotInjectionQuantityState @ 0x0052c688
