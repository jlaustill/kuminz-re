// Function: cm848_calculatePilotInjectionTimingOffset @ 0x0052c780
//

/* WARNING: Function: cm848_signedDivision32 replaced with injection: sdiv64by32 */
/* Computes how far the pilot (first) injection is advanced ahead of the main injection, in counts
   of 0.1171875 degree: the cold-start rpm x coolant map while cold_start_phase is
   CSP_ABOVE_RPM_TRIGGER / CSP_ABOVE_RPM_VIA_EVENTS / CSP_SETPOINT_UNDERRUN, otherwise the sum,
   highest, lowest or main-timing-winner choice (ROM mode word 0x409e74) of a 4-map blend, coolant,
   intake temperature, barometric pressure and boost components (each an rpm x
   total_injection_quantity angle map x a Q12 factor / 4096) and a constant (512 normally, 85 under
   an engine sync fault). While the governor holds a target speed (governor_mode_code 11 or 4) the
   maps are read at that speed and the result is scaled by measured / target rpm;
   cm848_calculatePilotInjectionTiming adds it to main_injection_timing to get the pilot timing for
   TPU-A channel 5 slot 4 (was engine_injectionTiming_arbitration_calc). */

void cm848_calculatePilotInjectionTimingOffset(void)

{
  word wVar1;
  uint uVar2;
  int iVar3;
  word unaff_r27;
  word unaff_r29;
  int iVar4;
  int iVar5;
  int iVar6;
  
  DAT_003fd16a = sensor_readings_t_0040baf2.coolant_temp;
  DAT_003fd16c = intake_manifold_temperature_sensor_filtered;
  DAT_003fd168 = sensor_readings_t_0040baf2.barometric_pressure;
  if (((cold_start_phase == CSP_ABOVE_RPM_TRIGGER) || (cold_start_phase == CSP_ABOVE_RPM_VIA_EVENTS)
      ) || (cold_start_phase == CSP_SETPOINT_UNDERRUN)) {
    injection_timing_pilot_offset_arbitrated =
         cm848_dualAxisTableInterpolation
                   (&DAT_003fd160,engine_rpm_state_t_0040b7ac.current_rpm,
                    injection_timing_pilot_offset_cold_start_x_axis,
                    sensor_readings_t_0040baf2.coolant_temp,
                    injection_timing_pilot_offset_cold_start_y_axis,
                    injection_timing_pilot_offset_cold_start_grid,6);
    injection_timing_pilot_source_code = 10;
    goto LAB_0052d010;
  }
  if (governor_mode_code == 0xb) {
    if (((int)(uint)engine_rpm_state_t_0040b7ac.current_rpm <=
         (int)((uint)governor_output_t_0040aec2.integrator._0_2_ -
              (uint)injection_timing_rpm_snap_tolerance)) ||
       ((uint)governor_output_t_0040aec2.integrator._0_2_ +
        (uint)injection_timing_rpm_snap_tolerance <= (uint)engine_rpm_state_t_0040b7ac.current_rpm))
    goto LAB_0052c8b0;
    injection_timing_rpm_snap_active_flag = 1;
    injection_timing_rpm_axis = governor_output_t_0040aec2.integrator._0_2_;
    timing_arbitration_status_bits = timing_arbitration_status_bits | 0x100;
  }
  else {
LAB_0052c8b0:
    if (governor_mode_code == 4) {
      if (((int)((uint)protection_monitored_rpm - (uint)injection_timing_rpm_snap_tolerance) <
           (int)(uint)engine_rpm_state_t_0040b7ac.current_rpm) &&
         ((uint)engine_rpm_state_t_0040b7ac.current_rpm <
          (uint)protection_monitored_rpm + (uint)injection_timing_rpm_snap_tolerance)) {
        injection_timing_rpm_snap_active_flag = 1;
        injection_timing_rpm_axis = protection_monitored_rpm;
        goto LAB_0052c910;
      }
    }
    injection_timing_rpm_snap_active_flag = 0;
    injection_timing_rpm_axis = engine_rpm_state_t_0040b7ac.current_rpm;
  }
LAB_0052c910:
  wVar1 = cm848_dualAxisTableInterpolation
                    (&DAT_003fd14c,injection_timing_rpm_axis,
                     injection_timing_pilot_offset_base_map_x_axis,total_injection_quantity,
                     injection_timing_pilot_offset_base_map_y_axis,
                     injection_timing_pilot_offset_base_map_grid,4);
  if (fuel_blend_lower_map_number == 1) {
    unaff_r29 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_1_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_1_y_axis,
                           injection_timing_pilot_offset_map_1_grid,4);
  }
  else if (fuel_blend_lower_map_number == 2) {
    unaff_r29 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_2_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_2_y_axis,
                           injection_timing_pilot_offset_map_2_grid,4);
  }
  else if (fuel_blend_lower_map_number == 3) {
    unaff_r29 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_3_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_3_y_axis,
                           injection_timing_pilot_offset_map_3_grid,4);
  }
  else if (fuel_blend_lower_map_number == 4) {
    unaff_r29 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_4_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_4_y_axis,
                           injection_timing_pilot_offset_map_4_grid,4);
  }
  if (fuel_blend_upper_map_number == 1) {
    unaff_r27 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_1_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_1_y_axis,
                           injection_timing_pilot_offset_map_1_grid,4);
  }
  else if (fuel_blend_upper_map_number == 2) {
    unaff_r27 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_2_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_2_y_axis,
                           injection_timing_pilot_offset_map_2_grid,4);
  }
  else if (fuel_blend_upper_map_number == 3) {
    unaff_r27 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_3_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_3_y_axis,
                           injection_timing_pilot_offset_map_3_grid,4);
  }
  else if (fuel_blend_upper_map_number == 4) {
    unaff_r27 = cm848_dualAxisTableInterpolation
                          (&injection_timing_pilot_offset_map_blend_cached_axis_offset,
                           injection_timing_rpm_axis,injection_timing_pilot_offset_map_4_x_axis,
                           total_injection_quantity,injection_timing_pilot_offset_map_4_y_axis,
                           injection_timing_pilot_offset_map_4_grid,4);
  }
  injection_timing_pilot_offset_map_blend =
       cm848_filterInputValue
                 ((int)(short)unaff_r29,(int)(short)unaff_r27,(int)(short)wVar1,
                  fuel_blend_lower_map_number,fuel_blend_upper_map_number,
                  fuel_blend_state_t_0040a494.blend_weight,fuel_blend_state_t_0040a494.blend_mode);
  injection_timing_pilot_offset_coolant_angle =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd15c,injection_timing_rpm_axis,
                  injection_timing_pilot_offset_coolant_angle_x_axis,total_injection_quantity,
                  injection_timing_pilot_offset_coolant_angle_y_axis,
                  injection_timing_pilot_offset_coolant_angle_grid,4);
  DAT_0040b972 = cm848_dualAxisTableInterpolation
                           (&DAT_003fd158,DAT_003fd16a,
                            injection_timing_pilot_offset_coolant_factor_x_axis,DAT_003fd16c,
                            injection_timing_pilot_offset_coolant_factor_y_axis,
                            injection_timing_pilot_offset_coolant_factor_grid,7);
  uVar2 = (int)(short)injection_timing_pilot_offset_coolant_angle * (int)(short)DAT_0040b972;
  injection_timing_pilot_offset_coolant_component =
       (short)((int)uVar2 >> 0xc) + (ushort)((int)uVar2 < 0 && (uVar2 & 0xfff) != 0);
  injection_timing_pilot_offset_intake_temperature_angle =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd148,injection_timing_rpm_axis,
                  injection_timing_pilot_offset_intake_temperature_angle_x_axis,
                  total_injection_quantity,
                  injection_timing_pilot_offset_intake_temperature_angle_y_axis,
                  injection_timing_pilot_offset_intake_temperature_angle_grid,4);
  DAT_0040b96a = lookupTableInterpolation
                           (&DAT_003fd142,DAT_003fd16c,
                            injection_timing_pilot_offset_intake_temperature_factor_axis,
                            injection_timing_pilot_offset_intake_temperature_factor_values,3);
  uVar2 = (int)(short)injection_timing_pilot_offset_intake_temperature_angle *
          (int)(short)DAT_0040b96a;
  injection_timing_pilot_offset_intake_temperature_component =
       (short)((int)uVar2 >> 0xc) + (ushort)((int)uVar2 < 0 && (uVar2 & 0xfff) != 0);
  injection_timing_pilot_offset_barometric_pressure_angle =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd144,injection_timing_rpm_axis,
                  injection_timing_pilot_offset_barometric_pressure_angle_x_axis,
                  total_injection_quantity,
                  injection_timing_pilot_offset_barometric_pressure_angle_y_axis,
                  injection_timing_pilot_offset_barometric_pressure_angle_grid,4);
  DAT_0040b964 = lookupTableInterpolation
                           (&DAT_003fd140,DAT_003fd168,
                            injection_timing_pilot_offset_barometric_pressure_factor_axis,
                            injection_timing_pilot_offset_barometric_pressure_factor_values,2);
  uVar2 = (int)(short)injection_timing_pilot_offset_barometric_pressure_angle *
          (int)(short)DAT_0040b964;
  injection_timing_pilot_offset_barometric_pressure_component =
       (short)((int)uVar2 >> 0xc) + (ushort)((int)uVar2 < 0 && (uVar2 & 0xfff) != 0);
  injection_timing_pilot_offset_boost_angle =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fd154,injection_timing_rpm_axis,
                  injection_timing_pilot_offset_boost_angle_x_axis,total_injection_quantity,
                  injection_timing_pilot_offset_boost_angle_y_axis,
                  injection_timing_pilot_offset_boost_angle_grid,4);
  wVar1 = cm848_calculateBoostPressure();
  DAT_0040b980 = cm848_dualAxisTableInterpolation
                           (&DAT_003fd150,injection_timing_rpm_axis,
                            injection_timing_pilot_offset_boost_factor_x_axis,wVar1,
                            injection_timing_pilot_offset_boost_factor_y_axis,
                            injection_timing_pilot_offset_boost_factor_grid,4);
  uVar2 = (int)(short)injection_timing_pilot_offset_boost_angle * (int)(short)DAT_0040b980;
  injection_timing_pilot_offset_boost_component =
       (short)((int)uVar2 >> 0xc) + (ushort)((int)uVar2 < 0 && (uVar2 & 0xfff) != 0);
  iVar3 = (int)(short)injection_timing_pilot_offset_boost_component;
  injection_timing_pilot_offset_constant_component = DAT_00409e7e;
  if (fuel_pressure_limp_home_active_flag != 0) {
    injection_timing_pilot_offset_constant_component = DAT_00409e7c;
  }
  iVar4 = (int)(short)injection_timing_pilot_offset_constant_component;
  if (injection_timing_arbitration_mode == 0) {
    iVar4 = (int)(short)injection_timing_pilot_offset_map_blend +
            (int)(short)injection_timing_pilot_offset_coolant_component +
            (int)(short)injection_timing_pilot_offset_intake_temperature_component +
            (int)(short)injection_timing_pilot_offset_barometric_pressure_component + iVar3 + iVar4;
    if (iVar4 < -0x400) {
      injection_timing_pilot_offset_arbitrated = 0xfc00;
    }
    else if (iVar4 < 0x401) {
      injection_timing_pilot_offset_arbitrated = (word)iVar4;
    }
    else {
      injection_timing_pilot_offset_arbitrated = 0x400;
    }
    injection_timing_pilot_source_code = 0xb;
    goto LAB_0052d010;
  }
  if (injection_timing_arbitration_mode == 1) {
    iVar6 = (int)(short)injection_timing_pilot_offset_map_blend;
    iVar5 = (int)(short)injection_timing_pilot_offset_coolant_component;
    if (iVar5 < iVar6) {
      if (iVar6 <= (short)injection_timing_pilot_offset_intake_temperature_component) {
LAB_0052ced0:
        iVar6 = (int)(short)injection_timing_pilot_offset_intake_temperature_component;
      }
    }
    else {
      iVar6 = iVar5;
      if (iVar5 <= (short)injection_timing_pilot_offset_intake_temperature_component)
      goto LAB_0052ced0;
    }
    iVar5 = (int)(short)injection_timing_pilot_offset_barometric_pressure_component;
    if (iVar5 < iVar6) {
      iVar5 = iVar6;
    }
    if (iVar5 <= iVar4) {
      iVar5 = iVar4;
    }
    injection_timing_pilot_offset_arbitrated = injection_timing_pilot_offset_boost_component;
    if (iVar5 <= iVar3) goto LAB_0052d010;
  }
  else {
    if (injection_timing_arbitration_mode != 2) {
      if (injection_timing_arbitration_mode == 3) {
        injection_timing_pilot_offset_arbitrated = injection_timing_pilot_offset_coolant_component;
        if (((((torque_limit_arb_t_0040a2f6.source_priority != 0x14) &&
              (torque_limit_arb_t_0040a2f6.source_priority != 0x18)) &&
             (injection_timing_pilot_offset_arbitrated =
                   injection_timing_pilot_offset_intake_temperature_component,
             torque_limit_arb_t_0040a2f6.source_priority != 0x13)) &&
            ((injection_timing_pilot_offset_arbitrated =
                   injection_timing_pilot_offset_barometric_pressure_component,
             torque_limit_arb_t_0040a2f6.source_priority != 0x15 &&
             (injection_timing_pilot_offset_arbitrated =
                   injection_timing_pilot_offset_boost_component,
             torque_limit_arb_t_0040a2f6.source_priority != 0x16)))) &&
           ((torque_limit_arb_t_0040a2f6.source_priority != 0xb &&
            (injection_timing_pilot_offset_arbitrated = injection_timing_pilot_offset_map_blend,
            torque_limit_arb_t_0040a2f6.source_priority == 0x1f)))) {
          injection_timing_pilot_offset_arbitrated =
               injection_timing_pilot_offset_constant_component;
        }
        injection_timing_pilot_source_code = 0xc;
      }
      goto LAB_0052d010;
    }
    iVar6 = (int)(short)injection_timing_pilot_offset_map_blend;
    iVar5 = (int)(short)injection_timing_pilot_offset_coolant_component;
    if (iVar6 < iVar5) {
      if ((short)injection_timing_pilot_offset_intake_temperature_component <= iVar6) {
LAB_0052cf48:
        iVar6 = (int)(short)injection_timing_pilot_offset_intake_temperature_component;
      }
    }
    else {
      iVar6 = iVar5;
      if ((short)injection_timing_pilot_offset_intake_temperature_component <= iVar5)
      goto LAB_0052cf48;
    }
    iVar5 = (int)(short)injection_timing_pilot_offset_barometric_pressure_component;
    if (iVar6 < iVar5) {
      iVar5 = iVar6;
    }
    if (iVar3 <= iVar5) {
      iVar5 = iVar3;
    }
    injection_timing_pilot_offset_arbitrated = injection_timing_pilot_offset_constant_component;
    if (iVar4 <= iVar5) goto LAB_0052d010;
  }
  injection_timing_pilot_offset_arbitrated = (word)iVar5;
LAB_0052d010:
  iVar3 = (int)(short)injection_timing_pilot_offset_arbitrated;
  if ((short)injection_timing_pilot_offset_map_blend == iVar3) {
    injection_timing_pilot_source_code = 1;
  }
  else if ((short)injection_timing_pilot_offset_coolant_component == iVar3) {
    injection_timing_pilot_source_code = 2;
  }
  else if ((short)injection_timing_pilot_offset_intake_temperature_component == iVar3) {
    injection_timing_pilot_source_code = 3;
  }
  else if ((short)injection_timing_pilot_offset_barometric_pressure_component == iVar3) {
    injection_timing_pilot_source_code = 4;
  }
  else if ((short)injection_timing_pilot_offset_boost_component == iVar3) {
    injection_timing_pilot_source_code = 5;
  }
  else if ((short)injection_timing_pilot_offset_constant_component == iVar3) {
    injection_timing_pilot_source_code = 0xf;
  }
  if (injection_timing_rpm_snap_active_flag == 0) {
    injection_timing_pilot_offset_rpm_corrected = injection_timing_pilot_offset_arbitrated;
  }
  else {
    iVar3 = (int)(CONCAT44((int)((ulonglong)
                                 ((longlong)iVar3 *
                                 (longlong)(int)(uint)engine_rpm_state_t_0040b7ac.current_rpm) >>
                                0x20),iVar3 * (uint)engine_rpm_state_t_0040b7ac.current_rpm) /
                 (longlong)(ulonglong)injection_timing_rpm_axis);
    if (iVar3 < -0x8000) {
      iVar3 = -0x8000;
    }
    else if (0x7fff < iVar3) {
      iVar3 = 0x7fff;
    }
    injection_timing_pilot_offset_rpm_corrected = (word)iVar3;
    timing_arbitration_status_bits = timing_arbitration_status_bits | 0x100;
  }
  return;
}



//
// Function: cm848_calculatePilotInjectionTiming @ 0x0052d140
