// Function: cm848_calculateAuxiliaryInjectionQuantityLimit @ 0x000466a8
//

/* WARNING: Function: cm848_signedDivision32 replaced with injection: sdiv64by32 */
/* Computes the auxiliary (third, after-main) injection quantity LIMIT (the cap of
   auxiliary_injection_quantity) injection_quantity_auxiliary_limit_unscaled: the blended
   injection_quantity_auxiliary map and the coolant, ambient and boost terms are selected by max or
   min wins (injection_quantity_auxiliary_logic_select: 1 = max, 2 = min), replaced by an override
   value when enabled, and set to 0 when crank_position_valid_flag is set with
   engine_sync_force_reset_cal = 1. cm848_fuel_demand_state_capture copies it to 0x3fd080 and
   engine_injectionAngle_updateCutoutAndTimingDemand uses it, scaled, as the cap of
   auxiliary_injection_quantity; the winning term goes to injection_quantity_auxiliary_source_code
   (was cm848_calculateGovernorOutput). */

void cm848_calculateAuxiliaryInjectionQuantityLimit(void)

{
  longlong lVar1;
  word y_input;
  word y_input_00;
  word wVar2;
  word wVar3;
  word wVar4;
  word wVar5;
  uint uVar6;
  int iVar7;
  word wStack_2e;
  
  y_input = intake_manifold_temperature_sensor_filtered;
  wVar3 = sensor_readings_t_0040baf2.barometric_pressure;
  wVar2 = sensor_readings_t_0040baf2.coolant_temp;
  wVar4 = 0;
  wVar5 = 0;
  if ((crank_position_valid_flag != 0) && (engine_sync_force_reset_cal == 1)) {
    injection_quantity_auxiliary_limit_unscaled = 0;
    injection_quantity_auxiliary_source_code = 0xe;
    return;
  }
  if (crank_sync_threshold_override_enable_cal != 0) {
    injection_quantity_auxiliary_limit_unscaled = crank_sync_threshold_override_cal;
    injection_quantity_auxiliary_source_code = 7;
    return;
  }
  y_input_00 = cm848_calculateBoostPressure();
  injection_quantity_auxiliary_coolant_factor =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fb606,wVar2,injection_quantity_auxiliary_coolant_factor_x_axis,y_input,
                  injection_quantity_auxiliary_coolant_factor_y_axis,
                  injection_quantity_auxiliary_coolant_factor_grid,7);
  injection_quantity_auxiliary_coolant_limit =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fb60e,engine_rpm_state_t_0040b7ac.current_rpm,
                  injection_quantity_auxiliary_coolant_limit_x_axis,fuel_demand_computed,
                  injection_quantity_auxiliary_coolant_limit_y_axis,
                  injection_quantity_auxiliary_coolant_limit_grid,4);
  uVar6 = (int)(short)injection_quantity_auxiliary_coolant_limit *
          (int)(short)injection_quantity_auxiliary_coolant_factor;
  injection_quantity_auxiliary_coolant_correction =
       (short)((int)uVar6 >> 0xc) + (ushort)((int)uVar6 < 0 && (uVar6 & 0xfff) != 0);
  wVar2 = cm848_dualAxisTableInterpolation
                    (&DAT_003fb5f2,y_input,injection_quantity_auxiliary_ambient_factor_x_axis,wVar3,
                     injection_quantity_auxiliary_ambient_factor_y_axis,
                     injection_quantity_auxiliary_ambient_factor_grid,5);
  wVar3 = cm848_dualAxisTableInterpolation
                    (&DAT_003fb5f6,engine_rpm_state_t_0040b7ac.current_rpm,
                     injection_quantity_auxiliary_ambient_limit_x_axis,fuel_demand_computed,
                     injection_quantity_auxiliary_ambient_limit_y_axis,
                     injection_quantity_auxiliary_ambient_limit_grid,4);
  lVar1 = CONCAT44((int)((ulonglong)((longlong)(int)(short)wVar2 * (longlong)(int)(short)wVar3) >>
                        0x20),(int)(short)wVar2 * (int)(short)wVar3) / 0x1000;
  iVar7 = (int)lVar1;
  if (iVar7 < 0x1701) {
    if (iVar7 < 0) {
      wStack_2e = 0;
    }
    else {
      wStack_2e = (word)lVar1;
    }
  }
  else {
    wStack_2e = 0x1700;
  }
  injection_quantity_auxiliary_ambient_correction = wStack_2e;
  injection_quantity_auxiliary_boost_factor =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fb5fa,engine_rpm_state_t_0040b7ac.current_rpm,
                  injection_quantity_auxiliary_boost_factor_x_axis,y_input_00,
                  injection_quantity_auxiliary_boost_factor_y_axis,
                  injection_quantity_auxiliary_boost_factor_grid,4);
  injection_quantity_auxiliary_boost_limit =
       cm848_dualAxisTableInterpolation
                 (&DAT_003fb5fe,engine_rpm_state_t_0040b7ac.current_rpm,
                  injection_quantity_auxiliary_boost_limit_x_axis,fuel_demand_computed,
                  injection_quantity_auxiliary_boost_limit_y_axis,
                  injection_quantity_auxiliary_boost_limit_grid,0);
  injection_quantity_auxiliary_boost_correction =
       (dword)(CONCAT44((int)((ulonglong)
                              ((longlong)((short)injection_quantity_auxiliary_boost_factor * 10) *
                              (longlong)(int)(uint)injection_quantity_auxiliary_boost_limit) >> 0x20
                             ),(short)injection_quantity_auxiliary_boost_factor * 10 *
                               (uint)injection_quantity_auxiliary_boost_limit) / 0x8000);
  wVar2 = cm848_dualAxisTableInterpolation
                    (&DAT_003fb5ee,engine_rpm_state_t_0040b7ac.current_rpm,
                     injection_quantity_auxiliary_base_map_x_axis,fuel_demand_computed,
                     injection_quantity_auxiliary_base_map_y_axis,
                     injection_quantity_auxiliary_base_map_grid,4);
  if (fuel_blend_lower_map_number == 1) {
    wVar4 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_1_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_1_y_axis,
                       injection_quantity_auxiliary_map_1_grid,4);
  }
  else if (fuel_blend_lower_map_number == 2) {
    wVar4 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_2_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_2_y_axis,
                       injection_quantity_auxiliary_map_2_grid,4);
  }
  else if (fuel_blend_lower_map_number == 3) {
    wVar4 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_3_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_3_y_axis,
                       injection_quantity_auxiliary_map_3_grid,4);
  }
  else if (fuel_blend_lower_map_number == 4) {
    wVar4 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_4_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_4_y_axis,
                       injection_quantity_auxiliary_map_4_grid,4);
  }
  if (fuel_blend_upper_map_number == 1) {
    wVar5 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_1_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_1_y_axis,
                       injection_quantity_auxiliary_map_1_grid,4);
  }
  else if (fuel_blend_upper_map_number == 2) {
    wVar5 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_2_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_2_y_axis,
                       injection_quantity_auxiliary_map_2_grid,4);
  }
  else if (fuel_blend_upper_map_number == 3) {
    wVar5 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_3_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_3_y_axis,
                       injection_quantity_auxiliary_map_3_grid,4);
  }
  else if (fuel_blend_upper_map_number == 4) {
    wVar5 = cm848_dualAxisTableInterpolation
                      (&injection_timing_boost_blend_interp_state,
                       engine_rpm_state_t_0040b7ac.current_rpm,
                       injection_quantity_auxiliary_map_4_x_axis,fuel_demand_computed,
                       injection_quantity_auxiliary_map_4_y_axis,
                       injection_quantity_auxiliary_map_4_grid,4);
  }
  injection_quantity_auxiliary_map_blend =
       cm848_filterInputValue
                 ((int)(short)wVar4,(int)(short)wVar5,(int)(short)wVar2,fuel_blend_lower_map_number,
                  fuel_blend_upper_map_number,fuel_blend_state_t_0040a494.blend_weight,
                  fuel_blend_state_t_0040a494.blend_mode);
  uVar6 = (uint)injection_quantity_auxiliary_map_blend;
  iVar7 = 1;
  if (injection_quantity_auxiliary_logic_select == 2) {
    if ((int)injection_quantity_auxiliary_boost_correction < (int)uVar6) {
      iVar7 = 5;
      uVar6 = injection_quantity_auxiliary_boost_correction;
    }
    if ((int)(uint)injection_quantity_auxiliary_ambient_correction < (int)uVar6) {
      iVar7 = 4;
      uVar6 = (uint)injection_quantity_auxiliary_ambient_correction;
    }
    if ((int)uVar6 <= (int)(short)injection_quantity_auxiliary_coolant_correction)
    goto LAB_00046c70;
  }
  else {
    if ((int)uVar6 < (int)injection_quantity_auxiliary_boost_correction) {
      iVar7 = 5;
      uVar6 = injection_quantity_auxiliary_boost_correction;
    }
    if ((int)uVar6 < (int)(uint)injection_quantity_auxiliary_ambient_correction) {
      iVar7 = 4;
      uVar6 = (uint)injection_quantity_auxiliary_ambient_correction;
    }
    if ((int)(short)injection_quantity_auxiliary_coolant_correction <= (int)uVar6)
    goto LAB_00046c70;
  }
  uVar6 = (uint)(short)injection_quantity_auxiliary_coolant_correction;
  iVar7 = 2;
LAB_00046c70:
  if ((int)uVar6 < 0x10000) {
    if ((int)uVar6 < 0) {
      uVar6 = 0;
    }
  }
  else {
    uVar6 = 0xffff;
  }
  injection_timing_arb_source_packed =
       ((int)(short)injection_timing_source_byte_2 & 0xffU) << 0x10 | iVar7 << 8 |
       (int)(short)governor_mode_code & 0xffU;
  injection_quantity_auxiliary_source_code = (word)iVar7;
  injection_quantity_auxiliary_limit_unscaled = (word)uVar6;
  return;
}



//
// Function: mpc555_initFuelFilterStates @ 0x00046cf8
