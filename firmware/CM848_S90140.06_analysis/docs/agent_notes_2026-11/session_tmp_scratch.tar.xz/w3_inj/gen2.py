import csv, json, re, subprocess
ROOT = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays"
src = open("/tmp/w3_inj/gen.py").read()
head = src.split("# ---------------- validation ----------------")[0]
exec(head)   # defines rows, F, G, N, NOTE, OUT, D

# ---- global string replacements (function prefix rule, demoted constant) ----
REPL = [("mpc555_exitSpeedLimpHome", "cm848_exitSpeedLimpHome"), ("mpc555_enterSpeedLimpHome", "cm848_enterSpeedLimpHome"),
        ("injection_timing_reference_offset", "DAT_0005a48a")]
def rep(v):
    if isinstance(v, str):
        for a, b in REPL: v = v.replace(a, b)
    return v
rows[:] = [{k: rep(v) for k, v in r.items()} for r in rows if not (r["kind"] == "new_global" and r["address"] == "0x0005a48a")]
def find(kind, addr):
    return next(r for r in rows if r["kind"] == kind and r.get("address") == addr)

# ---- 0x4090f6: correct the state 4 condition ----
find("global", "0x004090f6")["evidence"] = (
 "Disassembled all three readers. (1) engine_injectionAngle_tpuChannel6EventHandler state 2 (lhz 0x5296d0, beq 0x529704): value 0 -> third-event shift r31 = 0; nonzero -> shift = main on-time as an angle (main_injection_pulse_width x cam_sync_position_high_byte x 256 / crank_period_accumulator), added to the auxiliary start angle 0x40b87d. "
 "(2) cm848_calculateAuxiliaryInjectionPulseWidth (lhz 0x475e0): value 0 requires (interval - main_injection_pulse_width) >= main_to_auxiliary_injection_minimum_interval, nonzero tests the interval itself, i.e. nonzero = the auxiliary start is already measured from the END of the main pulse. "
 "(3) state 4 (lhz 0x529878, bne 0x5298ac): value 0 -> shift = main on-time angle, nonzero -> 0, the opposite of (1) and (2). "
 "State 4 belongs to the speed limp home sequence only: engine_injectionTiming_crankSyncDispatch calls engine_injectionAngle_schedule_crankValid (sets TPU mode 18 and state 4) when crank_position_valid_flag == 1, the channel 10 cylinder handler picks state 4 only while injection_tpu_timing_mode == 18, and with the flag 0 the sequence is states 1 -> 2 -> 8 using the state 2 code (schedule_crankInvalid, mode 2). "
 "e2m Aux_SOI_End_Of_Main_Adjust (0x01805C0E, 'adjust Aux SOI to be relative to Main EOI, 0 = SOI-SOI, 1 = EOI-SOI') sits at the matching offset (cal block 0x01805C00 = CM848 0x4090e8; its next word EOI_Aux_Separation_Limit 0x01805C10 = DAT_004090f8 is used in both states exactly as 'separation from the EOI limit'), so 1 = end-of-main referenced; normal running (state 2) and the gap check agree, the speed limp home path (state 4) has the inverted test. "
 "With the dump value 1 the third event is therefore placed relative to the main END in normal running and relative to the main START in speed limp home. Second limp-home quirk from the same disassembly: in the fresh-compute branch of state 4 the limit test and clip use the latched DAT_0040b87d (0x5298c8, 0x5298e8) while the event is written with the freshly computed angle (r24, 0x529924). Address is not EEPROM, so no _cal.")

# ---- channel 6 plate: new state 4 meaning, keep the old markers ----
find("function", "0x00529640")["plate_comment"] = (
 "TPU-A channel 6 interrupt: the injection scheduling state machine on injection_angle_sequence_state. State 1 runs the cut-out, quantity and timing demand (engine_injectionAngle_updateCutoutAndTimingDemand) and loads the pilot, main and auxiliary start angles (engine_injectionAngle_computeLoadCh6, which re-arms the channel for the scheduling angle and sets state 2); state 2 computes the pilot, main and auxiliary on-times and writes the three events (start angle, on-time, slots 4 / 8 / 12) into TPU-A channel 5 parameter RAM via engine_injectionAngle_writeTpuEvent, then state 8; state 4 is the speed limp home sequence (TPU mode 18, set by the schedule_crankValid scheduler): it does the same in one step, recomputing everything or reusing the angles of a still pending state 2. "
 "The auxiliary start is shifted by the main on-time as an angle (clipped to injection_end_limit_angle - auxiliary_injection_end_limit_separation) when injection_timing_auxiliary_relative_to_main_end_flag is nonzero in state 2 but when it is 0 in state 4. "
 "Was missing from every build (wrongly in deleted_functions.csv) | review-function-readability reviewed 2026-11-11 - Readability Medium Accuracy Confidence Medium | reached via tpu_a_channel_interrupt_handler_table[6] - mpc555_tpuAInterruptDispatcher 0x55de4 calls table[channel] - no direct caller")
find("function", "0x00529640")["evidence"] = ("Plate refreshed from the disassembly of all three states (see the 0x4090f6 row for the polarity test and the state 4 condition). Event writes go to TPU-A channel 5 parameter words 0x304154 / 0x304158 / 0x30415c (angle) with the on-time in the paired word, slots 4 / 8 / 12 = pilot / main / auxiliary; angles are timing counts x -5 = 0.0234375 degree per TPU count (0x7800 = 30720 counts = 720 degrees). Old plate facts (missing-from-build note, review marker, dispatcher address) carried over.")

# ---- scheduler functions: names carry the old flag polarity ----
F("0x00529994", "engine_injectionAngle_schedule_crankValid", "cm848_scheduleInjectionAnglesInSpeedLimpHome",
  "Speed limp home path of the injection scheduler: engine_injectionTiming_crankSyncDispatch calls it when engine_speed_limp_home_active_flag == 1 (engine position from TPU-A channel 1) and the channel 10 cylinder handler calls it while injection_tpu_timing_mode is 18. Sets mode 18, walks injection_angle_sequence_state (2 / 8 / 1 -> 4) and re-arms TPU-A channel 6 at the injection tooth (was engine_injectionAngle_schedule_crankValid, earlier cm848_protection_condition_eval_set1; does TPU injection timing, not protection).",
  "engine_injectionTiming_crankSyncDispatch: 'if (crank_position_valid_flag == 1) { read TPU-A ch1 PARAM4; engine_injectionAngle_schedule_crankValid(); }'; engine_injectionAngle_tpuChannel10CylinderEventHandler: 'if (injection_tpu_timing_mode == 0x12) { state = 4; schedule_crankValid }'. The flag is the speed limp home flag (see its row), so 'crankValid' is the limp-home path and the old name reads backwards.")
F("0x00529d1c", "engine_injectionAngle_schedule_crankInvalid", "cm848_scheduleInjectionAnglesOnPrimarySpeedInput",
  "Normal path of the injection scheduler (engine_speed_limp_home_active_flag == 0, engine position from TPU-A channel 0): sets injection_tpu_timing_mode to 2, computes the tooth and phase of the next injection sequence, loads TPU-A channel 6 and sets injection_angle_sequence_state to 1, so the channel 6 handler runs states 1 -> 2 -> 8 (was engine_injectionAngle_schedule_crankInvalid, earlier cm848_protection_condition_eval_set2; does TPU injection timing, not protection).",
  "engine_injectionTiming_crankSyncDispatch calls it when crank_position_valid_flag == 0 (TPU-A ch0 PARAM4 position) and the channel 10 handler calls it whenever the TPU mode is not 18; the init cm848_sensor_diagnostic_flag_update also starts in state 1 / mode 2. Primary input = channel 0, the one cm848_enterSpeedLimpHome switches off.")

# ---- types from the actual load instructions (lha = signed) ----
TYPES = {"0x0040b972":"i16","0x0040b96a":"i16","0x0040b964":"i16","0x0040b980":"i16","0x003fd16a":"word","0x003fd16c":"word","0x003fd168":"word",
 "0x00409e6e":"word","0x00409e70":"i16","0x00409e72":"word","0x00409e7a":"i16","0x00409e7c":"i16","0x00409e7e":"i16","0x0040b98e":"i16","0x0040b990":"i16",
 "0x00409090":"word","0x00409092":"i16","0x00409094":"i16","0x00409096":"word","0x0040b842":"word","0x00409098":"i16","0x0040909a":"i16","0x0040909c":"word",
 "0x004090f8":"i16","0x0040b871":"i16","0x0040b873":"i16","0x0040b87d":"i16","0x0040b870":"byte","0x003fd07e":"word","0x003fd080":"word","0x0040908c":"i16",
 "0x00409e66":"word","0x0040b94c":"word","0x0040b940":"i16","0x0040b95c":"i16","0x0040b95e":"i16","0x00409e4a":"word","0x00409e4c":"word","0x00409e5a":"word",
 "0x00409e5c":"word","0x00409e5e":"i16","0x00409e60":"i16","0x00409e62":"word"}
for r in rows:
    if r["kind"] != "new_global": continue
    a = r["address"]
    out = subprocess.run(["python3", ROOT + "/firmware/scripts/xref_addr.py", a], capture_output=True, text=True, cwd=ROOT).stdout
    m = re.search(r"total: (\d+) read\(s\), (\d+) write\(s\)", out)
    reads, writes = (m.group(1), m.group(2)) if m else ("?", "?")
    mn = sorted(set(re.findall(r"\[(?:load |store)\]\s+\w+\s+\w+:\s+(?:[0-9a-f]{2} ){4}\s*(\w+)", out)))
    t = TYPES[a]
    if "lha" in mn and t != "i16": print("TYPE?", a, t, mn)
    if "lhz" in mn and "lha" not in mn and t != "word": print("TYPE?", a, t, mn)
    r["type"] = t
    ev = re.sub(r"\s*width: .*$", "", r["evidence"]).rstrip()
    if not ev.endswith("."): ev += "."
    why = {"i16": "signed in the code (lha or (short) use)", "word": "unsigned in the code (lhz) or store-only", "byte": "byte"}[t]
    r["evidence"] = f"{ev} Width: xref_addr.py says {'byte' if t == 'byte' else 'word'} ({reads} reads / {writes} writes; {', '.join(mn)}); {why}."
find("new_global", "0x0040b98e")["evidence"] = ("= pilot_injection_timing_maximum_possible - pilot_injection_timing_maximum_margin, the cap of the pilot timing (source code 9; pilot_injection_timing is set from it). e2m Max_Allowable_Pilot_SOI (0x01806C2E = 0x40b960 + 0x2e): 'calculated imposed pilot tmg limit, offset from max possible tmg'. Write-only in the binary (stored once, the cap uses the same value from a register); a signed angle. Width: xref_addr.py says word (0 reads / 1 write; sth); i16 because the compare against pilot_injection_timing_uncapped is signed.")
find("new_global", "0x0040b990")["evidence"] = ("= earliest schedulable angle (DAT_0005fbb2 / 5 - tooth base offset term, 0x40b996) minus the engine-speed-proportional latency angle (injection_timing_speed_component). e2m Max_Possible_Pilot_SOI (0x01806C30): 'calculated earliest injection tmg that won't cause problems'. Write-only in the binary; a signed angle. Width: xref_addr.py says word (0 reads / 1 write; sth); i16 because it is subtracted from and compared as a signed angle.")

# ---- notes: rebuild three, add 0x5a48a, scheduler polarity, CM550 check ----
rows[:] = [r for r in rows if not (r["kind"] == "note" and (r["text"].startswith("Slot / state facts") or r["text"].startswith("Idle consequence") or r["text"].startswith("Struct torque_limit_arb_t_0040a2f6")))]
NOTE("Slot / state facts for firmware/CLAUDE.md: the pilot / main / auxiliary events are written by engine_injectionAngle_writeTpuEvent into TPU-A channel 5 parameter RAM (angle words 0x304154 / 0x304158 / 0x30415c = slots 4 / 8 / 12, on-time in the paired word), not by channel 6; the channel 6 interrupt handler is the scheduler (state 1 compute + arm, state 2 write, state 8 done; state 4 = the one-step speed limp home sequence). Normal running (crank_position_valid_flag 0) is TPU mode 2 with states 1 -> 2 -> 8 per cylinder event (schedule_crankInvalid); speed limp home (flag 1) is TPU mode 18 with state 4 (schedule_crankValid). Angle = timing counts x -5 = 0.0234375 degree per TPU count (30720 counts = 720 deg). Event order in crank angle: pilot (slot 4, main + offset) < main (slot 8) < auxiliary (slot 12, main - retard). e2m names the third event 'Aux' throughout (Aux_SOI, Aux_Quantity), so 'auxiliary' is Cummins' own word.")
NOTE("Consequence of the state 2 / state 4 asymmetry (0x4090f6 row): the dump value of injection_timing_auxiliary_relative_to_main_end_flag is 1, so in normal running (states 1 -> 2 -> 8) the third event is shifted by the main on-time and the minimum-gap test in cm848_calculateAuxiliaryInjectionPulseWidth (end-of-main gap) is consistent with it, while in speed limp home (state 4) the event is not shifted but the same gap test applies. Speed limp home is an abnormal state, so this probably never matters on the truck; whether it is a Cummins quirk or intended cannot be settled from the code.")
NOTE("Polarity fallout of the crank_position_valid_flag rename (-> engine_speed_limp_home_active_flag, 1 = backup speed input): other names built on the old reading are now backwards or misleading and were not touched: crank_pattern_valid_flag (check its meaning), engine_injectionTiming_crankSyncDispatch (name fine, plate says 'crank-position-valid path'), and the run-state handlers that test crank_position_valid_flag == 1 / == 0 (cm848_setEngineCrankState1, cm848_setEngineRunState1, cm848_engineRunState3Handler, cm848_engineRunState4Conditional, mpc555_updateEngineRunState, mpc555_updateEngineCrankState, cm848_protectionOverrideEvaluator, mpc555_updateSensorDiagnosticFlags). The 16 users of the flag keep working; only comments and plates that say 'valid' need a pass.")
NOTE("DAT_0005a48a (ROM word -171, i16, 4 reads, no row) is left without a name. Two uses agree: cm848_j1939HandlePgn65504ProprietaryB sends ((timing + K) x 120 >> 10) + 125 and, with the TDC-referenced auxiliary flag set, auxiliary timing = -(K + retard), i.e. K = -(the reference point in timing counts: 171 counts = 20.04 degrees) with timing counts larger = earlier. The third use contradicts that sign: in injection_delivery_mode 3 cm848_calculateMainInjectionTiming adds K to demand + injection_timing_offset_cal, which only fits if the offset cal is measured the other way round. Not settled, so no name (candidate if settled: injection_timing_top_dead_center_offset).")
NOTE("Struct torque_limit_arb_t_0040a2f6: field source_priority is used by cm848_calculateMainInjectionTiming (20 sites, writes of the winning code), cm848_calculatePilotInjectionTimingOffset (7 reads: mode 3 'same kind as the main timing winner'), cm848_updateEngineStatusFlags (packer) and cm848_initTimingFilterStates, so it is the main injection timing source code (the Final_Timing byte of combined_emissions_state). The other fields (source_active, limit_source, fuel_minimum, ~85 sites) were not checked; no struct_field rename proposed because the struct name would then disagree with its first field.")

# ---- plate tails from the current CSV ----
fnrows = {}
with open(D + "function_renames.csv", newline="") as f:
    for r in csv.reader(f):
        if r and not r[0].startswith("#") and r[0] != "address":
            try: fnrows[int(r[0], 16)] = r
            except: pass
for r in rows:
    if r["kind"] == "function":
        old_plate = fnrows[int(r["address"], 16)][2] if len(fnrows[int(r["address"], 16)]) > 2 else ""
        if " | " in old_plate:
            tail = old_plate[old_plate.index(" | "):]
            if tail not in r["plate_comment"]:
                print("TAIL appended for", r["address"], tail[:90]); r["plate_comment"] += tail

# ---- CM550 shared-name check ----
cm550 = set()
for fnm in ("global_variables.csv", "function_renames.csv"):
    try:
        for r in csv.reader(open(D.replace("CM848_S90140.06", "CM550_J90350.00") + fnm)):
            if r and len(r) > 1: cm550.add(r[1])
    except Exception as e: print("CM550 read error", fnm, e)
shared = sorted({r["old"] for r in rows if r["kind"] in ("global", "function") and r["old"] in cm550})
print("CM550 shares old names:", shared)
if shared:
    NOTE("CM550 rows with the same name as a renamed CM848 symbol (cross-firmware link would break; CM550 semantics not checked): " + ", ".join(shared))

# ---- validation (same as before, hex check fixed) ----
gv = {}
with open(D + "global_variables.csv", newline="") as f:
    for r in csv.reader(f):
        if r and not r[0].startswith("#") and r[0] != "address":
            try: gv[int(r[0], 16)] = r
            except: pass
names = set(r[1] for r in gv.values()) | set(r[1] for r in fnrows.values())
with open(D + "arrays.csv", newline="") as f:
    for r in csv.reader(f):
        if r and len(r) > 1: names.add(r[1]); names.add(r[0])
bad = 0; seen_new = {}
for r in rows:
    k = r["kind"]
    if k in ("global", "function", "new_global"): a = int(r["address"], 16)
    if k == "global":
        cur = gv.get(a)
        if not cur or cur[1] != r["old"]: print("OLD MISMATCH", r["address"], r["old"], cur[1] if cur else None); bad += 1
    if k == "function":
        cur = fnrows.get(a)
        if not cur or cur[1] != r["old"]: print("FN OLD MISMATCH", r["address"], r["old"], cur[1] if cur else None); bad += 1
        if not r["new"].startswith("cm848_") and r["new"] != r["old"]: print("PREFIX", r["new"]); bad += 1
    if k == "new_global" and a in gv: print("ROW EXISTS", r["address"], gv[a][1]); bad += 1
    if r.get("new"):
        n = r["new"]
        if n != r.get("old") and n in names: print("NAME EXISTS", n); bad += 1
        if n in seen_new and seen_new[n] != r.get("address"): print("DUP NEW", n); bad += 1
        seen_new[n] = r.get("address")
        if re.search(r"0x|(?<![a-z])[0-9a-f]{6,}(?![a-z])", n): print("HEX?", n); bad += 1
        if n.endswith("_cal") and k != "function" and not (0x3fd482 <= int(r["address"], 16) <= 0x3feec1): print("_cal outside EEPROM", n); bad += 1
        for t in re.split(r"_|(?<=[a-z])(?=[A-Z])", n):
            if t.lower() in ("tdc", "eoi", "soi", "eps", "ess", "lsg", "cyl", "aux", "mgr", "ctx", "temp", "pres", "cnt", "val", "cfg", "param", "idx"): print("ABBREV?", n, t); bad += 1
with open(OUT, "w") as f:
    for r in rows: f.write(json.dumps(r, ensure_ascii=True) + "\n")
from collections import Counter
c = Counter((r["kind"], r.get("verdict")) for r in rows)
print("rows", len(rows), dict(c), "problems", bad)
