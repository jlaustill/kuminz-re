import json, re, subprocess, sys
ROOT = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays"
rows = [json.loads(l) for l in open("/home/linux/.claude/jobs/d55ae3c6/tmp/renames/result_W3_injection.jsonl")]
addrs = [r["address"] for r in rows if r["kind"] == "new_global"] + ["0x0040b98e", "0x0040b990", "0x0040b996"]
want = {r["address"]: r.get("type") for r in rows if r["kind"] == "new_global"}
for a in addrs:
    out = subprocess.run(["python3", ROOT + "/firmware/scripts/xref_addr.py", a], capture_output=True, text=True, cwd=ROOT).stdout
    mn = {}
    for line in out.splitlines():
        m = re.match(r"\s+\[(load |store)\]\s+(\w+)\s+\w+:\s+(?:[0-9a-f]{2} ){4}\s*(\w+)", line)
        if m:
            mn.setdefault((m.group(1).strip(), m.group(2), m.group(3)), 0)
            mn[(m.group(1).strip(), m.group(2), m.group(3))] += 1
    summ = ", ".join(f"{k[2]}x{v}" for k, v in sorted(mn.items()))
    print(a, "planned:", want.get(a), "|", summ)
