#!/usr/bin/env python3
"""Read-only gate checks for the bin 02 (agent A) table names.

Usage: check_names.py <output_dir> <result_jsonl>
Checks: format, length, base uniqueness, composed-name collisions in every CSV, result file shape.
"""
import json
import os
import re
import sys

out_dir = sys.argv[1]
result_path = sys.argv[2]

files = [
    "global_variables.csv",
    "function_renames.csv",
    "enums.csv",
    "structure_definitions.csv",
    "arrays.csv",
    "constants.csv",
    "labels.csv",
    "local_variables.csv",
    "function_definitions.csv",
]
text = {}
for name in files:
    path = os.path.join(out_dir, name)
    if os.path.exists(path):
        text[name] = open(path, errors="replace").read()

rows = []
with open(result_path) as handle:
    for number, line in enumerate(handle, 1):
        line = line.strip()
        if not line:
            raise SystemExit("blank line %d" % number)
        rows.append(json.loads(line))

print("lines:", len(rows))
bases = {}
for row in rows:
    lookup = row["lookup"]
    if row.get("skip"):
        print(lookup, "SKIP", row["reason"][:80])
        continue
    base = row["base"]
    assert re.fullmatch(r"[a-z][a-z0-9_]*", base), base
    assert not base.endswith("_") and "__" not in base, base
    assert "_cal" not in base, base
    assert len(base) <= 48, (base, len(base))
    assert row["confidence"] in ("high", "medium"), row["confidence"]
    for key in ("input", "output", "units_check", "evidence", "naming_concern"):
        assert key in row, (lookup, key)
    assert base not in bases, ("duplicate base", base, bases[base], lookup)
    bases[base] = lookup

print("bases:", len(bases))
lookups = [row["lookup"] for row in rows]
assert len(lookups) == len(set(lookups)), "duplicate lookup lines"
print("lookups:", lookups)

collisions = 0
longest = 0
count = 0
for base, lookup in sorted(bases.items(), key=lambda item: item[1]):
    for suffix in ("_x_axis", "_y_axis", "_grid"):
        name = base + suffix
        count += 1
        longest = max(longest, len(name))
        for file_name, body in text.items():
            exact = body.count("," + name + ",")
            anywhere = body.count(name)
            if exact or anywhere:
                collisions += 1
                print("COLLISION", lookup, name, file_name, exact, anywhere)

print("composed names:", count, "longest:", longest, "collisions:", collisions)

# list the existing names that share the prefix, for a human eye
prefix = "injection_timing_auxiliary"
for line in text["global_variables.csv"].splitlines():
    if prefix in line:
        print("existing:", line[:110])
