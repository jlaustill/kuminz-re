import json
d = json.load(open('/home/linux/.claude/jobs/d55ae3c6/tmp/tables/bin_01.json'))
def sgn(v): return v - 65536 if v >= 32768 else v
RPM = 0.125; FUEL = 0.0679; TEMP = 1/64; BOOST = 0.0159
def conv(vals, k, nd=1):
    return [round(sgn(v) * k, nd) for v in vals]
for l in d['lookups']:
    print('=====', l['id'])
    for t in l['tables']:
        c = t['contents']
        bp = c.get('breakpoints_unsigned') or c.get('values_unsigned')
        role = t['role']
        if role == 'grid':
            print('  grid', t['address'], 'min/max', c['grid_min_max_unsigned'], 'shape', c['shape_x_by_y'],
                  'Q12', [round(x/4096, 2) for x in c['grid_min_max_unsigned']],
                  'deg(0.1171875)', [round(x*0.1171875, 1) for x in c['grid_min_max_unsigned']])
        else:
            print(' ', role, t['address'], 'n=', len(bp))
            print('     rpm :', conv(bp, RPM, 0))
            print('     mm3 :', conv(bp, FUEL, 1))
            print('     degF:', conv(bp, TEMP, 1))
            print('     inHg:', conv(bp, BOOST, 1))
            print('     Q12 :', [round(sgn(v)/4096, 2) for v in bp])
