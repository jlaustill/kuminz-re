import json, re, sys

BIN = '/home/linux/.claude/jobs/d55ae3c6/tmp/tables/bin_01.json'
OUT = '/home/linux/.claude/jobs/d55ae3c6/tmp/tables/result_01.jsonl'
GLOBALS = '/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output/global_variables.csv'

P = 'injection_timing_offset_'
RPM_AXIS_IN = ("x = injection_timing_rpm_axis (engine rpm, or the governor integrator / protection_monitored_rpm "
               "when within injection_timing_rpm_snap_tolerance; 0.125 rpm/count); "
               "y = engine_timing_reference (fuel quantity of the cylinder event: fuel_demand_computed_snapshot x "
               "injection_timing_demand_working / 0xc800 plus the cylinder_diag_output_array trim, clamped 0..0x1700; "
               "0.0679 mm3/count)")
UNIT_NOTE = "the six offset terms are summed or min/max-compared in the arbitration, so they share one unit"

records = []

records.append({
    "lookup": "L179",
    "base": P + "coolant_trim_scale",
    "input": "x = DAT_003fd16a, copy of sensor_readings_t_0040baf2.coolant_temp (1/64 deg F); "
             "y = DAT_003fd16c, copy of intake_manifold_temperature_sensor_filtered (1/64 deg F); both copied at the top of the function",
    "output": "DAT_0040b972 (unnamed) = Q12 multiplier; injection_timing_offset_coolant_trim = "
              "(injection_timing_coolant_trim_rpm_factor x DAT_0040b972) >> 12, one of the offset terms that become "
              "injection_timing_offset_arbitrated -> injection_timing_offset_rpm_corrected, which cm848_pressure_control_state_load adds to torque_limit_fault_snapshot (main injection timing; "
              "skipped when DAT_00409e72 is nonzero)",
    "units_check": "x -20, 0, 20, 50, 75, 90, 160, 180 deg F (-1280..11520); y 0, 10, 20, 30, 55, 60, 90, 120 deg F (0..7680); "
                   "all round values at 1/64 deg F; grid 4096..28672 = Q12 1.0..7.0 (row at 0 deg F intake all 1.0; row at 120 deg F intake "
                   "1.5 rising to 7.0 at 180 deg F coolant)",
    "confidence": "high",
    "evidence": "Both inputs are named temperature channels; the result multiplies the coolant rpm x fuel table in the Q12 idiom (a x b >> 12) "
                "to give the named injection_timing_offset_coolant_trim. cm848_calculateEngineTimingData makes the same lookup (coolant, "
                "intake manifold temperature, same flags) at 0x60d00.",
    "naming_concern": "Partner table destination injection_timing_coolant_trim_rpm_factor is called a factor but holds the angle term; "
                      "the Q12 factor is this table's unnamed destination DAT_0040b972."
})

records.append({
    "lookup": "L180",
    "base": P + "intake_temperature_scale",
    "input": "DAT_003fd16c, copy of intake_manifold_temperature_sensor_filtered (1/64 deg F)",
    "output": "DAT_0040b96a (unnamed) = Q12 multiplier; injection_timing_arb_component_3 = "
              "(injection_timing_arb_comp3_rpm_factor x DAT_0040b96a) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "axis -20, -15, 0, 10, 20, 30, 40, 55, 60, 77, 90, 120 deg F (-1280..7680), round values at 1/64 deg F; "
                   "values 4096 (1.0) up to 55 deg F, 7373 (1.8) at 60, 12247 (2.99) from 77 deg F up (Q12)",
    "confidence": "high",
    "evidence": "Input traces to the named intake manifold temperature channel; the output is the second factor of the component 3 product. "
                "cm848_calculateEngineTimingData has the matching 1-D lookup (0x60da4, intake temperature snapshot).",
    "naming_concern": "Comment on injection_timing_arb_component_3 says 'extended-protection mode' but the traced scale input is intake "
                      "manifold temperature; the destination names use banned abbreviations (arb, comp)."
})

records.append({
    "lookup": "L181",
    "base": P + "barometric_scale",
    "input": "DAT_003fd168, copy of sensor_readings_t_0040baf2.barometric_pressure (0.0159 inHg per count)",
    "output": "DAT_0040b964 (unnamed) = Q12 multiplier; injection_timing_arb_component_4 = "
              "(injection_timing_arb_comp4_rpm_factor x DAT_0040b964) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "axis 1257, 1383, 1509, 1635, 1886 = 20, 22, 24, 26, 30 inHg at 0.0159 inHg/count (round values); "
                   "values 4096, 4096, 4915, 5734, 12288 = Q12 1.0, 1.0, 1.2, 1.4, 3.0, rising with barometric pressure",
    "confidence": "high",
    "evidence": "Input traces to the barometric pressure sensor field, the same unit cm848_calculateBoostPressure subtracts from manifold pressure; "
                "the output is the second factor of the component 4 product. cm848_calculateEngineTimingData has the matching 1-D lookup "
                "(0x60dd8, barometric pressure snapshot).",
    "naming_concern": "Comment on injection_timing_arb_component_4 says 'rpm*rpm product' but the traced scale input is barometric pressure "
                      "(and its angle table is flat 512)."
})

records.append({
    "lookup": "L182",
    "base": P + "cold_start",
    "input": "x = engine_rpm_state_t_0040b7ac.current_rpm (0.125 rpm/count); y = sensor_readings_t_0040baf2.coolant_temp (1/64 deg F)",
    "output": "injection_timing_offset_arbitrated directly, only while cold_start_phase is CSP_ABOVE_RPM_TRIGGER, CSP_ABOVE_RPM_VIA_EVENTS or "
              "CSP_SETPOINT_UNDERRUN (engine_timing_arb_byte_24_31 = 10, component arbitration skipped) -> injection_timing_offset_rpm_corrected "
              "-> cm848_pressure_control_state_load adds torque_limit_fault_snapshot (main injection timing; skipped when DAT_00409e72 is nonzero)",
    "units_check": "x 0, 100, 190, 240, 400, 500, 600, 700, 900 rpm (0..7200 counts); y -30, -20, -10, 0, 10, 30, 50, 70, 190 deg F "
                   "(-1920..12160); grid 68..188 counts = 8..22 deg at 0.1171875 deg/count (9 x 9)",
    "confidence": "high",
    "evidence": "Both inputs are named, the breakpoints are round values in the post-cranking rpm range and the coolant range, and the output is "
                "assigned straight to the named arbitrated offset under the warm-up cold_start_phase values. cm848_calculateEngineTimingData "
                "makes the same lookup (same inputs and flags, 0x60df0) under the same cold_start_phase test.",
    "naming_concern": ""
})

records.append({
    "lookup": "L183",
    "base": P + "base_map",
    "input": RPM_AXIS_IN,
    "output": "local wVar1 -> third argument of cm848_filterInputValue, the value it returns when fuel_blend_state_t_0040a494.blend_mode is 0 "
              "(maps 1..4 take over as blend_mode rises to 100) -> injection_timing_offset_boost_blended, winner 1 of the arbitration",
    "units_check": "x 620, 650, 800 .. 3500 rpm (4960..28000 counts, round rpm); y 0, 10, 20, 30, 45, 55, 65, 75, 85, 95, 110, 120, 125, 130, 135, "
                   "140 mm3 (0..2061 counts at 0.0679); grid 81..490 counts = 9.5..57.4 deg at 0.1171875 deg/count (19 x 16), near-identical to maps 1..4; "
                   + UNIT_NOTE,
    "confidence": "high",
    "evidence": "cm848_filterInputValue returns (blended maps - param_3) x blend_mode / 100 + param_3, so param_3 is the mode-0 map; same axes and "
                "shape as the four selected maps, and the committed injection_timing_auxiliary_base_map has the same 19 x 16 layout.",
    "naming_concern": "injection_timing_offset_boost_blended says boost but is the base map / maps 1..4 blend (blend tables, not boost pressure); "
                      "the term that uses real boost pressure is the injection_timing_arb_component_5 pair."
})

records.append({
    "lookup": "L184",
    "base": P + "coolant_trim_angle",
    "input": RPM_AXIS_IN,
    "output": "injection_timing_coolant_trim_rpm_factor (angle term) -> injection_timing_offset_coolant_trim = "
              "(injection_timing_coolant_trim_rpm_factor x DAT_0040b972) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "x 500, 600, 650, 700, 800, 950, 1000, 1050, 1200, 1400, 2000, 2500, 3200 rpm (4000..25600); y 0, 22, 29, 36, 43, 50, 60, 70, 100, 110, "
                   "120 mm3 (0..1766 counts); grid 68..299 counts = 8..35 deg at 0.1171875 deg/count (13 x 11); " + UNIT_NOTE,
    "confidence": "high",
    "evidence": "Same two inputs as the other rpm x fuel tables of this function; the output is the first factor of the Q12 product that makes the named "
                "injection_timing_offset_coolant_trim, with the coolant x intake temperature table as the other factor.",
    "naming_concern": "Destination injection_timing_coolant_trim_rpm_factor holds the angle term (rpm x fuel table output), not a factor; "
                      "the table is named by what it produces."
})

records.append({
    "lookup": "L185",
    "base": P + "intake_temperature_angle",
    "input": RPM_AXIS_IN,
    "output": "injection_timing_arb_comp3_rpm_factor (angle term) -> injection_timing_arb_component_3 = "
              "(injection_timing_arb_comp3_rpm_factor x DAT_0040b96a) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "x 700, 1000, 1200 .. 3000, 3200 rpm (5600..25600); y 0, 22, 29, 36, 43, 50, 60, 70, 80, 100, 115 mm3 (0..1693 counts); "
                   "grid 171..512 counts = 20..60 deg at 0.1171875 deg/count (13 x 11); " + UNIT_NOTE,
    "confidence": "high",
    "evidence": "Same two inputs as the other rpm x fuel tables; its product partner is the intake manifold temperature scale table (L180), so this "
                "is the angle term of the intake temperature component.",
    "naming_concern": "injection_timing_arb_comp3_rpm_factor holds the angle term, not a factor; comment on component 3 says "
                      "'extended-protection mode' but its scale keys on intake manifold temperature."
})

records.append({
    "lookup": "L186",
    "base": P + "barometric_angle",
    "input": RPM_AXIS_IN,
    "output": "injection_timing_arb_comp4_rpm_factor (angle term) -> injection_timing_arb_component_4 = "
              "(injection_timing_arb_comp4_rpm_factor x DAT_0040b964) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "x 500, 650, 800 .. 2600, 3300 rpm (4000..26400); y 0, 10, 20, 25, 35, 45, 50, 60, 80, 100, 120 mm3 (0..1766 counts); "
                   "grid 512 (60 deg) in all 143 cells, so the angle term is flat and only the barometric scale shapes component 4 (13 x 11); " + UNIT_NOTE,
    "confidence": "high",
    "evidence": "Same two inputs as the other rpm x fuel tables; its product partner is the barometric pressure scale table (L181), so this is the "
                "angle term of the barometric component.",
    "naming_concern": "injection_timing_arb_comp4_rpm_factor holds the angle term, not a factor; comment on component 4 says 'rpm*rpm product' "
                      "but its scale keys on barometric pressure."
})

records.append({
    "lookup": "L187",
    "base": P + "boost_pressure_angle",
    "input": RPM_AXIS_IN,
    "output": "injection_timing_arb_comp5_rpm_factor_a (angle term) -> injection_timing_arb_component_5 = "
              "(injection_timing_arb_comp5_rpm_factor_a x DAT_0040b980) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "x 800, 1000 .. 3000, 3200 rpm (6400..25600); y 0, 30, 60, 70, 80, 90, 100, 110, 120, 130, 170 mm3 (0..2502 counts); "
                   "grid 213..512 counts = 25..60 deg at 0.1171875 deg/count (13 x 11); " + UNIT_NOTE,
    "confidence": "high",
    "evidence": "Same two inputs as the other rpm x fuel tables; its product partner is the rpm x boost pressure scale table (L188), so this is the "
                "angle term of the boost pressure component.",
    "naming_concern": "injection_timing_arb_comp5_rpm_factor_a holds the angle term, not a factor; comment on component 5 says "
                      "'crank-start mode' but its scale keys on rpm x boost pressure."
})

records.append({
    "lookup": "L188",
    "base": P + "boost_pressure_scale",
    "input": "x = injection_timing_rpm_axis (rpm, 0.125 rpm/count); y = wVar1 = cm848_calculateBoostPressure() (boost gauge pressure, or absolute "
             "manifold pressure when protection_sensor_mode_flag is 0; 0.0159 inHg/count)",
    "output": "DAT_0040b980 (unnamed) = Q12 multiplier; injection_timing_arb_component_5 = "
              "(injection_timing_arb_comp5_rpm_factor_a x DAT_0040b980) >> 12, an offset term arbitrated into injection_timing_offset_arbitrated",
    "units_check": "x 800, 1000 .. 3000, 3200 rpm (6400..25600); y 189, 314, 629, 754, 1069, 1320, 1572, 1760, 2138, 2515, 2766 counts = 3, 5, 10, 12, 17, "
                   "21, 25, 28, 34, 40, 44 inHg (round values at 0.0159); grid 4096..12288 = Q12 1.0..3.0, rising with boost (13 x 11)",
    "confidence": "high",
    "evidence": "y input is the named boost pressure function and its breakpoints are round inHg values; the output is the second factor of the "
                "component 5 product. cm848_calculateEngineTimingData has the matching rpm x boost lookup (0x61402).",
    "naming_concern": "Comment on injection_timing_arb_component_5 says 'crank-start mode' but its scale keys on rpm x boost pressure."
})

map_specs = [
    ("L189", 1, "81..491 counts = 9.5..57.5 deg", "0x637f4"),
    ("L190", 2, "85..494 counts = 10.0..57.9 deg", "0x63a9e"),
    ("L191", 3, "85..494 counts = 10.0..57.9 deg", "0x63d48"),
    ("L192", 4, "85..494 counts = 10.0..57.9 deg", "0x63ff2"),
]
for lid, n, grid_txt, addr in map_specs:
    records.append({
        "lookup": lid,
        "base": P + "map_%d" % n,
        "input": RPM_AXIS_IN,
        "output": "unaff_r29 (when boost_map_index_current = %d) and unaff_r27 (when boost_map_index_target = %d) -> first two arguments of "
                  "cm848_filterInputValue (current and target map values), blended by fuel_blend_state_t_0040a494.blend_weight / blend_mode into "
                  "injection_timing_offset_boost_blended, winner 1 of the arbitration" % (n, n),
        "units_check": "x 620 .. 3500 rpm (4960..28000 counts, round rpm); y 0 .. 140 mm3 (0..2061 counts at 0.0679); grid %s at 0.1171875 deg/count "
                       "(19 x 16), same axes and shape as the base map; %s" % (grid_txt, UNIT_NOTE),
        "confidence": "high",
        "evidence": "Selected by boost_map_index_current / boost_map_index_target = %d (blend table numbers 1..4), which is why the same address "
                    "set appears in two call statements; same axes as the base map and the committed injection_timing_auxiliary_map_%d family." % (n, n),
        "naming_concern": ""
    })

# ---------------------------------------------------------------- write
with open(OUT, 'w') as fh:
    for r in records:
        fh.write(json.dumps(r, ensure_ascii=True) + '\n')

# ---------------------------------------------------------------- validate
b = json.load(open(BIN))
kind = {l['id']: l['kind'] for l in b['lookups']}
tables_by_lookup = {l['id']: [(t['role'], t['address']) for t in l['tables']] for l in b['lookups']}
glob = open(GLOBALS).read()
glob_lines = glob.splitlines()
banned_words = ['_cal', 'temp_', '_temp', 'pres_', 'pos_', 'corr_', 'coef', 'thresh', 'inj_', 'qty', 'comp', 'arb', 'mgr', 'cfg', '0x']
ok = True
seen_addr = {}
bases = set()
for r in records:
    lid = r['lookup']
    base = r['base']
    if base in bases:
        print('DUPLICATE BASE', base); ok = False
    bases.add(base)
    if not re.fullmatch(r'[a-z0-9_]+', base):
        print('BAD CHARS', base); ok = False
    if len(base) > 48:
        print('BASE TOO LONG', base, len(base)); ok = False
    for tok in base.split('_'):
        if tok in ('cal', 'temp', 'pres', 'pos', 'corr', 'coef', 'thresh', 'inj', 'qty', 'comp', 'arb', 'mgr', 'cfg', 'protection', 'idx', 'val', 'cnt', 'ctrl', 'cmd'):
            print('BANNED TOKEN', tok, 'in', base); ok = False
    if '0x' in base:
        print('HEX IN NAME', base); ok = False
    if re.search(r'[0-9a-f]{6,}', base):
        print('HEX-LIKE', base); ok = False
    if kind[lid] == '2-D':
        suffix = {'x_axis': '_x_axis', 'y_axis': '_y_axis', 'grid': '_grid'}
    else:
        suffix = {'x_axis': '_axis', 'values': '_values'}
    for role, addr in tables_by_lookup[lid]:
        composed = base + suffix[role]
        if len(composed) > 56:
            print('COMPOSED TOO LONG', composed, len(composed)); ok = False
        needle = ',' + composed + ','
        hits = sum(1 for line in glob_lines if needle in line)
        if hits:
            print('NAME ALREADY IN global_variables.csv', composed, hits); ok = False
        if addr in seen_addr:
            print('ADDRESS TWICE', addr); ok = False
        seen_addr[addr] = composed
missing = [a for a in b['assigned_tables'] if a not in seen_addr]
extra = [a for a in seen_addr if a not in b['assigned_tables']]
print('records', len(records), 'bases', len(bases), 'addresses covered', len(seen_addr), 'assigned', len(b['assigned_tables']))
print('missing', missing, 'extra', extra)
for a in b['assigned_tables']:
    print(a, seen_addr.get(a), len(seen_addr.get(a, '')))
# JSON re-read check
with open(OUT) as fh:
    n = 0
    for line in fh:
        json.loads(line); n += 1
print('jsonl lines', n, 'ALL OK' if ok and not missing and not extra else 'PROBLEMS')
