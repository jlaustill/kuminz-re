import re
import sys

F = sys.argv[1]
names = sys.argv[2:]
cur = None
uses = {}
for line in open(F, errors="replace"):
    m = re.match(r"// Function: (\S+) @", line)
    if m:
        cur = m.group(1)
        continue
    for n in names:
        if re.search(r"\b" + n + r"\b", line):
            kind = "W" if re.search(r"\b" + n + r"\s*=[^=]", line) else "R"
            uses.setdefault(n, {}).setdefault(cur, set()).add(kind)
for n in names:
    print(n, {k: "".join(sorted(v)) for k, v in uses.get(n, {}).items()})
