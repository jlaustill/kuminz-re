#!/usr/bin/env python3
"""Validate result_05.jsonl against the brief's rules (read-only)."""
import json
import re

TABLES = "/home/linux/.claude/jobs/d55ae3c6/tmp/tables"
OUT = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/output"

binfile = json.load(open(TABLES + "/bin_05.json"))
lookups = {l["id"]: l for l in binfile["lookups"]}
assigned = set(binfile["assigned_tables"])

text = ""
for name in ("global_variables.csv", "arrays.csv", "function_renames.csv", "structure_definitions.csv", "enums.csv",
             "local_variables.csv", "constants.csv", "labels.csv"):
    try:
        text += open(OUT + "/" + name).read() + "\n"
    except OSError:
        pass

BANNED = re.compile(r"(_cal(_|$))|0x|(^|_)(temp|tmp|pos|press|corr|cfg|calc|param|val|idx|cnt|ctr|ptr|mgr|ctx)(_|$)|(^|_)protection(_|$)")
seen = set()
covered_tables = set()
problems = 0
with open(TABLES + "/result_05.jsonl") as handle:
    for number, line in enumerate(handle, 1):
        record = json.loads(line)
        lid = record["lookup"] if "lookup" in record else None
        if lid is None:
            print("line", number, "non-lookup record", record.get("table"))
            continue
        seen.add(lid)
        lk = lookups[lid]
        for t in lk["tables"]:
            if t["address"] in assigned:
                covered_tables.add(t["address"])
        if record.get("skip"):
            print(lid, "SKIP", record["reason"][:80])
            continue
        base = record["base"]
        suffixes = ("_x_axis", "_y_axis", "_grid") if lk["kind"] == "2-D" else ("_axis", "_values")
        ok = True
        if len(base) > 48:
            print(lid, "base too long", len(base)); ok = False
        if not re.fullmatch(r"[a-z][a-z0-9_]*", base):
            print(lid, "bad charset"); ok = False
        if BANNED.search(base):
            print(lid, "banned token in", base); ok = False
        if base.endswith("_") or "__" in base:
            print(lid, "underscore rule"); ok = False
        for s in suffixes:
            composed = base + s
            if len(composed) > 56:
                print(lid, "composed too long", composed, len(composed)); ok = False
            hits = len(re.findall(r"(^|[,\s])" + re.escape(composed) + r"([,\s]|$)", text))
            if hits:
                print(lid, "COLLISION", composed, hits); ok = False
        hits = len(re.findall(r"(^|[,\s])" + re.escape(base) + r"([,\s]|$)", text))
        if hits:
            print(lid, "base itself exists in CSVs:", base, hits)
        for key in ("input", "output", "units_check", "confidence", "evidence", "naming_concern"):
            if key not in record:
                print(lid, "missing key", key); ok = False
        if record["confidence"] not in ("high", "medium"):
            print(lid, "bad confidence"); ok = False
        print(lid, "OK" if ok else "PROBLEM", base, len(base))
        problems += 0 if ok else 1

print("lookups missing:", sorted(set(lookups) - seen))
print("assigned tables not covered:", sorted(assigned - covered_tables))
print("problems:", problems)
