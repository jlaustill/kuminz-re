#!/usr/bin/env python3
"""Scratch reader for bin 05 research (read-only): prints words from the CM848 images.

usage:
  peek.py words <hexaddr> <count>            big-endian unsigned and signed words
  peek.py grid  <hexaddr> <nx> <ny>          2-D grid rows (y index down, x index across)
  peek.py axis  <hexaddr>                    byte-length word + breakpoints
  peek.py vars                               live values of the timing variables in the RAM dump
"""
import os
import struct
import sys

BASE = "/home/linux/code/kuminz-re/.claude/worktrees/cm848-typing-arrays/firmware/CM848_S90140.06_analysis/originals"
rom = open(os.path.join(BASE, "cm848_rom.bin"), "rb").read()
ram = open(os.path.join(BASE, "cm848_ram.bin"), "rb").read()
flash2 = open(os.path.join(BASE, "cm848_flash2_live.bin"), "rb").read()


def word(addr, signed=False):
    fmt = ">h" if signed else ">H"
    if addr < 0x70000:
        return struct.unpack(fmt, rom[addr:addr + 2])[0]
    if 0x3FA000 <= addr < 0x3FA000 + len(ram):
        o = addr - 0x3FA000
        return struct.unpack(fmt, ram[o:o + 2])[0]
    if 0x500000 <= addr < 0x500000 + len(flash2):
        o = addr - 0x500000
        return struct.unpack(fmt, flash2[o:o + 2])[0]
    raise ValueError(hex(addr))


def main():
    cmd = sys.argv[1]
    if cmd == "words":
        a = int(sys.argv[2], 16)
        n = int(sys.argv[3])
        print([word(a + 2 * i) for i in range(n)])
        print([word(a + 2 * i, True) for i in range(n)])
    elif cmd == "axis":
        a = int(sys.argv[2], 16)
        length = word(a)
        n = length // 2
        print("bytes", length, "points", n)
        print("unsigned", [word(a + 2 + 2 * i) for i in range(n)])
        print("signed  ", [word(a + 2 + 2 * i, True) for i in range(n)])
    elif cmd == "grid":
        a = int(sys.argv[2], 16)
        nx = int(sys.argv[3])
        ny = int(sys.argv[4])
        for y in range(ny):
            print("y%02d" % y, [word(a + 2 * (y * nx + x)) for x in range(nx)])
    elif cmd == "vars":
        names = {
            0x409E40: "injection_delivery_mode", 0x409E42: "injection_timing_select_mode_cal",
            0x409E44: "injection_timing_demand_lower_limit_cal", 0x409E46: "injection_timing_cyl5_fault",
            0x409E48: "injection_timing_cyl5_normal", 0x40B90E: "injection_timing_demand_calc",
            0x40B910: "factor_base_b", 0x40B912: "factor_base_a", 0x40B914: "demand_cyl2",
            0x40B916: "factor_cyl2_b", 0x40B918: "factor_cyl2_a", 0x40B91A: "demand_cyl3",
            0x40B91C: "factor_cyl3_b", 0x40B91E: "factor_cyl3_a", 0x40B928: "demand_cyl4",
            0x40B92A: "factor_cyl4_b", 0x40B92C: "factor_cyl4_a", 0x40B92E: "injection_timing_demand",
            0x40B930: "timing_arbitration_status_bits", 0x40B936: "demand_cyl5",
            0x40A46E: "injection_timing_advance", 0x40AEE8: "injection_timing_demand_floor",
            0x40B256: "injection_timing_demand_min_working", 0x40A2CE: "fuel_demand_computed",
            0x40A2E6: "torque_limit_fault_snapshot", 0x40A7C0: "cold_start_phase",
            0x3FB728: "coolant_temp_snapshot", 0x3FB72A: "timing_imt_snapshot",
            0x3FB72C: "timing_baro_snapshot", 0x40BAF4: "slot2 coolant", 0x40BB02: "slot9 intake manifold temp",
            0x40BAF6: "slot3 barometric", 0x40BAF2: "slot1 intake manifold pressure", 0x40B7BA: "current_rpm",
            0x40AEBC: "governor_speed_limit_active_flag", 0x40B8A8: "engine_sync_fault_active_flag (byte)",
        }
        for a, n in sorted(names.items()):
            print("0x%06x %-44s u=%6d s=%6d hex=0x%04x" % (a, n, word(a), word(a, True), word(a)))


main()
